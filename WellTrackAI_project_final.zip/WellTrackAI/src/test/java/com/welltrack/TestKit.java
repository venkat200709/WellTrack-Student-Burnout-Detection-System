package com.welltrack;

import java.util.ArrayList;
import java.util.List;
import java.util.function.BooleanSupplier;

/**
 * A miniature assertion and test-running framework.
 *
 * <p>WellTrack has no third-party dependencies — including test libraries — so
 * this stands in for JUnit. It supports named suites, expressive assertions,
 * expected-exception checks and a summary report with timings, which is
 * everything this project's tests actually need.</p>
 *
 * <p>Run it with {@code java -cp out com.welltrack.TestRunner}.</p>
 */
public final class TestKit {

    private static final List<String> failures = new ArrayList<>();
    private static int passed;
    private static int executed;
    private static String currentSuite = "";

    private TestKit() {
    }

    public static void suite(String name) {
        currentSuite = name;
        System.out.println();
        System.out.println("\033[1m\033[36m▸ " + name + "\033[0m");
    }

    /** Runs one named check, catching anything it throws. */
    public static void test(String description, Runnable body) {
        executed++;
        long started = System.nanoTime();
        try {
            body.run();
            passed++;
            System.out.printf("  \033[32m✔\033[0m %-62s %5.1f ms%n",
                    description, (System.nanoTime() - started) / 1_000_000.0);
        } catch (Throwable error) {
            failures.add(currentSuite + " → " + description + " :: " + error.getMessage());
            System.out.printf("  \033[31m✘ %-62s %s\033[0m%n", description, error.getMessage());
        }
    }

    public static void assertTrue(boolean condition, String message) {
        if (!condition) {
            throw new AssertionError(message);
        }
    }

    public static void assertFalse(boolean condition, String message) {
        assertTrue(!condition, message);
    }

    public static void assertEquals(Object expected, Object actual, String message) {
        if (expected == null ? actual != null : !expected.equals(actual)) {
            throw new AssertionError(message + " (expected <" + expected + "> but was <" + actual + ">)");
        }
    }

    public static void assertClose(double expected, double actual, double tolerance, String message) {
        if (Math.abs(expected - actual) > tolerance) {
            throw new AssertionError(message + " (expected " + expected + " ± " + tolerance
                    + " but was " + actual + ")");
        }
    }

    public static void assertGreater(double actual, double threshold, String message) {
        if (!(actual > threshold)) {
            throw new AssertionError(message + " (" + actual + " was not greater than " + threshold + ")");
        }
    }

    public static void assertLess(double actual, double threshold, String message) {
        if (!(actual < threshold)) {
            throw new AssertionError(message + " (" + actual + " was not less than " + threshold + ")");
        }
    }

    public static void assertNotNull(Object value, String message) {
        assertTrue(value != null, message);
    }

    /** Asserts that the body throws the expected exception type. */
    public static void assertThrows(Class<? extends Throwable> expected, Runnable body, String message) {
        try {
            body.run();
        } catch (Throwable thrown) {
            if (expected.isInstance(thrown)) {
                return;
            }
            throw new AssertionError(message + " (threw " + thrown.getClass().getSimpleName()
                    + " instead of " + expected.getSimpleName() + ")");
        }
        throw new AssertionError(message + " (nothing was thrown)");
    }

    public static void assertEventually(BooleanSupplier condition, long timeoutMillis, String message) {
        long deadline = System.currentTimeMillis() + timeoutMillis;
        while (System.currentTimeMillis() < deadline) {
            if (condition.getAsBoolean()) {
                return;
            }
            try {
                Thread.sleep(25);
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                break;
            }
        }
        throw new AssertionError(message);
    }

    /** Prints the summary and returns the process exit code. */
    public static int report() {
        System.out.println();
        System.out.println("─".repeat(78));
        if (failures.isEmpty()) {
            System.out.printf("\033[1m\033[32m  ALL TESTS PASSED — %d of %d checks\033[0m%n", passed, executed);
        } else {
            System.out.printf("\033[1m\033[31m  %d of %d checks FAILED\033[0m%n",
                    failures.size(), executed);
            failures.forEach(failure -> System.out.println("    • " + failure));
        }
        System.out.println("─".repeat(78));
        return failures.isEmpty() ? 0 : 1;
    }
}
