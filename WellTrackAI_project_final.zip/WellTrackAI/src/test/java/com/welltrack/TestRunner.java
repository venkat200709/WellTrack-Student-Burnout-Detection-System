package com.welltrack;

import com.welltrack.ai.BurnoutPredictor;
import com.welltrack.ai.ForecastEngine;
import com.welltrack.ai.KnowledgeBase;
import com.welltrack.ai.RecommendationEngine;
import com.welltrack.ai.TrainingDataFactory;
import com.welltrack.ai.engine.AnomalyDetector;
import com.welltrack.ai.engine.HoltLinearForecaster;
import com.welltrack.ai.engine.KMeansClusterer;
import com.welltrack.ai.engine.LogisticRegressionModel;
import com.welltrack.ai.engine.ModelMetrics;
import com.welltrack.ai.engine.StandardScaler;
import com.welltrack.ai.nlp.NaiveBayesIntentClassifier;
import com.welltrack.ai.nlp.SentimentAnalyzer;
import com.welltrack.ai.nlp.TfIdfIndex;
import com.welltrack.ai.nlp.Tokenizer;
import com.welltrack.core.http.HttpMethod;
import com.welltrack.core.http.HttpRequest;
import com.welltrack.core.http.HttpResponse;
import com.welltrack.core.http.Router;
import com.welltrack.core.json.Json;
import com.welltrack.core.json.JsonArray;
import com.welltrack.core.json.JsonException;
import com.welltrack.core.json.JsonObject;
import com.welltrack.core.util.Numbers;
import com.welltrack.core.util.Validation;
import com.welltrack.dto.BehaviorLogRequest;
import com.welltrack.dto.LoginRequest;
import com.welltrack.exception.ValidationException;
import com.welltrack.model.BehaviorLog;
import com.welltrack.model.RiskDriver;
import com.welltrack.model.Student;
import com.welltrack.model.User;
import com.welltrack.model.enums.Mood;
import com.welltrack.model.enums.RiskLevel;
import com.welltrack.model.enums.Role;
import com.welltrack.repository.BehaviorLogRepository;
import com.welltrack.repository.UserRepository;
import com.welltrack.repository.datastore.Datastore;
import com.welltrack.repository.datastore.InMemoryDatastore;
import com.welltrack.security.Pbkdf2PasswordEncoder;
import com.welltrack.security.RateLimiter;
import com.welltrack.security.TokenService;

import java.time.Duration;
import java.time.LocalDate;
import java.util.List;
import java.util.Map;
import java.util.Random;

import static com.welltrack.TestKit.assertClose;
import static com.welltrack.TestKit.assertEquals;
import static com.welltrack.TestKit.assertFalse;
import static com.welltrack.TestKit.assertGreater;
import static com.welltrack.TestKit.assertLess;
import static com.welltrack.TestKit.assertNotNull;
import static com.welltrack.TestKit.assertThrows;
import static com.welltrack.TestKit.assertTrue;
import static com.welltrack.TestKit.suite;
import static com.welltrack.TestKit.test;

/**
 * The WellTrack test suite.
 *
 * <p>Covers the JSON engine, validation, security primitives, the persistence
 * layer, HTTP routing and — most importantly — every machine-learning component,
 * because a wellness model that is quietly wrong is worse than no model at all.</p>
 */
public final class TestRunner {

    public static void main(String[] args) {
        com.welltrack.core.util.Log.setColourEnabled(true);
        System.out.println("\n  WellTrack — automated test suite\n" + "═".repeat(78));

        jsonEngine();
        validation();
        security();
        persistence();
        routing();
        domainModel();
        machineLearning();
        naturalLanguage();
        forecasting();
        endToEndScoring();

        System.exit(TestKit.report());
    }

    /* ------------------------------------------------------------------ */

    private static void jsonEngine() {
        suite("JSON engine");

        test("serialises and reparses a nested structure", () -> {
            JsonObject original = JsonObject.of()
                    .set("name", "Venkatesan N")
                    .set("score", 63.9)
                    .set("active", true)
                    .set("nothing", null)
                    .set("tags", JsonArray.of("cse", "year3"))
                    .set("nested", JsonObject.of("deep", JsonArray.of(1, 2, 3)));

            JsonObject parsed = Json.parseObject(Json.write(original));
            assertEquals("Venkatesan N", parsed.getString("name"), "string survives the round trip");
            assertClose(63.9, parsed.getDouble("score", 0), 1e-9, "double survives the round trip");
            assertTrue(parsed.getBoolean("active", false), "boolean survives the round trip");
            assertEquals(2, parsed.getArray("tags").size(), "array length is preserved");
            assertEquals(3, parsed.getObject("nested").getArray("deep").size(), "nesting is preserved");
        });

        test("escapes control characters and quotes", () -> {
            String awkward = "He said \"stop\"\n\tand left \\ now";
            JsonObject parsed = Json.parseObject(Json.write(JsonObject.of("text", awkward)));
            assertEquals(awkward, parsed.getString("text"), "escaping is lossless");
        });

        test("rejects malformed documents", () -> {
            assertThrows(JsonException.class, () -> Json.parse("{\"a\":}"), "missing value is rejected");
            assertThrows(JsonException.class, () -> Json.parse("[1,2"), "unterminated array is rejected");
            assertThrows(JsonException.class, () -> Json.parse(""), "empty input is rejected");
        });

        test("guards against unbounded nesting", () ->
                assertThrows(JsonException.class,
                        () -> Json.parse("[".repeat(100) + "]".repeat(100)),
                        "deep nesting is refused"));

        test("pretty printing stays parseable", () -> {
            String pretty = Json.writePretty(JsonObject.of("a", JsonArray.of(1, 2)));
            assertTrue(pretty.contains("\n"), "pretty output is multi-line");
            assertNotNull(Json.parseObject(pretty), "pretty output re-parses");
        });
    }

    /* ------------------------------------------------------------------ */

    private static void validation() {
        suite("Input validation");

        test("collects every violation rather than stopping at the first", () -> {
            try {
                Validation.check()
                        .required("username", "")
                        .email("email", "not-an-email")
                        .password("password", "short")
                        .throwIfInvalid();
                throw new AssertionError("expected a ValidationException");
            } catch (ValidationException e) {
                assertEquals(3, e.fieldErrors().size(), "all three problems are reported together");
            }
        });

        test("accepts a compliant password and rejects weak ones", () -> {
            assertTrue(Validation.check().password("p", "Student@2026").isValid(), "strong password passes");
            assertFalse(Validation.check().password("p", "alllowercase1").isValid(), "no uppercase fails");
            assertFalse(Validation.check().password("p", "NoDigitsHere").isValid(), "no digit fails");
            assertFalse(Validation.check().password("p", "Ab1").isValid(), "too short fails");
        });

        test("scores password strength sensibly", () -> {
            assertLess(Validation.passwordStrength("abc"), 40, "a trivial password scores low");
            assertGreater(Validation.passwordStrength("Tr0ub4dor&3xyz"), 75, "a strong password scores high");
            assertLess(Validation.passwordStrength("password1234"), 45, "a common pattern is penalised");
        });

        test("range checks reject impossible check-in values", () ->
                assertThrows(ValidationException.class,
                        () -> BehaviorLogRequest.from(JsonObject.of()
                                .set("sleepHours", 40).set("stressLevel", 99)),
                        "a 40-hour night is refused"));

        test("cross-field rule catches attendance exceeding schedule", () ->
                assertThrows(ValidationException.class,
                        () -> BehaviorLogRequest.from(JsonObject.of()
                                .set("classesScheduled", 2).set("classesAttended", 8)),
                        "attending more classes than exist is refused"));

        test("login request requires both credentials", () ->
                assertThrows(ValidationException.class,
                        () -> LoginRequest.from(new JsonObject()),
                        "empty credentials are refused"));
    }

    /* ------------------------------------------------------------------ */

    private static void security() {
        suite("Security primitives");

        Pbkdf2PasswordEncoder encoder = new Pbkdf2PasswordEncoder();

        test("password hashing is salted, verifiable and one-way", () -> {
            String hash = encoder.encode("Student@2026");
            assertTrue(hash.startsWith("pbkdf2-sha256$210000$"), "hash records its parameters");
            assertFalse(hash.contains("Student@2026"), "the plaintext never appears in the hash");
            assertTrue(encoder.matches("Student@2026", hash), "the correct password verifies");
            assertFalse(encoder.matches("student@2026", hash), "verification is case sensitive");
            assertFalse(encoder.matches("wrong", hash), "an incorrect password fails");
        });

        test("the same password produces different hashes", () -> {
            String first = encoder.encode("Student@2026");
            String second = encoder.encode("Student@2026");
            assertFalse(first.equals(second), "a fresh salt is used every time");
            assertTrue(encoder.matches("Student@2026", first) && encoder.matches("Student@2026", second),
                    "both hashes still verify");
        });

        test("malformed stored credentials fail closed", () ->
                assertFalse(encoder.matches("anything", "not-a-real-hash"), "garbage never verifies"));

        TokenService tokens = new TokenService("a-very-long-development-signing-secret-value", 3600);
        Student subject = new Student("venkat", "venkat@cit.edu.in", "Venkatesan N", "hash");
        subject.setId(42);
        subject.setRole(Role.STUDENT);

        test("tokens carry the expected claims", () -> {
            JsonObject claims = tokens.verify(tokens.issue(subject));
            assertEquals("venkat", claims.getString("sub"), "subject claim");
            assertEquals(42L, claims.getLong("uid", 0), "user id claim");
            assertEquals("STUDENT", claims.getString("role"), "role claim");
            assertGreater(tokens.remainingSeconds(claims), 3500, "expiry is in the future");
        });

        test("a tampered signature is rejected", () -> {
            String token = tokens.issue(subject);
            assertThrows(com.welltrack.exception.AuthenticationException.class,
                    () -> tokens.verify(token + "x"), "modified signature fails");
            String[] parts = token.split("\\.");
            String forged = parts[0] + "." + parts[1] + ".ZmFrZXNpZ25hdHVyZQ";
            assertThrows(com.welltrack.exception.AuthenticationException.class,
                    () -> tokens.verify(forged), "forged signature fails");
        });

        test("an expired token is rejected", () -> {
            TokenService shortLived = new TokenService("another-very-long-signing-secret-for-tests", -5);
            assertThrows(com.welltrack.exception.AuthenticationException.class,
                    () -> shortLived.verify(shortLived.issue(subject)), "expiry is enforced");
        });

        test("a token signed with a different secret is rejected", () -> {
            TokenService other = new TokenService("a-completely-different-secret-of-sufficient-length", 3600);
            assertThrows(com.welltrack.exception.AuthenticationException.class,
                    () -> other.verify(tokens.issue(subject)), "cross-secret verification fails");
        });

        test("the rate limiter exhausts and refuses further attempts", () -> {
            RateLimiter limiter = new RateLimiter(3, Duration.ofMinutes(5));
            assertTrue(limiter.tryAcquire("10.0.0.1"), "first attempt allowed");
            assertTrue(limiter.tryAcquire("10.0.0.1"), "second attempt allowed");
            assertTrue(limiter.tryAcquire("10.0.0.1"), "third attempt allowed");
            assertFalse(limiter.tryAcquire("10.0.0.1"), "fourth attempt refused");
            assertTrue(limiter.tryAcquire("10.0.0.2"), "a different caller is unaffected");
        });

        test("account lockout engages after the configured failures", () -> {
            Student student = new Student("locked", "l@x.edu", "Locked Account", "hash");
            for (int i = 0; i < 4; i++) {
                student.registerFailedLogin(5, 10);
                assertFalse(student.isLocked(), "still unlocked after " + (i + 1) + " failures");
            }
            student.registerFailedLogin(5, 10);
            assertTrue(student.isLocked(), "locked on the fifth failure");
            student.registerSuccessfulLogin();
            assertFalse(student.isLocked(), "a successful sign-in clears the lock");
            assertEquals(0, student.getFailedLoginAttempts(), "the counter resets");
        });

        test("role hierarchy is respected", () -> {
            assertTrue(Role.ADMIN.satisfies(Role.STUDENT), "admin satisfies student");
            assertTrue(Role.FACULTY.satisfies(Role.STUDENT), "faculty satisfies student");
            assertFalse(Role.STUDENT.satisfies(Role.ADMIN), "student does not satisfy admin");
        });
    }

    /* ------------------------------------------------------------------ */

    private static void persistence() {
        suite("Persistence layer");

        Datastore datastore = new InMemoryDatastore();
        UserRepository users = new UserRepository(datastore);
        BehaviorLogRepository logs = new BehaviorLogRepository(datastore);

        test("assigns identities and finds by id", () -> {
            Student student = new Student("tester", "tester@cit.edu.in", "Test Student", "hash",
                    "2104251040999", "CSE", "A", 3);
            users.save(student);
            assertGreater(student.getId(), 0, "an id was assigned");
            assertTrue(users.findById(student.getId()).isPresent(), "the entity is retrievable");
        });

        test("finds accounts by username or email, case-insensitively", () -> {
            assertTrue(users.findByIdentifier("TESTER").isPresent(), "username lookup ignores case");
            assertTrue(users.findByIdentifier("tester@cit.edu.in").isPresent(), "email lookup works");
            assertFalse(users.findByIdentifier("ghost").isPresent(), "unknown identifiers return empty");
        });

        test("polymorphic mapping restores the concrete subclass", () -> {
            UserRepository reloaded = new UserRepository(datastore);
            reloaded.load();
            User restored = reloaded.findByIdentifier("tester").orElseThrow();
            assertTrue(restored instanceof Student, "a Student is restored as a Student");
            assertEquals("2104251040999", ((Student) restored).getRegisterNumber(), "subclass fields survive");
        });

        test("never exposes the password hash through JSON", () -> {
            User user = users.findByIdentifier("tester").orElseThrow();
            assertFalse(Json.write(user.toJson()).contains("passwordHash"), "credentials are not serialised");
        });

        test("stores and queries time-series behaviour logs", () -> {
            long studentId = users.findByIdentifier("tester").orElseThrow().getId();
            for (int day = 10; day >= 1; day--) {
                BehaviorLog log = new BehaviorLog(studentId, LocalDate.now().minusDays(day));
                log.setSleepHours(6 + (day % 3));
                logs.save(log);
            }
            assertEquals(10, logs.findByStudent(studentId).size(), "all entries are stored");
            assertTrue(logs.findRecent(studentId, 5).size() <= 5, "the recent window is bounded");
            assertTrue(logs.findLatest(studentId).isPresent(), "the latest entry is found");
        });

        test("deletes cascade for a student", () -> {
            long studentId = users.findByIdentifier("tester").orElseThrow().getId();
            assertEquals(10, logs.deleteForStudent(studentId), "every log is removed");
            assertTrue(logs.findByStudent(studentId).isEmpty(), "nothing remains");
        });
    }

    /* ------------------------------------------------------------------ */

    private static void routing() {
        suite("HTTP routing");

        Router router = new Router();
        router.group("/api/risk")
                .get("/{studentId}", request -> HttpResponse.ok(JsonObject.of("matched", "byId")))
                .get("/distribution", request -> HttpResponse.ok(JsonObject.of("matched", "distribution")))
                .post("/{studentId}/analyse", request -> HttpResponse.ok(JsonObject.of("matched", "analyse")));

        test("binds path variables", () -> {
            HttpRequest request = get("/api/risk/42");
            assertTrue(router.resolve(request).isPresent(), "the route resolves");
            assertEquals("42", request.pathVariable("studentId"), "the variable is bound");
        });

        test("prefers the more specific literal route", () -> {
            HttpRequest request = get("/api/risk/distribution");
            assertTrue(router.resolve(request).isPresent(), "the route resolves");
            assertEquals("/api/risk/distribution", router.resolve(request).orElseThrow().template(),
                    "the literal template wins over the variable one");
        });

        test("distinguishes verbs on the same path", () -> {
            assertTrue(router.resolve(get("/api/risk/7")).isPresent(), "GET resolves");
            assertFalse(router.resolve(request(HttpMethod.DELETE, "/api/risk/7")).isPresent(),
                    "DELETE does not resolve");
            assertTrue(router.pathExists("/api/risk/7"), "the path is known under another verb");
        });

        test("ignores trailing slashes", () ->
                assertTrue(router.resolve(get("/api/risk/42/")).isPresent(), "a trailing slash still matches"));

        test("does not match unrelated paths", () ->
                assertFalse(router.resolve(get("/api/unknown/42")).isPresent(), "unknown paths return empty"));

        test("parses query strings including encoded values", () -> {
            Map<String, String> query = HttpRequest.parseQuery("q=high%20risk&days=30&flag");
            assertEquals("high risk", query.get("q"), "percent-encoding is decoded");
            assertEquals("30", query.get("days"), "plain values are read");
            assertEquals("", query.get("flag"), "valueless keys are tolerated");
        });
    }

    private static HttpRequest get(String path) {
        return request(HttpMethod.GET, path);
    }

    private static HttpRequest request(HttpMethod method, String path) {
        return new HttpRequest(method, path, Map.of(), Map.of(), "", "127.0.0.1");
    }

    /* ------------------------------------------------------------------ */

    private static void domainModel() {
        suite("Domain model");

        test("risk bands map from the score", () -> {
            assertEquals(RiskLevel.THRIVING, RiskLevel.of(10), "10 is thriving");
            assertEquals(RiskLevel.STABLE, RiskLevel.of(30), "30 is stable");
            assertEquals(RiskLevel.ELEVATED, RiskLevel.of(50), "50 is elevated");
            assertEquals(RiskLevel.HIGH, RiskLevel.of(70), "70 is high");
            assertEquals(RiskLevel.CRITICAL, RiskLevel.of(95), "95 is critical");
            assertTrue(RiskLevel.of(85).requiresIntervention(), "critical requires intervention");
            assertFalse(RiskLevel.of(25).requiresIntervention(), "stable does not");
        });

        test("polymorphism selects the right greeting per role", () -> {
            Student student = new Student("s", "s@x.edu", "Aarthi Krishnan", "h");
            com.welltrack.model.Faculty faculty = new com.welltrack.model.Faculty(
                    "f", "f@x.edu", "Dr. Vignesh T", "h", "E1", "CSE", "Professor");
            assertTrue(student.headline().contains("Aarthi"), "students are greeted by name");
            assertTrue(faculty.headline().contains("CSE"), "faculty see their department");
            assertEquals("AK", student.initials(), "initials are derived from the full name");
        });

        test("feature vector is aligned with its names", () -> {
            BehaviorLog log = new BehaviorLog(1, LocalDate.now());
            log.setSleepHours(5.5);
            log.setStudyHours(9);
            double[] vector = log.toFeatureVector();
            assertEquals(BehaviorLog.FEATURE_NAMES.length, vector.length, "length matches the catalogue");
            assertClose(2.5, vector[1], 1e-9, "sleep debt is derived correctly");
            assertClose(3.0, vector[3], 1e-9, "study overload is derived correctly");
        });

        test("engineered features never go negative", () -> {
            BehaviorLog rested = new BehaviorLog(1, LocalDate.now());
            rested.setSleepHours(9);
            rested.setStudyHours(2);
            double[] vector = rested.toFeatureVector();
            assertClose(0, vector[1], 1e-9, "a well-rested student carries no sleep debt");
            assertClose(0, vector[3], 1e-9, "a light day carries no study overload");
        });

        test("the heuristic separates a healthy day from a punishing one", () -> {
            BehaviorLog healthy = new BehaviorLog(1, LocalDate.now());
            healthy.setSleepHours(8);
            healthy.setStudyHours(4);
            healthy.setStressLevel(2);
            healthy.setMood(Mood.HAPPY);
            healthy.setExerciseMinutes(45);
            healthy.setClassesScheduled(6);
            healthy.setClassesAttended(6);

            BehaviorLog punishing = new BehaviorLog(1, LocalDate.now());
            punishing.setSleepHours(4);
            punishing.setStudyHours(11);
            punishing.setStressLevel(9);
            punishing.setMood(Mood.LOW);
            punishing.setExerciseMinutes(0);
            punishing.setMealsSkipped(3);
            punishing.setClassesScheduled(6);
            punishing.setClassesAttended(2);

            assertLess(healthy.heuristicStrainScore(), 35, "a healthy day scores low");
            assertGreater(punishing.heuristicStrainScore(), 70, "a punishing day scores high");
        });

        test("numeric helpers behave at the boundaries", () -> {
            assertClose(5, Numbers.clamp(9, 0, 5), 1e-9, "clamping caps the value");
            assertClose(0, Numbers.slope(new double[]{4, 4, 4, 4}), 1e-9, "a flat series has no slope");
            assertGreater(Numbers.slope(new double[]{1, 2, 3, 4, 5}), 0.9, "a rising series has a positive slope");
            assertClose(3, Numbers.median(new double[]{5, 1, 3}), 1e-9, "the median ignores ordering");
            assertClose(0, Numbers.percentageChange(0, 0), 1e-9, "zero-to-zero is guarded");
        });
    }

    /* ------------------------------------------------------------------ */

    private static void machineLearning() {
        suite("Machine learning");

        test("the scaler standardises to zero mean and unit variance", () -> {
            double[][] samples = {{2, 100}, {4, 200}, {6, 300}, {8, 400}};
            StandardScaler scaler = new StandardScaler();
            double[][] scaled = scaler.fitTransform(samples);
            double mean = 0;
            for (double[] row : scaled) {
                mean += row[0];
            }
            assertClose(0, mean / scaled.length, 1e-9, "the mean is centred at zero");
            assertClose(5, scaler.meanOf(0), 1e-9, "the learned mean is correct");
        });

        test("the scaler survives a constant column", () -> {
            StandardScaler scaler = new StandardScaler();
            scaler.fit(new double[][]{{1, 7}, {2, 7}, {3, 7}});
            double[] scaled = scaler.transform(new double[]{2, 7});
            assertClose(0, scaled[1], 1e-9, "a constant feature becomes zero rather than infinity");
        });

        test("logistic regression learns a separable problem", () -> {
            Random random = new Random(7);
            double[][] samples = new double[600][2];
            int[] labels = new int[600];
            for (int i = 0; i < 600; i++) {
                boolean positive = i % 2 == 0;
                samples[i][0] = (positive ? 2.4 : -2.4) + random.nextGaussian() * 0.8;
                samples[i][1] = random.nextGaussian();
                labels[i] = positive ? 1 : 0;
            }
            LogisticRegressionModel model = new LogisticRegressionModel(new String[]{"signal", "noise"});
            ModelMetrics metrics = model.train(samples, labels, 240, 0.1, 0.001, 32, 11);
            assertGreater(metrics.accuracy(), 0.9, "accuracy exceeds 90%");
            assertGreater(Math.abs(model.weights()[0]), Math.abs(model.weights()[1]),
                    "the informative feature carries the larger weight");
        });

        test("the sigmoid is numerically stable at the extremes", () -> {
            assertClose(0.5, LogisticRegressionModel.sigmoid(0), 1e-12, "zero maps to one half");
            assertClose(1, LogisticRegressionModel.sigmoid(800), 1e-9, "large positives saturate at one");
            assertClose(0, LogisticRegressionModel.sigmoid(-800), 1e-9, "large negatives saturate at zero");
        });

        test("contributions reconstruct the log-odds exactly", () -> {
            LogisticRegressionModel model = new LogisticRegressionModel(new String[]{"a", "b"});
            double[][] samples = {{1, 0}, {0, 1}, {1, 1}, {0, 0}, {2, 0}, {0, 2}};
            int[] labels = {1, 0, 1, 0, 1, 0};
            model.train(samples, labels, 120, 0.15, 0.001, 4, 3);

            double[] observation = {1.4, 0.3};
            double sum = 0;
            for (double contribution : model.contributions(observation)) {
                sum += contribution;
            }
            double expected = LogisticRegressionModel.sigmoid(sum + model.bias());
            assertClose(expected, model.predict(observation), 1e-9,
                    "the contributions add up to the prediction");
        });

        test("k-means recovers two well-separated clusters", () -> {
            Random random = new Random(5);
            double[][] samples = new double[200][2];
            for (int i = 0; i < 200; i++) {
                double centre = i < 100 ? -5 : 5;
                samples[i][0] = centre + random.nextGaussian() * 0.6;
                samples[i][1] = centre + random.nextGaussian() * 0.6;
            }
            KMeansClusterer clusterer = new KMeansClusterer(100, 5);
            int[] assignments = clusterer.fit(samples, 2);
            assertEquals(assignments[0], assignments[50], "points in the first blob agree");
            assertEquals(assignments[120], assignments[180], "points in the second blob agree");
            assertFalse(assignments[0] == assignments[150], "the blobs are separated");
            assertGreater(clusterer.silhouette(), 0.7, "the silhouette confirms a clean split");
        });

        test("silhouette selection finds the true number of clusters", () -> {
            Random random = new Random(9);
            double[][] samples = new double[150][2];
            for (int i = 0; i < 150; i++) {
                double[] centre = i < 50 ? new double[]{0, 0}
                        : i < 100 ? new double[]{10, 0} : new double[]{5, 9};
                samples[i][0] = centre[0] + random.nextGaussian() * 0.5;
                samples[i][1] = centre[1] + random.nextGaussian() * 0.5;
            }
            KMeansClusterer clusterer = new KMeansClusterer(120, 3);
            assertEquals(3, clusterer.fitBest(samples, 2, 6), "three clusters are chosen");
        });

        test("the training simulator produces a usable class balance", () -> {
            TrainingDataFactory.Dataset dataset = TrainingDataFactory.generate(2000, 1);
            assertEquals(2000, dataset.size(), "the requested number of samples is produced");
            assertGreater(dataset.positiveRate(), 0.20, "there are enough positive examples");
            assertLess(dataset.positiveRate(), 0.60, "the classes are not inverted");
        });

        test("simulated behaviour moves in the researched direction", () -> {
            Random random = new Random(3);
            double healthySleep = 0;
            double strainedSleep = 0;
            for (int i = 0; i < 400; i++) {
                healthySleep += TrainingDataFactory.simulateDay(0.1, random)[0];
                strainedSleep += TrainingDataFactory.simulateDay(0.9, random)[0];
            }
            assertGreater(healthySleep / 400 - strainedSleep / 400, 1.5,
                    "high-propensity students sleep measurably less");
        });
    }

    /* ------------------------------------------------------------------ */

    private static void naturalLanguage() {
        suite("Natural language processing");

        SentimentAnalyzer analyzer = new SentimentAnalyzer();

        test("separates positive from negative journal entries", () -> {
            assertGreater(analyzer.analyse("Slept well and felt productive and calm today").polarity(), 0.2,
                    "a positive entry scores positive");
            assertLess(analyzer.analyse("I am completely exhausted, overwhelmed and anxious").polarity(), -0.2,
                    "a negative entry scores negative");
        });

        test("handles negation rather than counting keywords", () -> {
            double plain = analyzer.analyse("I am happy").polarity();
            double negated = analyzer.analyse("I am not happy").polarity();
            assertGreater(plain, 0, "the plain statement is positive");
            assertLess(negated, plain, "negation reverses the reading");
        });

        test("intensifiers scale the magnitude", () -> {
            double mild = Math.abs(analyzer.analyse("slightly tired").polarity());
            double strong = Math.abs(analyzer.analyse("extremely tired").polarity());
            assertGreater(strong, mild, "'extremely' outweighs 'slightly'");
        });

        test("identifies the dominant emotion channel", () -> {
            assertEquals("exhaustion",
                    analyzer.analyse("I am so tired, no sleep, completely drained and fatigued").dominantEmotion(),
                    "exhaustion is detected");
            assertEquals("isolation",
                    analyzer.analyse("I feel lonely and alone, nobody to talk to, isolated").dominantEmotion(),
                    "isolation is detected");
        });

        test("flags crisis language", () -> {
            assertTrue(analyzer.analyse("I want to give up, there is no point anymore").crisisMarkerDetected(),
                    "distress markers are caught");
            assertFalse(analyzer.analyse("I gave up on the optional assignment").crisisMarkerDetected(),
                    "ordinary usage is not a false alarm");
        });

        test("the tokeniser normalises and stems", () -> {
            List<String> tokens = Tokenizer.normalise("The students are studying and sleeping badly");
            assertFalse(tokens.contains("the"), "stop words are removed");
            assertTrue(tokens.contains("studi") || tokens.contains("study"), "study is stemmed");
            assertEquals(2, Tokenizer.bigrams(List.of("a", "b", "c")).size(), "bigrams are produced");
        });

        test("Naive Bayes classifies intents it was trained on", () -> {
            NaiveBayesIntentClassifier classifier = new NaiveBayesIntentClassifier();
            classifier.trainAll("sleep", "i cannot sleep", "my sleep schedule is broken", "insomnia every night");
            classifier.trainAll("exam", "exams are next week", "i am scared of the exam", "revision for exams");
            assertEquals("sleep", classifier.classify("i cannot sleep at night").intent(), "sleep intent");
            assertEquals("exam", classifier.classify("my exam is coming next week").intent(), "exam intent");
            assertGreater(classifier.classify("i cannot sleep at night").confidence(), 0.5,
                    "the classifier is confident on a clear example");
        });

        test("an unseen word does not zero out the evidence", () -> {
            NaiveBayesIntentClassifier classifier = new NaiveBayesIntentClassifier();
            classifier.trainAll("sleep", "i cannot sleep at night");
            classifier.trainAll("study", "i cannot focus while studying");
            assertNotNull(classifier.classify("sleep zzzxqv").intent(), "Laplace smoothing keeps it working");
        });

        test("TF-IDF retrieval returns the relevant article", () -> {
            TfIdfIndex index = KnowledgeBase.build();
            List<TfIdfIndex.Hit> hits = index.search("i cannot sleep and my schedule is broken", 2);
            assertFalse(hits.isEmpty(), "something is retrieved");
            String title = hits.get(0).document().title().toLowerCase();
            assertTrue(title.contains("sleep"), "the top hit is about sleep, not something unrelated");
        });

        test("retrieval discriminates between topics", () -> {
            TfIdfIndex index = KnowledgeBase.build();
            String examTop = index.search("how do i prepare for my exams", 1).get(0).document().id();
            String socialTop = index.search("i feel lonely and have no friends", 1).get(0).document().id();
            assertFalse(examTop.equals(socialTop), "different questions retrieve different articles");
        });
    }

    /* ------------------------------------------------------------------ */

    private static void forecasting() {
        suite("Forecasting and anomaly detection");

        test("Holt smoothing projects a rising series upward", () -> {
            double[] rising = {30, 33, 35, 38, 41, 45, 48, 52};
            HoltLinearForecaster forecaster = new HoltLinearForecaster();
            forecaster.fit(rising);
            double[] projection = forecaster.forecast(7, 0, 100);
            assertGreater(projection[6], rising[rising.length - 1], "the projection continues upward");
            assertGreater(forecaster.trend(), 0, "a positive trend is learned");
        });

        test("a falling series projects downward", () -> {
            HoltLinearForecaster forecaster = new HoltLinearForecaster();
            forecaster.fit(new double[]{72, 68, 63, 60, 55, 51, 47});
            assertLess(forecaster.forecast(7, 0, 100)[6], 47, "the projection continues downward");
        });

        test("damping prevents runaway extrapolation", () -> {
            HoltLinearForecaster forecaster = new HoltLinearForecaster();
            forecaster.fit(new double[]{10, 20, 30, 40, 50, 60});
            double[] projection = forecaster.forecast(30, 0, 100);
            assertTrue(projection[29] <= 100, "the projection stays inside the valid range");
        });

        test("projections are clamped to the score range", () -> {
            HoltLinearForecaster forecaster = new HoltLinearForecaster();
            forecaster.fit(new double[]{95, 96, 98, 99, 99, 100});
            for (double value : forecaster.forecast(7, 0, 100)) {
                assertTrue(value >= 0 && value <= 100, "every projected point is a valid score");
            }
        });

        test("short histories degrade gracefully", () -> {
            HoltLinearForecaster forecaster = new HoltLinearForecaster();
            forecaster.fit(new double[]{55});
            assertClose(55, forecaster.forecast(3, 0, 100)[0], 1e-9, "a single point holds flat");
        });

        test("the anomaly detector finds an injected outlier", () -> {
            double[] series = {40, 41, 39, 42, 40, 41, 40, 39, 95, 41, 40};
            AnomalyDetector detector = new AnomalyDetector();
            detector.analyse(series);
            assertTrue(detector.hasAnomalies(), "the spike is detected");
            assertTrue(detector.anomalousIndices().contains(8), "the correct index is flagged");
        });

        test("a steady series produces no false alarms", () -> {
            AnomalyDetector detector = new AnomalyDetector();
            detector.analyse(new double[]{40, 41, 39, 42, 40, 41, 40, 39, 41, 40});
            assertFalse(detector.hasAnomalies(), "normal variation is not flagged");
        });

        test("the forecast engine narrates a deterioration", () -> {
            ForecastEngine engine = new ForecastEngine();
            ForecastEngine.Forecast forecast =
                    engine.project(new double[]{30, 34, 38, 43, 47, 52, 56});
            assertEquals(com.welltrack.model.enums.TrendDirection.WORSENING, forecast.direction(),
                    "the direction is worsening");
            assertGreater(forecast.daysUntilHighRisk(), 0, "an upcoming crossing is predicted");
            assertNotNull(forecast.narrative(), "a human-readable narrative is produced");
        });
    }

    /* ------------------------------------------------------------------ */

    private static void endToEndScoring() {
        suite("End-to-end burnout scoring");

        BurnoutPredictor predictor = new BurnoutPredictor();
        predictor.train();

        test("the trained model meets its quality bar", () -> {
            ModelMetrics metrics = predictor.metrics();
            assertGreater(metrics.accuracy(), 0.75, "accuracy is acceptable");
            assertGreater(metrics.recall(), 0.75, "recall is high — missing an at-risk student is the costly error");
            assertGreater(metrics.rocAuc(), 0.85, "ranking quality is strong");
            assertLess(metrics.logLoss(), 0.60, "the model is well calibrated");
            assertFalse(metrics.accuracy() > 0.999, "the problem is not trivially separable");
        });

        test("a thriving profile scores far below a burning-out one", () -> {
            double[] thriving = {8.3, 0, 4.0, 0, 2.5, 55, 140, 2, 0.85, 0.97, 1, 1, 0, 2};
            double[] burning = {4.4, 3.6, 10.0, 4.0, 8.5, 0, 15, 9, 0.10, 0.55, 10, 5, 3, 9};
            double thrivingScore = predictor.toScore(predictor.probability(thriving));
            double burningScore = predictor.toScore(predictor.probability(burning));
            assertLess(thrivingScore, 25, "the healthy profile scores low");
            assertGreater(burningScore, 75, "the struggling profile scores high");
            assertGreater(burningScore - thrivingScore, 50, "the model separates them decisively");
        });

        test("explanations are ranked and human readable", () -> {
            double[] burning = {4.4, 3.6, 10.0, 4.0, 8.5, 0, 15, 9, 0.10, 0.55, 10, 5, 3, 9};
            List<RiskDriver> drivers = predictor.explain(burning, 5);
            assertEquals(5, drivers.size(), "the requested number of drivers is returned");
            assertGreater(drivers.get(0).magnitude(), drivers.get(4).magnitude(), "drivers are ranked");
            drivers.forEach(driver -> {
                assertNotNull(driver.explanation(), "each driver explains itself");
                assertTrue(driver.explanation().length() > 20, "the explanation is a real sentence");
            });
            assertTrue(drivers.stream().anyMatch(RiskDriver::isAggravating),
                    "a struggling profile has aggravating drivers");
        });

        test("recency weighting makes a bad week outweigh a good month", () -> {
            java.util.List<BehaviorLog> window = new java.util.ArrayList<>();
            for (int day = 20; day >= 8; day--) {
                BehaviorLog good = new BehaviorLog(1, LocalDate.now().minusDays(day));
                good.setSleepHours(8.2);
                good.setStudyHours(4);
                good.setStressLevel(2);
                good.setMood(Mood.HAPPY);
                window.add(good);
            }
            for (int day = 7; day >= 1; day--) {
                BehaviorLog bad = new BehaviorLog(1, LocalDate.now().minusDays(day));
                bad.setSleepHours(4.2);
                bad.setStudyHours(11);
                bad.setStressLevel(9);
                bad.setMood(Mood.STRESSED);
                window.add(bad);
            }
            double[] aggregated = predictor.aggregate(window);
            assertLess(aggregated[0], 6.0, "the recent poor sleep dominates the average");
        });

        test("the recommender produces an actionable plan from the explanation", () -> {
            double[] burning = {4.4, 3.6, 10.0, 4.0, 8.5, 0, 15, 9, 0.10, 0.55, 10, 5, 3, 9};
            List<RiskDriver> drivers = predictor.explain(burning, 8);
            RecommendationEngine engine = new RecommendationEngine();
            List<com.welltrack.model.Recommendation> plan =
                    engine.generate(1, drivers, RiskLevel.HIGH, Map.of(), 4);
            assertFalse(plan.isEmpty(), "a plan is produced");
            plan.forEach(item -> {
                assertNotNull(item.getActionStep(), "each item has a concrete step");
                assertTrue(item.getEstimatedRiskReduction() >= 0, "impact is estimated");
            });
        });

        test("a thriving student is told to keep going rather than fix nothing", () -> {
            double[] thriving = {8.3, 0, 4.0, 0, 2.5, 55, 140, 2, 0.85, 0.97, 1, 1, 0, 2};
            RecommendationEngine engine = new RecommendationEngine();
            List<com.welltrack.model.Recommendation> plan = engine.generate(
                    1, predictor.explain(thriving, 8), RiskLevel.THRIVING, Map.of(), 4);
            assertFalse(plan.isEmpty(), "a maintenance message is still produced");
        });

        test("scoring the whole feature space stays inside 0-100", () -> {
            Random random = new Random(21);
            for (int i = 0; i < 300; i++) {
                double[] vector = TrainingDataFactory.simulateDay(random.nextDouble(), random);
                double score = predictor.toScore(predictor.probability(vector));
                assertTrue(score >= 0 && score <= 100, "score " + score + " is within range");
            }
        });
    }
}
