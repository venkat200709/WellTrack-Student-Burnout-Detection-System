/**
 * WellTrack — UI toolkit.
 *
 * DOM helpers, the toast system, number/gauge animation, the login particle
 * field and small interaction niceties (ripples, spotlight cards, count-ups).
 * Everything is written against requestAnimationFrame and respects the user's
 * reduced-motion preference.
 */
(function (global) {
    'use strict';

    const reduceMotion = global.matchMedia('(prefers-reduced-motion: reduce)').matches;

    /* ---------------------------------------------------------------- DOM */

    function el(tag, attributes, children) {
        const node = document.createElement(tag);
        if (attributes) {
            Object.keys(attributes).forEach((key) => {
                const value = attributes[key];
                if (value === null || value === undefined || value === false) { return; }
                if (key === 'class') { node.className = value; }
                else if (key === 'html') { node.innerHTML = value; }
                else if (key === 'text') { node.textContent = value; }
                else if (key === 'style') { node.setAttribute('style', value); }
                else if (key.startsWith('on') && typeof value === 'function') {
                    node.addEventListener(key.slice(2).toLowerCase(), value);
                } else { node.setAttribute(key, value); }
            });
        }
        (children || []).forEach((child) => {
            if (child === null || child === undefined || child === false) { return; }
            node.appendChild(typeof child === 'string' ? document.createTextNode(child) : child);
        });
        return node;
    }

    const $  = (selector, scope) => (scope || document).querySelector(selector);
    const $$ = (selector, scope) => Array.from((scope || document).querySelectorAll(selector));

    function clear(node) {
        while (node && node.firstChild) { node.removeChild(node.firstChild); }
        return node;
    }

    function escapeHtml(value) {
        return String(value === null || value === undefined ? '' : value)
            .replace(/&/g, '&amp;').replace(/</g, '&lt;')
            .replace(/>/g, '&gt;').replace(/"/g, '&quot;');
    }

    /* ------------------------------------------------------------ Numbers */

    function formatNumber(value, decimals) {
        const places = decimals === undefined ? 0 : decimals;
        return Number(value || 0).toFixed(places);
    }

    function relativeTime(isoString) {
        if (!isoString) { return ''; }
        const then = new Date(isoString).getTime();
        const seconds = Math.max(0, Math.floor((Date.now() - then) / 1000));
        if (seconds < 60) { return 'just now'; }
        const minutes = Math.floor(seconds / 60);
        if (minutes < 60) { return minutes + 'm ago'; }
        const hours = Math.floor(minutes / 60);
        if (hours < 24) { return hours + 'h ago'; }
        const days = Math.floor(hours / 24);
        if (days < 7) { return days + 'd ago'; }
        return new Date(isoString).toLocaleDateString();
    }

    /**
     * Animates a numeric value with an ease-out-expo curve. Used for every
     * headline figure so the dashboard "counts up" as it loads.
     */
    function countUp(node, to, options) {
        const settings = options || {};
        const decimals = settings.decimals || 0;
        const suffix = settings.suffix || '';
        const duration = reduceMotion ? 0 : (settings.duration || 1100);
        const from = settings.from !== undefined ? settings.from : 0;

        if (duration === 0) {
            node.textContent = formatNumber(to, decimals) + suffix;
            return;
        }
        const started = performance.now();
        function frame(now) {
            const progress = Math.min(1, (now - started) / duration);
            const eased = 1 - Math.pow(1 - progress, 4);
            node.textContent = formatNumber(from + (to - from) * eased, decimals) + suffix;
            if (progress < 1) { requestAnimationFrame(frame); }
        }
        requestAnimationFrame(frame);
    }

    /* ------------------------------------------------------------- Toasts */

    const toastStack = () => {
        let stack = $('.toast-stack');
        if (!stack) {
            stack = el('div', { class: 'toast-stack' });
            document.body.appendChild(stack);
        }
        return stack;
    };

    const TOAST_STYLES = {
        info:    { glyph: 'ℹ️', colour: 'var(--accent-cyan)' },
        success: { glyph: '✅', colour: 'var(--accent-mint)' },
        warning: { glyph: '⚠️', colour: 'var(--accent-amber)' },
        danger:  { glyph: '🚨', colour: 'var(--accent-rose)' },
        ai:      { glyph: '🧠', colour: 'var(--brand-400)' }
    };

    function toast(title, body, kind, timeout) {
        const style = TOAST_STYLES[kind || 'info'] || TOAST_STYLES.info;
        const node = el('div', { class: 'toast' }, [
            el('span', { class: 'toast__glyph', text: style.glyph }),
            el('div', {}, [
                el('div', { class: 'toast__title', text: title }),
                body ? el('div', { class: 'toast__body', text: body }) : null
            ]),
            el('span', { class: 'toast__progress', style: 'background:' + style.colour })
        ]);
        toastStack().appendChild(node);
        const life = timeout || 5000;
        setTimeout(() => {
            node.classList.add('is-leaving');
            setTimeout(() => node.remove(), 380);
        }, life);
        return node;
    }

    /* ------------------------------------------------------------- Modals */

    function modal(title, subtitle, contentNode, options) {
        const settings = options || {};
        const overlay = el('div', { class: 'overlay' });
        const box = el('div', { class: 'modal' }, [
            el('div', { class: 'modal__title', text: title }),
            subtitle ? el('div', { class: 'modal__sub', text: subtitle }) : null,
            contentNode
        ]);
        overlay.appendChild(box);
        overlay.addEventListener('click', (event) => {
            if (event.target === overlay && !settings.persistent) { close(); }
        });
        function close() {
            overlay.style.animation = 'fadeIn 200ms reverse';
            setTimeout(() => overlay.remove(), 190);
        }
        document.addEventListener('keydown', function onEscape(event) {
            if (event.key === 'Escape') { close(); document.removeEventListener('keydown', onEscape); }
        });
        document.body.appendChild(overlay);
        return { overlay, close };
    }

    /* -------------------------------------------------------- Interaction */

    /** Attaches a click ripple that originates from the pointer position. */
    function bindRipples(scope) {
        $$('.btn', scope).forEach((button) => {
            if (button.dataset.rippleBound) { return; }
            button.dataset.rippleBound = '1';
            button.addEventListener('click', (event) => {
                if (reduceMotion) { return; }
                const rect = button.getBoundingClientRect();
                const size = Math.max(rect.width, rect.height);
                const ripple = el('span', {
                    class: 'ripple',
                    style: 'width:' + size + 'px;height:' + size + 'px;left:'
                        + (event.clientX - rect.left - size / 2) + 'px;top:'
                        + (event.clientY - rect.top - size / 2) + 'px'
                });
                button.appendChild(ripple);
                setTimeout(() => ripple.remove(), 640);
            });
        });
    }

    /** Cursor-tracking sheen for spotlight cards. */
    function bindSpotlights(scope) {
        $$('.card--spotlight', scope).forEach((card) => {
            if (card.dataset.spotlightBound) { return; }
            card.dataset.spotlightBound = '1';
            card.addEventListener('pointermove', (event) => {
                const rect = card.getBoundingClientRect();
                card.style.setProperty('--mx', (event.clientX - rect.left) + 'px');
                card.style.setProperty('--my', (event.clientY - rect.top) + 'px');
            });
        });
    }

    function enhance(scope) {
        bindRipples(scope);
        bindSpotlights(scope);
    }

    /* ----------------------------------------------------------- Particles */

    /**
     * The constellation field behind the sign-in screen: points drift, connect
     * to nearby neighbours and lean gently toward the cursor. Rendered on a
     * single canvas so it costs one composite layer.
     */
    function startParticles(canvas) {
        if (!canvas || reduceMotion) { return function () {}; }
        const context = canvas.getContext('2d');
        let width = 0;
        let height = 0;
        let points = [];
        let pointer = { x: -999, y: -999 };
        let running = true;

        function resize() {
            const ratio = Math.min(2, global.devicePixelRatio || 1);
            width = canvas.clientWidth;
            height = canvas.clientHeight;
            canvas.width = width * ratio;
            canvas.height = height * ratio;
            context.setTransform(ratio, 0, 0, ratio, 0, 0);

            const density = Math.min(120, Math.round((width * height) / 15000));
            points = new Array(density).fill(0).map(() => ({
                x: Math.random() * width,
                y: Math.random() * height,
                vx: (Math.random() - 0.5) * 0.28,
                vy: (Math.random() - 0.5) * 0.28,
                r: Math.random() * 1.9 + 0.7
            }));
        }

        function frame() {
            if (!running) { return; }
            context.clearRect(0, 0, width, height);

            for (let i = 0; i < points.length; i++) {
                const point = points[i];
                point.x += point.vx;
                point.y += point.vy;
                if (point.x < 0 || point.x > width) { point.vx *= -1; }
                if (point.y < 0 || point.y > height) { point.vy *= -1; }

                // Gentle attraction toward the pointer.
                const dx = pointer.x - point.x;
                const dy = pointer.y - point.y;
                const distance = Math.hypot(dx, dy);
                if (distance < 150 && distance > 0.1) {
                    point.x += (dx / distance) * 0.35;
                    point.y += (dy / distance) * 0.35;
                }

                context.beginPath();
                context.arc(point.x, point.y, point.r, 0, Math.PI * 2);
                context.fillStyle = 'rgba(129, 140, 248, 0.65)';
                context.fill();

                for (let j = i + 1; j < points.length; j++) {
                    const other = points[j];
                    const span = Math.hypot(point.x - other.x, point.y - other.y);
                    if (span < 128) {
                        context.beginPath();
                        context.moveTo(point.x, point.y);
                        context.lineTo(other.x, other.y);
                        context.strokeStyle = 'rgba(129, 140, 248, ' + (0.16 * (1 - span / 128)) + ')';
                        context.lineWidth = 1;
                        context.stroke();
                    }
                }
            }
            requestAnimationFrame(frame);
        }

        function onPointerMove(event) { pointer = { x: event.clientX, y: event.clientY }; }
        function onPointerLeave() { pointer = { x: -999, y: -999 }; }

        resize();
        global.addEventListener('resize', resize);
        global.addEventListener('pointermove', onPointerMove);
        global.addEventListener('pointerleave', onPointerLeave);
        requestAnimationFrame(frame);

        return function stop() {
            running = false;
            global.removeEventListener('resize', resize);
            global.removeEventListener('pointermove', onPointerMove);
            global.removeEventListener('pointerleave', onPointerLeave);
        };
    }

    /* --------------------------------------------------------------- Theme */

    const THEME_KEY = 'welltrack.theme';

    function applyTheme(theme) {
        document.documentElement.setAttribute('data-theme', theme);
        localStorage.setItem(THEME_KEY, theme);
    }

    function initTheme() {
        applyTheme(localStorage.getItem(THEME_KEY) || 'dark');
    }

    function toggleTheme() {
        const next = document.documentElement.getAttribute('data-theme') === 'dark' ? 'light' : 'dark';
        applyTheme(next);
        return next;
    }

    /* -------------------------------------------------------------- Export */

    global.WT = global.WT || {};
    global.WT.ui = {
        el, $, $$, clear, escapeHtml,
        formatNumber, relativeTime, countUp,
        toast, modal, enhance, bindRipples, bindSpotlights,
        startParticles, initTheme, toggleTheme, reduceMotion
    };
})(window);
