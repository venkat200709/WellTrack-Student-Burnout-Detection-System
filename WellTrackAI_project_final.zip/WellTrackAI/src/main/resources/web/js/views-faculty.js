/**
 * WellTrack — Faculty, administrator and AI-transparency views.
 */
(function (global) {
    'use strict';

    const WT = global.WT;
    const ui = WT.ui;
    const api = WT.api;
    const charts = WT.charts;
    const esc = ui.escapeHtml;
    const shared = WT.studentViews;

    let rosterState = { rows: [], sortKey: 'score', ascending: false, query: '' };

    /* ====================================================================
       Mentor console
       ==================================================================== */

    async function console_(container) {
        container.innerHTML = shared.skeletonGrid();
        const [overview, priority, timeline, behaviour, alerts] = await Promise.all([
            api.facultyOverview(), api.facultyPriority(), api.facultyTimeline(30),
            api.facultyBehaviour(), api.facultyAlerts()
        ]);

        const distribution = overview.distribution;
        const bands = [
            ['THRIVING', 'Thriving', 'var(--risk-thriving)'],
            ['STABLE', 'Stable', 'var(--risk-stable)'],
            ['ELEVATED', 'Elevated', 'var(--risk-elevated)'],
            ['HIGH', 'High Risk', 'var(--risk-high)'],
            ['CRITICAL', 'Critical', 'var(--risk-critical)']
        ];

        container.innerHTML = `
          <div class="grid grid--kpi">
            ${kpi('Students Monitored', overview.totalStudents, overview.scope === 'institution' ? 'across the institution' : 'assigned as mentees', 'var(--brand-400)')}
            ${kpi('Average Risk', overview.averageScore, 'cohort mean score', 'var(--accent-cyan)')}
            ${kpi('Need Intervention', overview.interventionsNeeded, 'high or critical band', 'var(--accent-rose)')}
            ${kpi('Open Alerts', overview.openAlerts, 'awaiting acknowledgement', 'var(--accent-amber)')}
          </div>

          <div class="grid grid--split">
            <div class="card">
              <div class="card__title"><span class="dot"></span>Cohort Risk Timeline</div>
              <canvas id="cohortTimeline" style="width:100%;height:270px"></canvas>
            </div>
            <div class="card">
              <div class="card__title"><span class="dot"></span>Risk Distribution</div>
              <canvas id="distributionChart" style="width:100%;height:200px"></canvas>
              <div id="distributionLegend" style="margin-top:var(--space-3)"></div>
            </div>
          </div>

          <div class="grid grid--split">
            <div class="card">
              <div class="row row--between" style="margin-bottom:var(--space-4)">
                <div class="card__title" style="margin:0"><span class="dot"></span>Student Roster</div>
                <div class="row">
                  <input id="rosterSearch" class="chat__input" style="padding:7px 14px;font-size:var(--text-sm);width:190px" placeholder="Search students…">
                  <button class="btn btn--ghost btn--sm" id="exportCohort">Export CSV</button>
                </div>
              </div>
              <div class="table-wrap"><table id="rosterTable">
                <thead><tr>
                  <th data-sort="name">Student</th>
                  <th data-sort="score">Burnout Risk</th>
                  <th data-sort="trendLabel">Trend</th>
                  <th data-sort="cohort">Cohort</th>
                  <th data-sort="streak">Streak</th>
                  <th data-sort="attendance">Attendance</th>
                  <th data-sort="lastCheckIn">Last Check-in</th>
                </tr></thead>
                <tbody id="rosterBody"></tbody>
              </table></div>
            </div>

            <div class="stack">
              <div class="card">
                <div class="card__title"><span class="dot"></span>Priority Queue</div>
                <div id="priorityList"></div>
              </div>
              <div class="card">
                <div class="card__title"><span class="dot"></span>Cohort Averages (14 days)</div>
                <div id="behaviourAverages"></div>
              </div>
            </div>
          </div>

          <div class="grid grid--split">
            <div class="card">
              <div class="card__title"><span class="dot"></span>Alert Feed</div>
              <div id="facultyAlerts"></div>
            </div>
            <div class="card">
              <div class="card__title"><span class="dot"></span>Discovered Wellness Cohorts</div>
              <div id="cohortCards"></div>
            </div>
          </div>`;

        // ---- Timeline ----------------------------------------------------
        const series = timeline.series;
        charts.areaChart(document.getElementById('cohortTimeline'), {
            values: series.length ? series.map((point) => point.averageScore) : [overview.averageScore],
            labels: series.map((point) => point.date.slice(5)),
            colour: charts.cssVar('--accent-cyan', '#22d3ee'),
            bands: true, min: 0, max: 100
        });

        // ---- Distribution -------------------------------------------------
        charts.donutChart(document.getElementById('distributionChart'), {
            segments: bands.map(([key, , colour]) => ({ value: distribution[key] || 0, colour: charts.cssVar(colour.slice(4, -1), colour) })),
            caption: 'students'
        });
        document.getElementById('distributionLegend').innerHTML = bands.map(([key, label, colour]) => `
          <div class="lever">
            <span class="row" style="gap:8px"><span class="chip__dot" style="background:${colour}"></span>${label}</span>
            <span class="lever__delta">${distribution[key] || 0}</span>
          </div>`).join('');

        // ---- Roster --------------------------------------------------------
        rosterState = { rows: overview.roster, sortKey: 'score', ascending: false, query: '' };
        drawRoster();

        container.querySelectorAll('#rosterTable th[data-sort]').forEach((header) => {
            header.addEventListener('click', () => {
                const key = header.dataset.sort;
                rosterState.ascending = rosterState.sortKey === key ? !rosterState.ascending : false;
                rosterState.sortKey = key;
                drawRoster();
            });
        });
        container.querySelector('#rosterSearch').addEventListener('input', (event) => {
            rosterState.query = event.target.value.toLowerCase();
            drawRoster();
        });
        container.querySelector('#exportCohort').addEventListener('click', () => {
            global.open('/api/export/cohort?token=' + encodeURIComponent(api.token), '_blank');
            ui.toast('Export started', 'If the download is blocked, allow pop-ups for this page.', 'info');
        });

        // ---- Priority queue -------------------------------------------------
        const queue = priority.queue;
        document.getElementById('priorityList').innerHTML = queue.length
            ? queue.map((item, index) => `
                <div class="alert-item" style="animation-delay:${index * 60}ms">
                  <div class="alert-item__rail" style="background:${item.levelColour}"></div>
                  <div style="flex:1;min-width:0">
                    <div class="row row--between">
                      <div class="alert-item__title">${esc(item.name)}</div>
                      <span class="chip" style="color:${item.levelColour}">${item.score}</span>
                    </div>
                    <div class="alert-item__msg">${esc(item.summary)}</div>
                    <div class="alert-item__time">${esc(item.registerNumber)} · ${esc(item.level)} · ${esc(item.trendLabel)}</div>
                  </div>
                </div>`).join('')
            : shared.emptyState('🌤️', 'Nobody is currently above the contact threshold.');

        // ---- Behaviour averages ---------------------------------------------
        document.getElementById('behaviourAverages').innerHTML = behaviour.samples ? [
            ['Sleep', behaviour.sleepHours, 'hours'],
            ['Study', behaviour.studyHours, 'hours'],
            ['Screen time', behaviour.screenTimeHours, 'hours'],
            ['Stress', behaviour.stressLevel, '/10'],
            ['Exercise', behaviour.exerciseMinutes, 'minutes'],
            ['Attendance', behaviour.attendancePercentage, '%']
        ].map(([label, value, unit]) => `
            <div class="lever"><span>${label}</span>
              <span class="lever__delta">${value} <span class="small muted">${unit}</span></span></div>`).join('')
            + `<div class="small muted" style="margin-top:var(--space-3)">Based on ${behaviour.samples} check-ins.</div>`
            : shared.emptyState('📊', 'No check-ins in the last fortnight.');

        // ---- Alerts ----------------------------------------------------------
        renderFacultyAlerts(document.getElementById('facultyAlerts'), alerts.alerts);

        // ---- Cohort cards ----------------------------------------------------
        const cohorts = overview.cohorts;
        document.getElementById('cohortCards').innerHTML = (cohorts.cohorts || []).length
            ? `<div class="small muted" style="margin-bottom:var(--space-3)">
                 ${cohorts.clusters} cohorts · silhouette ${cohorts.silhouette} · ${esc(cohorts.algorithm)}
               </div>` + cohorts.cohorts.map((cohort) => `
                <div class="rec">
                  <div class="rec__glyph">🧬</div>
                  <div class="rec__body">
                    <div class="rec__title">${esc(cohort.name)}</div>
                    <div class="rec__detail">${esc(cohort.description)}</div>
                    <div class="rec__meta">
                      <span class="chip">${cohort.size} students</span>
                      <span class="chip">average risk ${cohort.averageRisk}</span>
                    </div>
                  </div>
                </div>`).join('')
            : shared.emptyState('🧬', 'Cohorts form once enough students have check-in history.');

        ui.enhance(container);
    }

    function drawRoster() {
        const body = document.getElementById('rosterBody');
        if (!body) { return; }
        const key = rosterState.sortKey;
        const direction = rosterState.ascending ? 1 : -1;

        const rows = rosterState.rows
            .filter((row) => !rosterState.query
                || (row.name || '').toLowerCase().includes(rosterState.query)
                || (row.registerNumber || '').toLowerCase().includes(rosterState.query))
            .slice()
            .sort((a, b) => {
                const left = a[key];
                const right = b[key];
                if (typeof left === 'number' && typeof right === 'number') { return (left - right) * direction; }
                return String(left).localeCompare(String(right)) * direction;
            });

        body.innerHTML = rows.length ? rows.map((row, index) => `
          <tr style="animation-delay:${Math.min(index * 35, 500)}ms">
            <td>
              <div class="person">
                <div class="avatar" style="width:32px;height:32px;font-size:0.68rem">${esc(row.initials)}</div>
                <div>
                  <div style="font-weight:620">${esc(row.name)}</div>
                  <div class="person__meta">${esc(row.registerNumber)} · Year ${row.yearOfStudy}${row.section ? ' · ' + esc(row.section) : ''}</div>
                </div>
              </div>
            </td>
            <td>
              <div class="risk-cell">
                <div class="risk-cell__bar"><div class="risk-cell__fill" data-width="${row.score}" style="background:${row.levelColour}"></div></div>
                <span class="risk-cell__num" style="color:${row.levelColour}">${row.score}</span>
              </div>
              <div class="small muted">${esc(row.levelLabel)}</div>
            </td>
            <td><span class="chip">${row.trend === 'WORSENING' ? '▲' : row.trend === 'IMPROVING' ? '▼' : '▶'} ${esc(row.trendLabel)}</span></td>
            <td class="small">${esc(row.cohort)}</td>
            <td class="tabular">${row.streak}🔥</td>
            <td class="tabular">${row.attendance}%</td>
            <td class="small muted">${esc(row.lastCheckIn)}</td>
          </tr>`).join('')
            : `<tr><td colspan="7">${shared.emptyState('🔍', 'No students match that search.')}</td></tr>`;

        requestAnimationFrame(() => {
            body.querySelectorAll('.risk-cell__fill').forEach((fill) => {
                fill.style.width = fill.dataset.width + '%';
            });
        });
    }

    function renderFacultyAlerts(node, alerts) {
        if (!alerts || !alerts.length) {
            node.innerHTML = shared.emptyState('🔔', 'No alerts in your scope.');
            return;
        }
        node.innerHTML = alerts.slice(0, 12).map((alert, index) => `
          <div class="alert-item ${alert.acknowledged ? 'is-ack' : ''}" style="animation-delay:${index * 50}ms">
            <div class="alert-item__rail" style="background:${alert.severityColour}"></div>
            <div style="flex:1;min-width:0">
              <div class="alert-item__title">${esc(alert.title)}</div>
              <div class="alert-item__msg">${esc(alert.message)}</div>
              <div class="row row--between" style="margin-top:6px">
                <span class="alert-item__time">${esc(alert.studentName)} · ${ui.relativeTime(alert.createdAt)}</span>
                ${alert.acknowledged
                    ? '<span class="chip">✔ ' + esc(alert.acknowledgedBy || 'acknowledged') + '</span>'
                    : '<button class="btn btn--ghost btn--sm" data-ack="' + alert.id + '">Acknowledge</button>'}
              </div>
            </div>
          </div>`).join('');

        node.querySelectorAll('[data-ack]').forEach((button) => {
            button.addEventListener('click', async () => {
                button.disabled = true;
                try {
                    await api.acknowledgeAlert(button.dataset.ack);
                    button.closest('.alert-item').classList.add('is-ack');
                    button.replaceWith(Object.assign(document.createElement('span'),
                        { className: 'chip', textContent: '✔ acknowledged' }));
                    ui.toast('Alert acknowledged', '', 'success');
                } catch (error) {
                    ui.toast('Failed', error.message, 'danger');
                    button.disabled = false;
                }
            });
        });
    }

    function kpi(label, value, meta, colour) {
        return `
          <div class="card kpi card--interactive card--spotlight">
            <div class="kpi__glow" style="background:${colour}"></div>
            <div class="kpi__label">${esc(label)}</div>
            <div class="kpi__value" style="color:${colour}" data-count="${value}">0</div>
            <div class="kpi__meta">${esc(meta)}</div>
          </div>`;
    }

    /* ====================================================================
       AI Lab — full model transparency
       ==================================================================== */

    async function aiLab(container) {
        container.innerHTML = shared.skeletonGrid();
        const [model, capabilities, cohorts] = await Promise.all([
            api.aiModel(), api.aiCapabilities(), api.aiCohorts()
        ]);

        const burnout = model.burnoutModel;
        const metrics = burnout.model.metrics || {};
        const coefficients = (burnout.model.coefficients || []).slice()
            .sort((a, b) => b.influence - a.influence);

        container.innerHTML = `
          <div>
            <div class="section-title">Model Transparency Lab</div>
            <div class="section-sub">${esc(capabilities.engine)} · ${capabilities.externalDependencies} external dependencies</div>
          </div>

          <div class="grid grid--kpi">
            ${kpi('Accuracy', (metrics.accuracy * 100).toFixed(1), 'hold-out validation split', 'var(--accent-mint)')}
            ${kpi('Recall', (metrics.recall * 100).toFixed(1), 'at-risk students correctly flagged', 'var(--accent-cyan)')}
            ${kpi('ROC-AUC', metrics.rocAuc, 'ranking quality', 'var(--brand-400)')}
            ${kpi('Training Samples', burnout.trainingSamples, 'trained in ' + burnout.trainingMillis + ' ms', 'var(--accent-amber)')}
          </div>

          <div class="grid grid--split">
            <div class="card">
              <div class="card__title"><span class="dot"></span>Learned Coefficients</div>
              <p class="small muted" style="margin-bottom:var(--space-4)">
                ${esc(burnout.model.algorithm)} · decision threshold ${burnout.model.decisionThreshold}
                (tuned for F1 rather than left at 0.5).
              </p>
              <div id="coefficientList"></div>
            </div>

            <div class="stack">
              <div class="card">
                <div class="card__title"><span class="dot"></span>Confusion Matrix</div>
                <div class="grid" style="grid-template-columns:1fr 1fr;gap:var(--space-3)">
                  ${matrixCell('True Positives', metrics.truePositives, 'var(--accent-mint)', 'Correctly flagged at-risk')}
                  ${matrixCell('False Positives', metrics.falsePositives, 'var(--accent-amber)', 'Flagged but were fine')}
                  ${matrixCell('False Negatives', metrics.falseNegatives, 'var(--accent-rose)', 'Missed — the costly error')}
                  ${matrixCell('True Negatives', metrics.trueNegatives, 'var(--accent-cyan)', 'Correctly cleared')}
                </div>
                <div class="lever" style="margin-top:var(--space-4)"><span>Precision</span><span class="lever__delta">${(metrics.precision * 100).toFixed(1)}%</span></div>
                <div class="lever"><span>F1 score</span><span class="lever__delta">${(metrics.f1 * 100).toFixed(1)}%</span></div>
                <div class="lever"><span>Balanced accuracy</span><span class="lever__delta">${(metrics.balancedAccuracy * 100).toFixed(1)}%</span></div>
                <div class="lever"><span>Log loss</span><span class="lever__delta">${metrics.logLoss}</span></div>
              </div>

              <div class="card">
                <div class="card__title"><span class="dot"></span>Ensemble Weighting</div>
                <canvas id="ensembleChart" style="width:100%;height:190px"></canvas>
              </div>
            </div>
          </div>

          <div class="card">
            <div class="card__title"><span class="dot"></span>Engine Capability Stack</div>
            <div class="grid grid--thirds" id="capabilityGrid"></div>
          </div>

          <div class="grid grid--split">
            <div class="card">
              <div class="card__title"><span class="dot"></span>Cohort Clustering</div>
              <canvas id="cohortScatter" style="width:100%;height:250px"></canvas>
              <div class="small muted" style="margin-top:var(--space-3)">
                ${esc(cohorts.algorithm)} · ${cohorts.clusters} clusters · silhouette ${cohorts.silhouette}
              </div>
            </div>
            <div class="card">
              <div class="card__title"><span class="dot"></span>Natural Language Stack</div>
              <div class="lever"><span>Intent classifier</span><span class="lever__delta">${esc(model.coach.intentClassifier.algorithm.split('(')[0])}</span></div>
              <div class="lever"><span>Trained intents</span><span class="lever__delta">${model.coach.intentClassifier.intents}</span></div>
              <div class="lever"><span>Training examples</span><span class="lever__delta">${model.coach.intentClassifier.trainingExamples}</span></div>
              <div class="lever"><span>Vocabulary size</span><span class="lever__delta">${model.coach.intentClassifier.vocabulary}</span></div>
              <div class="lever"><span>Knowledge articles</span><span class="lever__delta">${model.coach.knowledgeArticles}</span></div>
              <div class="lever"><span>Intervention library</span><span class="lever__delta">${model.recommendationKnowledgeBase}</span></div>
              <div class="lever"><span>Analysis window</span><span class="lever__delta">${model.analysisWindowDays} days</span></div>
              <div class="lever"><span>External LLM</span><span class="lever__delta">${model.coach.llmEnabled ? esc(model.coach.llmModel) : 'disabled (fully offline)'}</span></div>
            </div>
          </div>`;

        const strongest = Math.max.apply(null, coefficients.map((item) => item.influence)) || 1;
        document.getElementById('coefficientList').innerHTML = coefficients.map((item) => `
          <div class="driver">
            <div class="driver__head">
              <span class="driver__label mono">${esc(item.feature)}</span>
              <span class="driver__value">${item.weight > 0 ? '+' : ''}${item.weight}</span>
            </div>
            <div class="driver__track">
              <div class="driver__fill driver__fill--${item.weight > 0 ? 'up' : 'down'}"
                   data-width="${(item.influence / strongest * 100).toFixed(1)}"></div>
            </div>
            <div class="driver__why">${esc(item.direction)}</div>
          </div>`).join('');
        requestAnimationFrame(() => {
            document.querySelectorAll('#coefficientList .driver__fill').forEach((fill, index) => {
                setTimeout(() => { fill.style.width = fill.dataset.width + '%'; }, index * 55);
            });
        });

        charts.barChart(document.getElementById('ensembleChart'), {
            values: [50, 25, 15, 10],
            labels: ['Model', 'Rules', 'Anomaly', 'Trend'],
            colours: [charts.cssVar('--brand-400'), charts.cssVar('--accent-cyan'),
                      charts.cssVar('--accent-magenta'), charts.cssVar('--accent-amber')]
        });

        document.getElementById('capabilityGrid').innerHTML = capabilities.capabilities.map((item) => `
          <div class="rec">
            <div class="rec__glyph">${item.glyph}</div>
            <div class="rec__body">
              <div class="rec__title">${esc(item.name)}</div>
              <div class="rec__detail">${esc(item.description)}</div>
            </div>
          </div>`).join('');

        // Scatter: place students by risk against streak, coloured by band.
        try {
            const overview = await api.facultyOverview();
            charts.scatterChart(document.getElementById('cohortScatter'), {
                points: overview.roster.map((row) => ({
                    x: row.attendance, y: row.score, colour: row.levelColour
                })),
                xLabel: 'Attendance %', yLabel: 'Burnout score'
            });
        } catch (error) {
            document.getElementById('cohortScatter').replaceWith(
                Object.assign(document.createElement('div'), {
                    className: 'empty', textContent: 'Cohort map is available to faculty accounts.'
                }));
        }

        ui.enhance(container);
    }

    function matrixCell(label, value, colour, hint) {
        return `
          <div style="padding:var(--space-3);border-radius:var(--radius-md);border:1px solid var(--border-subtle);background:var(--surface-1)">
            <div class="kpi__label">${label}</div>
            <div style="font-size:var(--text-2xl);font-weight:740;color:${colour}">${value}</div>
            <div class="small muted">${hint}</div>
          </div>`;
    }

    /* ====================================================================
       System console (administrator)
       ==================================================================== */

    async function system(container) {
        container.innerHTML = shared.skeletonGrid();
        const [metrics, audit, health] = await Promise.all([
            api.systemMetrics(), api.auditTrail(), api.systemHealth()
        ]);

        container.innerHTML = `
          <div>
            <div class="section-title">System Console</div>
            <div class="section-sub">${esc(health.application)} v${esc(health.version)} · Java ${esc(health.javaVersion)} · ${esc(health.datastore)}</div>
          </div>

          <div class="grid grid--kpi">
            ${kpi('Requests Served', metrics.http.requests, metrics.http.errors + ' errors', 'var(--brand-400)')}
            ${kpi('Heap Used', metrics.jvm.usedMemoryMb, 'of ' + metrics.jvm.maxMemoryMb + ' MB', 'var(--accent-cyan)')}
            ${kpi('Live Listeners', metrics.realtime.liveListeners, metrics.realtime.eventsPublished + ' events published', 'var(--accent-mint)')}
            ${kpi('Active Sessions', metrics.realtime.activeSessions, 'signed-in users', 'var(--accent-amber)')}
          </div>

          <div class="grid grid--split">
            <div class="card">
              <div class="card__title"><span class="dot"></span>Security Audit Trail</div>
              <div class="table-wrap"><table>
                <thead><tr><th>When</th><th>Actor</th><th>Action</th><th>Detail</th><th>Result</th></tr></thead>
                <tbody>
                  ${audit.events.map((event, index) => `
                    <tr style="animation-delay:${Math.min(index * 25, 400)}ms">
                      <td class="small muted">${ui.relativeTime(event.occurredAt)}</td>
                      <td class="mono">${esc(event.actor)}</td>
                      <td><span class="chip">${esc(event.action)}</span></td>
                      <td class="small">${esc(event.detail)}</td>
                      <td>${event.successful
                          ? '<span class="chip" style="color:var(--accent-mint)">✔</span>'
                          : '<span class="chip" style="color:var(--accent-rose)">✖</span>'}</td>
                    </tr>`).join('')}
                </tbody>
              </table></div>
            </div>

            <div class="stack">
              <div class="card">
                <div class="card__title"><span class="dot"></span>Runtime</div>
                <div class="lever"><span>Uptime</span><span class="lever__delta">${Math.floor(metrics.jvm.uptimeSeconds / 60)} min</span></div>
                <div class="lever"><span>Threads</span><span class="lever__delta">${metrics.jvm.threadCount}</span></div>
                <div class="lever"><span>Processors</span><span class="lever__delta">${metrics.jvm.availableProcessors}</span></div>
                <div class="lever"><span>HTTP port</span><span class="lever__delta">${metrics.http.port}</span></div>
                <div class="lever"><span>Server uptime</span><span class="lever__delta">${metrics.http.uptimeSeconds}s</span></div>
              </div>
              <div class="card">
                <div class="card__title"><span class="dot"></span>Domain Data</div>
                <div class="lever"><span>Users</span><span class="lever__delta">${metrics.domain.users}</span></div>
                <div class="lever"><span>Students</span><span class="lever__delta">${metrics.domain.students}</span></div>
                <div class="lever"><span>Behaviour logs</span><span class="lever__delta">${metrics.domain.behaviourLogs}</span></div>
                <div class="lever"><span>Audit events</span><span class="lever__delta">${metrics.domain.auditEvents}</span></div>
              </div>
              <div class="card">
                <div class="card__title"><span class="dot"></span>Department Breakdown</div>
                <div id="departmentList"></div>
              </div>
            </div>
          </div>`;

        try {
            const departments = await api.departments();
            document.getElementById('departmentList').innerHTML = departments.departments.map((row) => `
              <div class="lever">
                <span>${esc(row.department)} <span class="small muted">(${row.students})</span></span>
                <span class="lever__delta">${row.averageScore} · ${row.atRisk} at risk</span>
              </div>`).join('');
        } catch (error) {
            document.getElementById('departmentList').innerHTML =
                shared.emptyState('🏛️', 'Department data requires an administrator account.');
        }

        ui.enhance(container);
    }

    global.WT = global.WT || {};
    global.WT.facultyViews = { console: console_, aiLab, system };
})(window);
