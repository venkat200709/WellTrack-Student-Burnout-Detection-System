/**
 * WellTrack — Application shell.
 *
 * Owns authentication, the navigation shell, client-side routing, the live
 * event stream and the command palette. Views are plain functions registered in
 * ROUTES; navigating simply swaps the view container's contents, which keeps
 * transitions instant.
 */
(function (global) {
    'use strict';

    const WT = global.WT;
    const ui = WT.ui;
    const api = WT.api;
    const el = ui.el;

    WT.state = { user: null, dashboard: null, stream: null, view: 'overview' };

    const ICONS = {
        overview: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><rect x="3" y="3" width="7" height="9" rx="2"/><rect x="14" y="3" width="7" height="5" rx="2"/><rect x="14" y="12" width="7" height="9" rx="2"/><rect x="3" y="16" width="7" height="5" rx="2"/></svg>',
        checkIn:  '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><rect x="3" y="5" width="18" height="16" rx="3"/><path d="M8 3v4M16 3v4M8 14l3 3 5-6"/></svg>',
        insights: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M12 3a6 6 0 0 0-3.6 10.8V17a1 1 0 0 0 1 1h5.2a1 1 0 0 0 1-1v-3.2A6 6 0 0 0 12 3Z"/><path d="M10 21h4"/></svg>',
        coach:    '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M21 12a8 8 0 1 1-3.2-6.4"/><path d="M8 21l-3 1 1-4"/><circle cx="9" cy="12" r="1"/><circle cx="13" cy="12" r="1"/><circle cx="17" cy="12" r="1"/></svg>',
        plan:     '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><circle cx="12" cy="12" r="9"/><circle cx="12" cy="12" r="4.5"/><circle cx="12" cy="12" r="1"/></svg>',
        console:  '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M3 20h18"/><rect x="4" y="11" width="4" height="7" rx="1"/><rect x="10" y="6" width="4" height="12" rx="1"/><rect x="16" y="9" width="4" height="9" rx="1"/></svg>',
        aiLab:    '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M9 3v6l-5 9a2 2 0 0 0 1.8 3h12.4a2 2 0 0 0 1.8-3l-5-9V3"/><path d="M8 3h8"/></svg>',
        system:   '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><rect x="3" y="4" width="18" height="7" rx="2"/><rect x="3" y="13" width="18" height="7" rx="2"/><path d="M7 7.5h.01M7 16.5h.01"/></svg>'
    };

    const ROUTES = {
        overview: { label: 'Overview',     title: 'Wellness Overview',  subtitle: 'Your live burnout analysis', roles: ['STUDENT'], render: () => WT.studentViews.overview },
        checkIn:  { label: 'Daily Check-in', title: 'Daily Check-in',   subtitle: 'Sixty seconds keeps the model accurate', roles: ['STUDENT'], render: () => WT.studentViews.checkIn },
        insights: { label: 'Insights',     title: 'Predictive Insights',        subtitle: 'Explainability and the what-if simulator', roles: ['STUDENT'], render: () => WT.studentViews.insights },
        coach:    { label: 'Coach',        title: 'Wellness Coach',  subtitle: 'Grounded in your own data', roles: ['STUDENT'], render: () => WT.studentViews.coach },
        plan:     { label: 'Recovery Plan',title: 'Recovery Plan',      subtitle: 'Actions, badges and standing', roles: ['STUDENT'], render: () => WT.studentViews.plan },
        console:  { label: 'Mentor Console', title: 'Mentor Console',   subtitle: 'Cohort-wide early warning', roles: ['FACULTY', 'ADMIN'], render: () => WT.facultyViews.console },
        aiLab:    { label: 'Model Lab',    title: 'Model Transparency Lab',subtitle: 'Model weights, metrics and behaviour', roles: ['STUDENT', 'FACULTY', 'ADMIN'], render: () => WT.facultyViews.aiLab },
        system:   { label: 'System',       title: 'System Console',     subtitle: 'Runtime, security and audit', roles: ['ADMIN'], render: () => WT.facultyViews.system }
    };

    /* ==================================================================== */
    /* Authentication                                                       */
    /* ==================================================================== */

    function showAuth() {
        const root = document.getElementById('root');
        root.innerHTML = `
          <canvas id="particles"></canvas>
          <div class="auth">
            <div class="auth__hero">
              <div class="brandmark">
                <div class="brandmark__logo">
                  <svg width="26" height="26" viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="2" stroke-linecap="round">
                    <path d="M3 13h3l2.5-7 4 14 2.5-7h3"/>
                  </svg>
                </div>
                <div>
                  <div class="brandmark__name">WellTrack</div>
                  <div class="brandmark__tag">Wellness Intelligence</div>
                </div>
              </div>
              <h1 class="auth__title">Catch burnout <span class="gradient-text">weeks before</span> the grades do.</h1>
              <p class="auth__lede">
                WellTrack reads a student's sleep, study rhythm, mood and attendance, predicts burnout with an
                explainable model, and turns the result into one concrete action for tomorrow.
              </p>
              <div class="stat-strip">
                <div class="stat-strip__item">
                  <div class="stat-strip__value gradient-text" id="statAccuracy">—</div>
                  <div class="stat-strip__label">Model accuracy</div>
                </div>
                <div class="stat-strip__item">
                  <div class="stat-strip__value gradient-text">10</div>
                  <div class="stat-strip__label">engine capabilities</div>
                </div>
                <div class="stat-strip__item">
                  <div class="stat-strip__value gradient-text">0</div>
                  <div class="stat-strip__label">External dependencies</div>
                </div>
              </div>
            </div>

            <div class="auth__panel glass">
              <div class="tabs">
                <div class="tabs__indicator" id="tabIndicator"></div>
                <button class="tabs__button is-active" data-tab="login">Sign in</button>
                <button class="tabs__button" data-tab="register">Create account</button>
              </div>

              <form id="loginForm">
                <div class="field">
                  <input id="loginId" placeholder=" " autocomplete="username">
                  <label>Username or email</label>
                  <span class="field__error"></span>
                </div>
                <div class="field">
                  <input id="loginPassword" type="password" placeholder=" " autocomplete="current-password">
                  <label>Password</label>
                  <span class="field__error"></span>
                </div>
                <button type="submit" class="btn btn--primary btn--block" id="loginButton">Sign in securely</button>
                <p class="small muted center" style="margin-top:var(--space-3)">
                  PBKDF2-SHA256 · signed session tokens · lockout after 5 failed attempts
                </p>
              </form>

              <form id="registerForm" class="hidden">
                <div class="field">
                  <input id="regFullName" placeholder=" " autocomplete="name">
                  <label>Full name</label><span class="field__error"></span>
                </div>
                <div class="field">
                  <input id="regUsername" placeholder=" " autocomplete="username">
                  <label>Username</label><span class="field__error"></span>
                </div>
                <div class="field">
                  <input id="regEmail" type="email" placeholder=" " autocomplete="email">
                  <label>Email address</label><span class="field__error"></span>
                </div>
                <div class="field">
                  <input id="regRegisterNumber" placeholder=" ">
                  <label>Register number</label><span class="field__error"></span>
                </div>
                <div class="row" style="gap:var(--space-3)">
                  <div class="field" style="flex:1">
                    <input id="regDepartment" placeholder=" " value="CSE">
                    <label>Department</label><span class="field__error"></span>
                  </div>
                  <div class="field" style="width:96px">
                    <input id="regSection" placeholder=" " value="A">
                    <label>Section</label><span class="field__error"></span>
                  </div>
                  <div class="field" style="width:96px">
                    <input id="regYear" type="number" min="1" max="5" placeholder=" " value="3">
                    <label>Year</label><span class="field__error"></span>
                  </div>
                </div>
                <div class="field">
                  <input id="regPassword" type="password" placeholder=" " autocomplete="new-password">
                  <label>Password</label><span class="field__error"></span>
                </div>
                <div class="strength">
                  <div class="strength__track"><div class="strength__fill" id="strengthFill"></div></div>
                  <span class="strength__label" id="strengthLabel">At least 8 characters with upper, lower and a digit</span>
                </div>
                <div class="field">
                  <input id="regConfirm" type="password" placeholder=" " autocomplete="new-password">
                  <label>Confirm password</label><span class="field__error"></span>
                </div>
                <button type="submit" class="btn btn--primary btn--block" id="registerButton">Create my account</button>
              </form>

              <div class="demo-accounts">
                <div class="demo-accounts__title">Demonstration accounts — click to fill</div>
                <div class="demo-accounts__grid">
                  ${demoAccount('Student', 'venkat', 'Student@2026')}
                  ${demoAccount('Faculty', 'vignesh', 'Faculty@2026')}
                  ${demoAccount('Admin', 'admin', 'Admin@2026')}
                </div>
              </div>
            </div>
          </div>`;

        WT.state.stopParticles = ui.startParticles(document.getElementById('particles'));
        ui.enhance(root);
        wireAuth();

        // Show the model's genuine hold-out accuracy rather than a slogan.
        api.aiCapabilities().then((capabilities) => {
            const node = document.getElementById('statAccuracy');
            if (!node) { return; }
            if (capabilities.modelReady && capabilities.accuracy) {
                ui.countUp(node, capabilities.accuracy, { decimals: 1, suffix: '%' });
            } else {
                node.textContent = 'training…';
            }
            const count = document.querySelectorAll('.stat-strip__item')[1];
            if (count) {
                ui.countUp(count.querySelector('.stat-strip__value'), capabilities.capabilities.length);
            }
        }).catch(() => {});
    }

    function demoAccount(role, username, password) {
        return `<button class="demo-account" data-user="${username}" data-pass="${password}">
                  <span class="demo-account__role">${role}</span>
                  <span class="demo-account__user">${username}</span>
                </button>`;
    }

    function wireAuth() {
        const root = document.getElementById('root');
        const indicator = root.querySelector('#tabIndicator');
        const loginForm = root.querySelector('#loginForm');
        const registerForm = root.querySelector('#registerForm');

        root.querySelectorAll('.tabs__button').forEach((button) => {
            button.addEventListener('click', () => {
                root.querySelectorAll('.tabs__button').forEach((other) => other.classList.remove('is-active'));
                button.classList.add('is-active');
                const isRegister = button.dataset.tab === 'register';
                indicator.classList.toggle('is-right', isRegister);
                loginForm.classList.toggle('hidden', isRegister);
                registerForm.classList.toggle('hidden', !isRegister);
            });
        });

        root.querySelectorAll('.demo-account').forEach((button) => {
            button.addEventListener('click', () => {
                root.querySelector('#loginId').value = button.dataset.user;
                root.querySelector('#loginPassword').value = button.dataset.pass;
                root.querySelector('#loginId').dispatchEvent(new Event('input'));
                loginForm.requestSubmit();
            });
        });

        loginForm.addEventListener('submit', async (event) => {
            event.preventDefault();
            clearFieldErrors(loginForm);
            const button = root.querySelector('#loginButton');
            button.disabled = true;
            button.textContent = 'Verifying…';
            try {
                const result = await api.login(
                    root.querySelector('#loginId').value.trim(),
                    root.querySelector('#loginPassword').value);
                api.setToken(result.token);
                ui.toast(result.message, 'Signed in as ' + result.user.roleLabel, 'success');
                enterApp(result.user);
            } catch (error) {
                applyFieldErrors(loginForm, error, { identifier: '#loginId', password: '#loginPassword' });
                root.querySelector('.auth__panel').classList.add('shake');
                setTimeout(() => root.querySelector('.auth__panel').classList.remove('shake'), 640);
                if (!Object.keys(error.fieldErrors || {}).length) {
                    ui.toast('Sign-in failed', error.message, 'danger');
                }
                button.disabled = false;
                button.textContent = 'Sign in securely';
            }
        });

        // Live password-strength meter — scored by the server so the policy has
        // exactly one definition.
        let strengthTimer = null;
        root.querySelector('#regPassword').addEventListener('input', (event) => {
            clearTimeout(strengthTimer);
            const password = event.target.value;
            strengthTimer = setTimeout(async () => {
                if (!password) {
                    root.querySelector('#strengthFill').style.width = '0';
                    return;
                }
                try {
                    const result = await api.passwordStrength(password);
                    root.querySelector('#strengthFill').style.width = result.score + '%';
                    root.querySelector('#strengthLabel').textContent =
                        result.label + (result.meetsPolicy ? ' · meets policy' : ' · does not meet policy yet');
                } catch (error) { /* non-critical */ }
            }, 220);
        });

        registerForm.addEventListener('submit', async (event) => {
            event.preventDefault();
            clearFieldErrors(registerForm);
            const button = root.querySelector('#registerButton');
            button.disabled = true;
            button.textContent = 'Creating…';
            try {
                const result = await api.register({
                    fullName: root.querySelector('#regFullName').value.trim(),
                    username: root.querySelector('#regUsername').value.trim(),
                    email: root.querySelector('#regEmail').value.trim(),
                    registerNumber: root.querySelector('#regRegisterNumber').value.trim(),
                    department: root.querySelector('#regDepartment').value.trim(),
                    section: root.querySelector('#regSection').value.trim(),
                    yearOfStudy: Number(root.querySelector('#regYear').value),
                    password: root.querySelector('#regPassword').value,
                    confirmPassword: root.querySelector('#regConfirm').value
                });
                api.setToken(result.token);
                ui.toast(result.message, 'Log your first check-in to activate the analysis.', 'success', 7000);
                enterApp(result.user);
            } catch (error) {
                applyFieldErrors(registerForm, error, {
                    fullName: '#regFullName', username: '#regUsername', email: '#regEmail',
                    registerNumber: '#regRegisterNumber', password: '#regPassword',
                    confirmPassword: '#regConfirm', yearOfStudy: '#regYear'
                });
                if (!Object.keys(error.fieldErrors || {}).length) {
                    ui.toast('Registration failed', error.message, 'danger');
                }
                button.disabled = false;
                button.textContent = 'Create my account';
            }
        });
    }

    function clearFieldErrors(form) {
        form.querySelectorAll('.field').forEach((field) => {
            field.classList.remove('has-error');
            const error = field.querySelector('.field__error');
            if (error) { error.textContent = ''; }
        });
    }

    function applyFieldErrors(form, error, mapping) {
        const fieldErrors = error.fieldErrors || {};
        Object.keys(fieldErrors).forEach((key) => {
            const selector = mapping[key];
            if (!selector) { return; }
            const input = form.querySelector(selector);
            if (!input) { return; }
            const field = input.closest('.field');
            field.classList.add('has-error');
            const node = field.querySelector('.field__error');
            if (node) { node.textContent = fieldErrors[key]; }
        });
    }

    /* ==================================================================== */
    /* Application shell                                                    */
    /* ==================================================================== */

    function enterApp(user) {
        if (WT.state.stopParticles) { WT.state.stopParticles(); WT.state.stopParticles = null; }
        WT.state.user = user;
        const root = document.getElementById('root');
        root.style.animation = 'fadeIn 400ms ease';

        const allowed = Object.keys(ROUTES).filter((key) => ROUTES[key].roles.includes(user.role));
        const initial = allowed.includes('overview') ? 'overview' : allowed[0];

        root.innerHTML = `
          <div class="app">
            <aside class="sidebar" id="sidebar">
              <div class="sidebar__brand">
                <div class="sidebar__logo">
                  <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="2.2" stroke-linecap="round">
                    <path d="M3 13h3l2.5-7 4 14 2.5-7h3"/>
                  </svg>
                </div>
                <div>
                  <div class="sidebar__name">WellTrack</div>
                  <div class="sidebar__sub">${ui.escapeHtml(user.roleLabel)}</div>
                </div>
              </div>

              <nav class="nav" id="nav">
                <div class="nav__section">Workspace</div>
                ${allowed.map((key) => `
                  <button class="nav__item" data-route="${key}">
                    ${ICONS[key] || ''}<span>${ROUTES[key].label}</span>
                    ${key === 'console' ? '<span class="nav__badge hidden" id="alertBadge">0</span>' : ''}
                  </button>`).join('')}
              </nav>

              <div class="sidebar__footer">
                <div class="user-chip" id="userChip">
                  <div class="avatar">${ui.escapeHtml(user.initials)}</div>
                  <div style="flex:1;min-width:0">
                    <div class="user-chip__name">${ui.escapeHtml(user.fullName)}</div>
                    <div class="user-chip__role">${ui.escapeHtml(user.profileSummary)}</div>
                  </div>
                </div>
                <button class="btn btn--ghost btn--sm btn--block" id="signOut" style="margin-top:var(--space-2)">Sign out</button>
              </div>
            </aside>

            <div class="main">
              <header class="topbar">
                <button class="icon-btn" id="menuToggle" style="display:none">
                  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M4 7h16M4 12h16M4 17h16"/></svg>
                </button>
                <div>
                  <div class="topbar__title" id="viewTitle">${ROUTES[initial].title}</div>
                  <div class="topbar__subtitle" id="viewSubtitle">${ROUTES[initial].subtitle}</div>
                </div>
                <div class="topbar__spacer"></div>
                <span class="live-pill is-offline" id="livePill"><span class="live-pill__dot"></span><span id="liveText">connecting</span></span>
                <button class="icon-btn tooltip" data-tip="Command palette (Ctrl+K)" id="paletteButton">
                  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><circle cx="11" cy="11" r="7"/><path d="m20 20-3.2-3.2"/></svg>
                </button>
                <button class="icon-btn tooltip" data-tip="Refresh analysis" id="refreshButton">
                  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M21 12a9 9 0 1 1-2.6-6.4"/><path d="M21 4v5h-5"/></svg>
                </button>
                <button class="icon-btn tooltip" data-tip="Toggle theme" id="themeButton">
                  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M21 12.8A9 9 0 1 1 11.2 3a7 7 0 0 0 9.8 9.8Z"/></svg>
                </button>
              </header>
              <main class="view" id="view"></main>
            </div>
          </div>`;

        document.getElementById('signOut').addEventListener('click', signOut);
        document.getElementById('themeButton').addEventListener('click', () => {
            const theme = ui.toggleTheme();
            ui.toast('Theme switched', 'Now using the ' + theme + ' theme', 'info', 2600);
            navigate(WT.state.view);
        });
        document.getElementById('refreshButton').addEventListener('click', async () => {
            ui.toast('Re-analysing', 'Running the full scoring pipeline…', 'ai', 2600);
            try {
                if (user.role === 'STUDENT') { await api.reanalyse(user.id); }
                navigate(WT.state.view);
            } catch (error) {
                ui.toast('Refresh failed', error.message, 'danger');
            }
        });
        document.getElementById('paletteButton').addEventListener('click', openPalette);
        document.getElementById('menuToggle').addEventListener('click', () =>
            document.getElementById('sidebar').classList.toggle('is-open'));

        document.querySelectorAll('[data-route]').forEach((button) =>
            button.addEventListener('click', () => navigate(button.dataset.route)));

        if (global.matchMedia('(max-width: 980px)').matches) {
            document.getElementById('menuToggle').style.display = 'grid';
        }

        ui.enhance(root);
        connectStream();
        navigate(initial);
    }

    async function navigate(routeKey) {
        const route = ROUTES[routeKey];
        if (!route || !route.roles.includes(WT.state.user.role)) { return; }
        WT.state.view = routeKey;

        document.querySelectorAll('.nav__item').forEach((item) =>
            item.classList.toggle('is-active', item.dataset.route === routeKey));
        document.getElementById('viewTitle').textContent = route.title;
        document.getElementById('viewSubtitle').textContent = route.subtitle;
        document.getElementById('sidebar').classList.remove('is-open');

        const view = document.getElementById('view');
        view.style.opacity = '0';
        view.style.transform = 'translateY(10px)';

        try {
            await route.render()(view);
        } catch (error) {
            if (error instanceof api.ApiError && error.status === 401) {
                ui.toast('Session expired', 'Please sign in again.', 'warning');
                signOut();
                return;
            }
            view.innerHTML = `<div class="card"><div class="empty">
                <span class="empty__glyph">⚠️</span>
                <div style="font-weight:640;margin-bottom:6px">This view could not be loaded</div>
                <div class="small">${ui.escapeHtml(error.message)}</div>
              </div></div>`;
        }

        requestAnimationFrame(() => {
            view.style.transition = 'opacity 380ms var(--ease-out-expo), transform 380ms var(--ease-out-expo)';
            view.style.opacity = '1';
            view.style.transform = 'none';
        });

        // Count-up every headline figure once the view has painted.
        view.querySelectorAll('[data-count]').forEach((node) => {
            const target = Number(node.dataset.count);
            ui.countUp(node, target, { decimals: Number.isInteger(target) ? 0 : 1 });
        });
    }
    WT.navigate = navigate;

    async function signOut() {
        try { await api.logout(); } catch (error) { /* the token may already be gone */ }
        if (WT.state.stream) { WT.state.stream.close(); }
        api.setToken(null);
        WT.state = { user: null, dashboard: null, stream: null, view: 'overview' };
        showAuth();
    }

    /* ==================================================================== */
    /* Live event stream                                                    */
    /* ==================================================================== */

    function connectStream() {
        const pill = document.getElementById('livePill');
        const text = document.getElementById('liveText');

        const stream = api.openStream({
            connected: () => {
                pill.classList.remove('is-offline');
                text.textContent = 'live';
            },
            'alert.created': (event) => {
                const alert = event.payload;
                ui.toast(alert.title, alert.message,
                    alert.severity === 'CRITICAL' || alert.severity === 'URGENT' ? 'danger' : 'warning', 8000);
                bumpAlertBadge();
            },
            'risk.updated': (event) => {
                if (WT.state.view === 'overview') { /* the view refreshes on demand */ }
            },
            'risk.intervention': (event) => {
                const payload = event.payload;
                ui.toast('Intervention needed', payload.studentName + ' is at '
                    + payload.score + ' (' + payload.level + ')', 'danger', 9000);
                bumpAlertBadge();
            },
            'badge.earned': (event) => {
                const badge = event.payload;
                ui.toast('Badge unlocked ' + badge.glyph, badge.name, 'success', 6500);
            },
            'ai.ready': () => {
                ui.toast('Scoring model ready', 'Cohort analysis complete — scores are now model-driven.', 'ai', 5000);
                if (WT.state.view) { navigate(WT.state.view); }
            }
        });

        if (stream) {
            stream.onerror = () => {
                pill.classList.add('is-offline');
                text.textContent = 'reconnecting';
            };
            WT.state.stream = stream;
        }
    }

    function bumpAlertBadge() {
        const badge = document.getElementById('alertBadge');
        if (!badge) { return; }
        badge.classList.remove('hidden');
        badge.textContent = String(Number(badge.textContent || 0) + 1);
        badge.animate(
            [{ transform: 'scale(1)' }, { transform: 'scale(1.5)' }, { transform: 'scale(1)' }],
            { duration: 420, easing: 'cubic-bezier(0.34,1.56,0.64,1)' });
    }

    /* ==================================================================== */
    /* Command palette                                                      */
    /* ==================================================================== */

    function openPalette() {
        if (!WT.state.user) { return; }
        const commands = Object.keys(ROUTES)
            .filter((key) => ROUTES[key].roles.includes(WT.state.user.role))
            .map((key) => ({ label: 'Go to ' + ROUTES[key].label, hint: 'view', run: () => navigate(key) }));

        commands.push({ label: 'Toggle light / dark theme', hint: 'theme', run: () => { ui.toggleTheme(); navigate(WT.state.view); } });
        commands.push({ label: 'Refresh current view', hint: 'reload', run: () => navigate(WT.state.view) });
        commands.push({ label: 'Sign out', hint: 'session', run: signOut });
        if (WT.state.user.role === 'STUDENT') {
            commands.push({
                label: 'Download my check-in data (CSV)',
                hint: 'export',
                run: () => global.open('/api/export/behaviour/' + WT.state.user.id
                    + '?token=' + encodeURIComponent(api.token), '_blank')
            });
            commands.push({
                label: 'Download my wellness report',
                hint: 'export',
                run: () => global.open('/api/export/report/' + WT.state.user.id
                    + '?token=' + encodeURIComponent(api.token), '_blank')
            });
        }

        const list = el('div', { class: 'palette__list' });
        const input = el('input', { class: 'palette__input', placeholder: 'Type a command…' });
        const box = el('div', { class: 'palette glass' }, [input, list]);
        const overlay = el('div', { class: 'overlay', style: 'align-items:flex-start' }, [box]);

        let active = 0;
        function draw() {
            const query = input.value.toLowerCase();
            const matches = commands.filter((command) => command.label.toLowerCase().includes(query));
            active = Math.min(active, Math.max(0, matches.length - 1));
            ui.clear(list);
            matches.forEach((command, index) => {
                const item = el('div', { class: 'palette__item' + (index === active ? ' is-active' : '') }, [
                    el('span', { text: command.label }),
                    el('span', { class: 'palette__hint', text: command.hint })
                ]);
                item.addEventListener('click', () => { close(); command.run(); });
                list.appendChild(item);
            });
            list.dataset.count = matches.length;
            list._matches = matches;
        }
        function close() { overlay.remove(); }

        input.addEventListener('input', () => { active = 0; draw(); });
        overlay.addEventListener('click', (event) => { if (event.target === overlay) { close(); } });
        document.addEventListener('keydown', function onKey(event) {
            if (!document.body.contains(overlay)) { document.removeEventListener('keydown', onKey); return; }
            if (event.key === 'Escape') { close(); }
            if (event.key === 'ArrowDown') { event.preventDefault(); active++; draw(); }
            if (event.key === 'ArrowUp') { event.preventDefault(); active = Math.max(0, active - 1); draw(); }
            if (event.key === 'Enter') {
                event.preventDefault();
                const match = (list._matches || [])[active];
                if (match) { close(); match.run(); }
            }
        });

        document.body.appendChild(overlay);
        draw();
        input.focus();
    }

    /* ==================================================================== */
    /* Boot                                                                 */
    /* ==================================================================== */

    document.addEventListener('keydown', (event) => {
        if ((event.ctrlKey || event.metaKey) && event.key.toLowerCase() === 'k') {
            event.preventDefault();
            openPalette();
        }
    });

    async function boot() {
        ui.initTheme();
        const token = api.restoreToken();
        if (!token) { showAuth(); return; }
        try {
            const user = await api.me();
            enterApp(user);
        } catch (error) {
            api.setToken(null);
            showAuth();
        }
    }

    document.addEventListener('DOMContentLoaded', boot);
})(window);
