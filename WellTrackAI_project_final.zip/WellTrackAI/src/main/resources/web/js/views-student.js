/**
 * WellTrack — Student-facing views.
 *
 * Each view is an async function that receives the container element and paints
 * itself. Views own their own data fetching so navigation is instant and no
 * global store has to be kept in sync.
 */
(function (global) {
    'use strict';

    const WT = global.WT;
    const ui = WT.ui;
    const api = WT.api;
    const charts = WT.charts;
    const el = ui.el;
    const esc = ui.escapeHtml;

    const MOODS = [
        ['ENERGISED', '⚡ Energised'], ['HAPPY', '😄 Happy'], ['CALM', '🍃 Calm'],
        ['NEUTRAL', '😐 Neutral'], ['TIRED', '😴 Tired'], ['ANXIOUS', '😰 Anxious'],
        ['STRESSED', '😤 Stressed'], ['LOW', '😔 Low']
    ];

    function riskColour(level) {
        return ({
            THRIVING: 'var(--risk-thriving)', STABLE: 'var(--risk-stable)',
            ELEVATED: 'var(--risk-elevated)', HIGH: 'var(--risk-high)',
            CRITICAL: 'var(--risk-critical)'
        })[level] || 'var(--brand-400)';
    }

    function trendClass(direction) {
        if (direction === 'WORSENING') { return 'trend-up'; }
        if (direction === 'IMPROVING') { return 'trend-down'; }
        return 'trend-flat';
    }

    function changeMarkup(change, invert) {
        const value = Number(change || 0);
        if (Math.abs(value) < 0.05) { return '<span class="trend-flat">▶ no change</span>'; }
        const worse = invert ? value < 0 : value > 0;
        const glyph = value > 0 ? '▲' : '▼';
        return '<span class="' + (worse ? 'trend-up' : 'trend-down') + '">'
            + glyph + ' ' + Math.abs(value).toFixed(1) + '</span>';
    }

    /* ====================================================================
       Overview — the main student dashboard
       ==================================================================== */

    async function overview(container) {
        container.innerHTML = skeletonGrid();
        const data = await api.dashboard();
        WT.state.dashboard = data;

        const risk = data.risk;
        const forecast = data.forecast;
        const weekly = data.weekly;
        const student = data.student;

        container.innerHTML = `
          <div class="grid grid--kpi">
            ${kpiTile('Burnout Risk', risk.score, risk.levelLabel, risk.levelColour, 'riskSpark')}
            ${kpiTile('Check-in Streak', student.streakDays, 'consecutive days', 'var(--accent-amber)', null, '🔥')}
            ${kpiTile('Wellness Points', student.wellnessPoints, 'Level ' + student.level + ' · ' + student.levelTitle, 'var(--accent-mint)')}
            ${kpiTile('Sleep This Week', weekly.sleep.current, 'hours per night ' + changeMarkup(weekly.sleep.change, true), 'var(--accent-cyan)', 'sleepSpark')}
          </div>

          <div class="grid grid--split">
            <div class="card card--spotlight">
              <div class="card__title"><span class="dot"></span>Risk Trajectory &amp; 7-Day Forecast</div>
              <canvas id="trendChart" style="width:100%;height:290px"></canvas>
              <div class="row row--between" style="margin-top:var(--space-3)">
                <div class="small muted">${esc(forecast.narrative)}</div>
                <span class="chip"><span class="chip__dot" style="background:${riskColour(risk.level)}"></span>
                  ${esc(forecast.directionLabel)} · confidence ${Math.round(forecast.confidence * 100)}%</span>
              </div>
            </div>

            <div class="card card--spotlight">
              <div class="card__title"><span class="dot"></span>Live Burnout Score</div>
              <div class="gauge-wrap">
                <div class="gauge">
                  <svg viewBox="0 0 220 220" width="100%" height="100%">
                    <circle class="gauge__track" cx="110" cy="110" r="92"></circle>
                    <circle id="gaugeValue" class="gauge__value" cx="110" cy="110" r="92"
                            stroke="${riskColour(risk.level)}"
                            stroke-dasharray="${(2 * Math.PI * 92).toFixed(1)}"
                            stroke-dashoffset="${(2 * Math.PI * 92).toFixed(1)}"></circle>
                  </svg>
                  <div class="gauge__centre">
                    <div class="gauge__number" id="gaugeNumber" style="color:${riskColour(risk.level)}">0</div>
                    <div class="gauge__unit">out of 100</div>
                    <div class="gauge__band" style="color:${riskColour(risk.level)}">${esc(risk.levelLabel)}</div>
                  </div>
                </div>
                <div class="confidence-bar">
                  <div class="row row--between small muted" style="margin-bottom:4px">
                    <span>Model confidence</span><span>${Math.round(risk.confidence * 100)}%</span>
                  </div>
                  <div class="confidence-bar__track"><div class="confidence-bar__fill" id="confFill"></div></div>
                </div>
                <p class="small muted" style="margin-top:var(--space-4);max-width:34ch">${esc(risk.guidance)}</p>
              </div>
            </div>
          </div>

          <div class="grid grid--split">
            <div class="card">
              <div class="card__title"><span class="dot"></span>Why — Explainable Scoring</div>
              <div id="driverList"></div>
            </div>
            <div class="stack">
              <div class="card">
                <div class="card__title"><span class="dot"></span>Your Wellness Cohort</div>
                <div id="cohortBlock"></div>
              </div>
              <div class="card">
                <div class="card__title"><span class="dot"></span>Journal Sentiment</div>
                <div id="journalBlock"></div>
              </div>
            </div>
          </div>

          <div class="grid grid--split">
            <div class="card">
              <div class="row row--between" style="margin-bottom:var(--space-4)">
                <div class="card__title" style="margin:0"><span class="dot"></span>Your Action Plan</div>
                <button class="btn btn--ghost btn--sm" data-nav="plan">View all</button>
              </div>
              <div id="recList"></div>
            </div>
            <div class="card">
              <div class="card__title"><span class="dot"></span>Recent Alerts</div>
              <div id="alertList"></div>
            </div>
          </div>

          <div class="card">
            <div class="card__title"><span class="dot"></span>This Week at a Glance</div>
            <div class="grid grid--thirds" id="weeklyGrid"></div>
          </div>
        `;

        // ---- Gauge -------------------------------------------------------
        const circumference = 2 * Math.PI * 92;
        requestAnimationFrame(() => {
            const arc = document.getElementById('gaugeValue');
            arc.style.strokeDashoffset = circumference * (1 - risk.score / 100);
            document.getElementById('confFill').style.width = (risk.confidence * 100) + '%';
        });
        ui.countUp(document.getElementById('gaugeNumber'), risk.score, { decimals: 0, duration: 1500 });

        // ---- Trend chart --------------------------------------------------
        const history = await api.riskHistory(student.id, 45);
        const series = history.history.map((point) => point.score);
        const labels = history.history.map((point) => (point.computedAt || '').slice(5, 10));
        charts.areaChart(document.getElementById('trendChart'), {
            values: series.length ? series : [risk.score],
            labels: labels,
            forecast: forecast.projection,
            upper: forecast.upperBound,
            lower: forecast.lowerBound,
            colour: charts.cssVar('--brand-400', '#818cf8'),
            bands: true,
            min: 0, max: 100
        });

        // ---- Sparklines ---------------------------------------------------
        const spark = document.getElementById('riskSpark');
        if (spark && series.length > 1) { charts.sparkline(spark, series.slice(-16), riskColour(risk.level)); }
        const sleepSpark = document.getElementById('sleepSpark');
        if (sleepSpark && data.history.length > 1) {
            charts.sparkline(sleepSpark, data.history.slice(-16).map((log) => log.sleepHours),
                charts.cssVar('--accent-cyan', '#22d3ee'));
        }

        renderDrivers(document.getElementById('driverList'), risk.drivers);
        renderCohort(document.getElementById('cohortBlock'), data.cohort, risk.score);
        renderJournal(document.getElementById('journalBlock'), data.journal);
        renderRecommendations(document.getElementById('recList'), data.recommendations.slice(0, 3), true);
        renderAlerts(document.getElementById('alertList'), data.alerts.slice(0, 5));
        renderWeekly(document.getElementById('weeklyGrid'), weekly);

        container.querySelectorAll('[data-nav]').forEach((button) =>
            button.addEventListener('click', () => WT.navigate(button.dataset.nav)));
        ui.enhance(container);
    }

    function kpiTile(label, value, meta, colour, sparkId, glyph) {
        return `
          <div class="card kpi card--interactive card--spotlight">
            <div class="kpi__glow" style="background:${colour}"></div>
            <div class="kpi__label">${esc(label)}</div>
            <div class="kpi__value" style="color:${colour}" data-count="${value}">0</div>
            <div class="kpi__meta">${glyph ? glyph + ' ' : ''}${meta}</div>
            ${sparkId ? `<canvas class="kpi__spark" id="${sparkId}"></canvas>` : ''}
          </div>`;
    }

    function renderDrivers(node, drivers) {
        if (!drivers || !drivers.length) {
            node.innerHTML = emptyState('🧠', 'The model is still training. Refresh in a moment.');
            return;
        }
        const strongest = Math.max.apply(null, drivers.map((driver) => driver.magnitude)) || 1;
        node.innerHTML = drivers.slice(0, 6).map((driver) => `
          <div class="driver">
            <div class="driver__head">
              <span class="driver__label">${esc(driver.label)}</span>
              <span class="driver__value">${driver.value} · ${driver.direction === 'AGGRAVATING' ? '+' : '−'}${Math.abs(driver.contribution).toFixed(2)}</span>
            </div>
            <div class="driver__track">
              <div class="driver__fill driver__fill--${driver.direction === 'AGGRAVATING' ? 'up' : 'down'}"
                   data-width="${(driver.magnitude / strongest * 100).toFixed(1)}"></div>
            </div>
            <div class="driver__why">${esc(driver.explanation)}</div>
          </div>`).join('');
        requestAnimationFrame(() => {
            node.querySelectorAll('.driver__fill').forEach((fill, index) => {
                setTimeout(() => { fill.style.width = fill.dataset.width + '%'; }, index * 90);
            });
        });
    }

    function renderCohort(node, cohort, score) {
        if (!cohort || !cohort.assigned) {
            node.innerHTML = emptyState('🧬', 'Cohorts appear once enough students are being tracked.');
            return;
        }
        const difference = cohort.comparedToCohort;
        const better = difference < 0;
        node.innerHTML = `
          <div style="font-size:var(--text-lg);font-weight:680;margin-bottom:4px">${esc(cohort.name)}</div>
          <p class="small muted" style="margin-bottom:var(--space-4)">${esc(cohort.description)}</p>
          <div class="row" style="gap:var(--space-5)">
            <div><div class="kpi__label">Cohort size</div><div style="font-size:var(--text-xl);font-weight:700">${cohort.size}</div></div>
            <div><div class="kpi__label">Cohort average</div><div style="font-size:var(--text-xl);font-weight:700">${cohort.averageRisk}</div></div>
            <div><div class="kpi__label">You</div>
              <div style="font-size:var(--text-xl);font-weight:700;color:${better ? 'var(--accent-mint)' : 'var(--accent-rose)'}">
                ${difference > 0 ? '+' : ''}${difference}</div></div>
          </div>
          <p class="small" style="margin-top:var(--space-3)">
            ${better
              ? 'You are doing better than the typical student in your behavioural cohort.'
              : 'You are running above your cohort average — the actions below are the fastest way back.'}
          </p>`;
    }

    function renderJournal(node, journal) {
        if (!journal || journal.entries === 0) {
            node.innerHTML = emptyState('📔', journal ? journal.message : 'No journal entries yet.');
            return;
        }
        const analysis = journal.analysis;
        const emotions = Object.keys(analysis.emotions)
            .map((key) => ({ key, value: analysis.emotions[key] }))
            .sort((a, b) => b.value - a.value).slice(0, 4);
        node.innerHTML = `
          <div class="row" style="margin-bottom:var(--space-3)">
            <span class="chip"><span class="chip__dot" style="background:${analysis.polarity < 0 ? 'var(--accent-rose)' : 'var(--accent-mint)'}"></span>${esc(analysis.label)}</span>
            <span class="chip">${journal.entries} entries analysed</span>
          </div>
          <p class="small" style="margin-bottom:var(--space-4)">${esc(journal.message)}</p>
          ${emotions.map((emotion) => `
            <div class="driver" style="margin-bottom:var(--space-3)">
              <div class="driver__head">
                <span class="driver__label" style="text-transform:capitalize">${esc(emotion.key)}</span>
                <span class="driver__value">${Math.round(emotion.value * 100)}%</span>
              </div>
              <div class="driver__track">
                <div class="driver__fill driver__fill--${emotion.key === 'motivation' ? 'down' : 'up'}"
                     data-width="${Math.round(emotion.value * 100)}"></div>
              </div>
            </div>`).join('')}`;
        requestAnimationFrame(() => {
            node.querySelectorAll('.driver__fill').forEach((fill, index) => {
                setTimeout(() => { fill.style.width = fill.dataset.width + '%'; }, index * 90);
            });
        });
    }

    function renderRecommendations(node, items, compact) {
        if (!items || !items.length) {
            node.innerHTML = emptyState('🎯', 'No actions outstanding — your habits are holding up well.');
            return;
        }
        node.innerHTML = items.map((item) => `
          <div class="rec ${item.completed ? 'is-complete' : ''}" data-id="${item.id}">
            <div class="rec__glyph">${item.categoryGlyph}</div>
            <div class="rec__body">
              <div class="rec__title">${esc(item.title)}</div>
              <div class="rec__detail">${esc(compact ? item.detail.slice(0, 150) + (item.detail.length > 150 ? '…' : '') : item.detail)}</div>
              <div class="rec__action">👉 ${esc(item.actionStep)}</div>
              <div class="rec__meta">
                <span class="impact-pill">▼ ${item.estimatedRiskReduction} pts expected</span>
                <span class="chip">${esc(item.categoryLabel)}</span>
                <span class="chip">evidence ${Math.round(item.evidenceStrength * 100)}%</span>
                ${item.completed ? '' : '<button class="btn btn--ghost btn--sm" data-complete="' + item.id + '">Mark done</button>'}
              </div>
            </div>
          </div>`).join('');

        node.querySelectorAll('[data-complete]').forEach((button) => {
            button.addEventListener('click', async () => {
                button.disabled = true;
                try {
                    const result = await api.completeRecommendation(button.dataset.complete);
                    ui.toast('Action completed', '+25 wellness points · ' + result.levelTitle, 'success');
                    (result.newBadges || []).forEach((badge) =>
                        ui.toast('Badge unlocked ' + badge.glyph, badge.name + ' — ' + badge.description, 'success', 6500));
                    const card = button.closest('.rec');
                    card.classList.add('is-complete');
                    button.remove();
                } catch (error) {
                    ui.toast('Could not complete', error.message, 'danger');
                    button.disabled = false;
                }
            });
        });
    }

    function renderAlerts(node, alerts) {
        if (!alerts || !alerts.length) {
            node.innerHTML = emptyState('🔔', 'No alerts. That is good news.');
            return;
        }
        node.innerHTML = alerts.map((alert, index) => `
          <div class="alert-item ${alert.acknowledged ? 'is-ack' : ''}" style="animation-delay:${index * 60}ms">
            <div class="alert-item__rail" style="background:${alert.severityColour}"></div>
            <div style="flex:1;min-width:0">
              <div class="alert-item__title">${esc(alert.title)}</div>
              <div class="alert-item__msg">${esc(alert.message)}</div>
              <div class="alert-item__time">${esc(alert.severityLabel)} · ${ui.relativeTime(alert.createdAt)}</div>
            </div>
          </div>`).join('');
    }

    function renderWeekly(node, weekly) {
        const metrics = [
            ['Sleep', weekly.sleep, 'var(--accent-cyan)', 9, true],
            ['Study', weekly.study, 'var(--brand-400)', 10, false],
            ['Screen time', weekly.screenTime, 'var(--accent-magenta)', 12, false],
            ['Stress', weekly.stress, 'var(--accent-rose)', 10, false],
            ['Exercise', weekly.exercise, 'var(--accent-mint)', 90, true],
            ['Attendance', weekly.attendance, 'var(--accent-amber)', 100, true]
        ];
        node.innerHTML = metrics.map(([label, metric, colour, max, higherIsBetter]) => `
          <div class="row" style="gap:var(--space-4)">
            <canvas class="weekly-ring" width="64" height="64" style="width:64px;height:64px"
                    data-value="${metric.current}" data-max="${max}" data-colour="${colour}"></canvas>
            <div>
              <div class="kpi__label">${label}</div>
              <div style="font-size:var(--text-xl);font-weight:700">${metric.current}<span class="small muted"> ${esc(metric.unit)}</span></div>
              <div class="small">${changeMarkup(metric.change, higherIsBetter)} vs last week</div>
            </div>
          </div>`).join('');
        node.querySelectorAll('.weekly-ring').forEach((canvas) =>
            charts.radialProgress(canvas, Number(canvas.dataset.value),
                Number(canvas.dataset.max), canvas.dataset.colour));
    }

    /* ====================================================================
       Daily check-in
       ==================================================================== */

    async function checkIn(container) {
        const studentId = WT.state.user.id;
        const existing = await api.todayLog(studentId);
        const log = existing.exists ? existing.log : null;

        container.innerHTML = `
          <div class="card" style="max-width:940px;margin:0 auto">
            <div class="row row--between" style="margin-bottom:var(--space-5)">
              <div>
                <div class="section-title">Daily Check-in</div>
                <div class="section-sub">${log ? 'You already logged today — submitting again will update it.' : 'Sixty seconds today keeps the model accurate all term.'}</div>
              </div>
              <span class="chip"><span class="chip__dot" style="background:var(--accent-mint)"></span>${new Date().toLocaleDateString(undefined, { weekday: 'long', day: 'numeric', month: 'long' })}</span>
            </div>

            <form id="checkInForm">
              <div class="grid grid--halves">
                ${sliderField('sleepHours', 'Hours of sleep last night', 0, 12, 0.5, log ? log.sleepHours : 7, 'h')}
                ${sliderField('studyHours', 'Hours studied today', 0, 14, 0.5, log ? log.studyHours : 4, 'h')}
                ${sliderField('screenTimeHours', 'Recreational screen time', 0, 14, 0.5, log ? log.screenTimeHours : 4, 'h')}
                ${sliderField('exerciseMinutes', 'Minutes of movement', 0, 180, 5, log ? log.exerciseMinutes : 20, 'min')}
                ${sliderField('socialMinutes', 'Minutes with other people', 0, 300, 10, log ? log.socialMinutes : 60, 'min')}
                ${sliderField('stressLevel', 'Stress level', 1, 10, 1, log ? log.stressLevel : 5, '/10')}
                ${sliderField('deadlinePressure', 'Deadline pressure', 0, 10, 1, log ? log.deadlinePressure : 3, '/10')}
                ${sliderField('assignmentsPending', 'Assignments pending', 0, 20, 1, log ? log.assignmentsPending : 2, '')}
                ${sliderField('caffeineCups', 'Cups of caffeine', 0, 10, 1, log ? log.caffeineCups : 1, '')}
                ${sliderField('mealsSkipped', 'Meals skipped', 0, 4, 1, log ? log.mealsSkipped : 0, '')}
                ${sliderField('classesScheduled', 'Classes scheduled', 0, 10, 1, log ? log.classesScheduled : 6, '')}
                ${sliderField('classesAttended', 'Classes attended', 0, 10, 1, log ? log.classesAttended : 6, '')}
              </div>

              <div class="field" style="margin-top:var(--space-5)">
                <select id="mood" class="filled">
                  ${MOODS.map(([value, label]) =>
                    `<option value="${value}" ${log && log.mood === value ? 'selected' : ''}>${label}</option>`).join('')}
                </select>
                <label>How did today feel?</label>
              </div>

              <div class="field">
                <textarea id="journalNote" placeholder=" " maxlength="600">${log ? esc(log.journalNote) : ''}</textarea>
                <label>Journal note — the coach reads this too (optional)</label>
                <span class="field__error"></span>
              </div>

              <div class="row row--between" style="margin-top:var(--space-4)">
                <span class="small muted">Your entry is analysed immediately and privately.</span>
                <button type="submit" class="btn btn--primary" id="submitCheckIn">
                  ${log ? 'Update today\'s check-in' : 'Submit check-in'}
                </button>
              </div>
            </form>
          </div>`;

        container.querySelectorAll('input[type=range]').forEach((slider) => {
            const output = container.querySelector('#' + slider.id + 'Value');
            slider.addEventListener('input', () => { output.textContent = slider.value + ' ' + slider.dataset.unit; });
        });

        container.querySelector('#checkInForm').addEventListener('submit', async (event) => {
            event.preventDefault();
            const button = container.querySelector('#submitCheckIn');
            button.disabled = true;
            button.textContent = 'Analysing…';

            const payload = { mood: container.querySelector('#mood').value,
                              journalNote: container.querySelector('#journalNote').value };
            container.querySelectorAll('input[type=range]').forEach((slider) => {
                payload[slider.id] = Number(slider.value);
            });

            try {
                const result = await api.checkIn(payload);
                ui.toast('Check-in recorded', 'New burnout score: ' + result.risk.score
                    + ' (' + result.risk.levelLabel + ')', 'success');
                (result.newBadges || []).forEach((badge) =>
                    ui.toast('Badge unlocked ' + badge.glyph, badge.name, 'success', 6500));
                WT.navigate('overview');
            } catch (error) {
                if (error.fieldErrors && Object.keys(error.fieldErrors).length) {
                    Object.keys(error.fieldErrors).forEach((field) =>
                        ui.toast('Check that value', error.fieldErrors[field], 'warning'));
                } else {
                    ui.toast('Could not save', error.message, 'danger');
                }
                button.disabled = false;
                button.textContent = 'Submit check-in';
            }
        });
        ui.enhance(container);
    }

    function sliderField(id, label, min, max, step, value, unit) {
        return `
          <div class="slider-row">
            <div class="slider-row__head">
              <span>${label}</span>
              <span class="slider-row__value" id="${id}Value">${value} ${unit}</span>
            </div>
            <input type="range" id="${id}" min="${min}" max="${max}" step="${step}" value="${value}" data-unit="${unit}">
          </div>`;
    }

    /* ====================================================================
       Insights — explainability plus the what-if simulator
       ==================================================================== */

    async function insights(container) {
        container.innerHTML = skeletonGrid();
        const studentId = WT.state.user.id;
        const [explanation, dashboard] = await Promise.all([api.aiExplain(studentId), api.dashboard()]);
        const names = explanation.featureNames;
        const vector = explanation.featureVector;
        const value = (key) => vector[names.indexOf(key)];

        container.innerHTML = `
          <div>
            <div class="section-title">Predictive Insights</div>
            <div class="section-sub">Every point of your score is attributable to a behaviour. Nothing here is a black box.</div>
          </div>

          <div class="grid grid--split">
            <div class="card">
              <div class="card__title"><span class="dot"></span>Full Factor Breakdown</div>
              <div id="fullDrivers"></div>
            </div>

            <div class="card card--spotlight">
              <div class="card__title"><span class="dot"></span>What-If Simulator</div>
              <p class="small muted" style="margin-bottom:var(--space-4)">
                Move the sliders to score a hypothetical day through the same trained model.
              </p>
              ${simSlider('sleepHours', 'Sleep', 3, 11, 0.5, value('sleepHours'), 'h')}
              ${simSlider('studyHours', 'Study', 0, 14, 0.5, value('studyHours'), 'h')}
              ${simSlider('screenTimeHours', 'Screen time', 0, 14, 0.5, value('screenTimeHours'), 'h')}
              ${simSlider('exerciseMinutes', 'Exercise', 0, 150, 5, value('exerciseMinutes'), 'min')}
              ${simSlider('socialMinutes', 'Social contact', 0, 300, 10, value('socialMinutes'), 'min')}
              ${simSlider('stressLevel', 'Stress', 1, 10, 1, value('stressLevel'), '/10')}
              ${simSlider('caffeineCups', 'Caffeine', 0, 8, 1, value('caffeineCups'), 'cups')}

              <div class="sim-result">
                <div class="sim-score">
                  <div class="sim-score__value" id="simBaseline">—</div>
                  <div class="sim-score__label">Today</div>
                </div>
                <div class="sim-arrow">→</div>
                <div class="sim-score">
                  <div class="sim-score__value" id="simProjected">—</div>
                  <div class="sim-score__label" id="simLevel">Simulated</div>
                </div>
              </div>
              <p class="small center" id="simNarrative" style="min-height:34px"></p>
              <button class="btn btn--ghost btn--block btn--sm" id="simReset">Reset to my actual data</button>
            </div>
          </div>

          <div class="grid grid--split">
            <div class="card">
              <div class="card__title"><span class="dot"></span>Single-Change Sensitivity</div>
              <p class="small muted" style="margin-bottom:var(--space-3)">
                What one change on its own is worth, measured through the model.
              </p>
              <div id="leverList"></div>
            </div>
            <div class="card">
              <div class="card__title"><span class="dot"></span>Behaviour Distribution</div>
              <canvas id="behaviourChart" style="width:100%;height:260px"></canvas>
            </div>
          </div>`;

        renderDrivers(document.getElementById('fullDrivers'), dashboard.risk.drivers);

        const behaviours = dashboard.history.slice(-14);
        charts.barChart(document.getElementById('behaviourChart'), {
            values: behaviours.map((log) => Math.round(log.strainScore)),
            labels: behaviours.map((log) => log.logDate.slice(8)),
            colours: behaviours.map((log) => log.strainScore >= 60 ? charts.cssVar('--risk-high')
                : log.strainScore >= 40 ? charts.cssVar('--risk-elevated') : charts.cssVar('--risk-stable'))
        });

        const sliders = Array.from(container.querySelectorAll('[data-sim]'));
        let debounce = null;

        async function runSimulation() {
            const payload = { studentId };
            sliders.forEach((slider) => { payload[slider.dataset.sim] = Number(slider.value); });
            try {
                const result = await api.simulate(payload);
                if (!result.ready) { return; }
                ui.countUp(document.getElementById('simBaseline'), result.baselineScore, { decimals: 0, duration: 500 });
                const projected = document.getElementById('simProjected');
                ui.countUp(projected, result.simulatedScore, { decimals: 0, duration: 700 });
                projected.style.color = result.simulatedColour;
                document.getElementById('simLevel').textContent = result.simulatedLevel;
                document.getElementById('simNarrative').textContent = result.narrative;
                document.getElementById('leverList').innerHTML = result.levers.map((lever) => `
                  <div class="lever">
                    <span>${esc(lever.label)}</span>
                    <span class="lever__delta ${lever.improves ? 'trend-down' : 'trend-up'}">
                      ${lever.scoreChange > 0 ? '+' : ''}${lever.scoreChange} pts</span>
                  </div>`).join('');
            } catch (error) {
                ui.toast('Simulation failed', error.message, 'danger');
            }
        }

        sliders.forEach((slider) => {
            slider.addEventListener('input', () => {
                container.querySelector('#' + slider.id + 'Out').textContent =
                    slider.value + ' ' + slider.dataset.unit;
                clearTimeout(debounce);
                debounce = setTimeout(runSimulation, 220);
            });
        });

        container.querySelector('#simReset').addEventListener('click', () => {
            sliders.forEach((slider) => {
                slider.value = slider.dataset.original;
                container.querySelector('#' + slider.id + 'Out').textContent =
                    Number(slider.dataset.original).toFixed(1) + ' ' + slider.dataset.unit;
            });
            runSimulation();
        });

        runSimulation();
        ui.enhance(container);
    }

    function simSlider(key, label, min, max, step, value, unit) {
        const safe = Number(value || 0);
        return `
          <div class="slider-row">
            <div class="slider-row__head">
              <span>${label}</span>
              <span class="slider-row__value" id="sim_${key}Out">${safe.toFixed(1)} ${unit}</span>
            </div>
            <input type="range" id="sim_${key}" data-sim="${key}" data-unit="${unit}"
                   data-original="${safe}" min="${min}" max="${max}" step="${step}" value="${safe}">
          </div>`;
    }

    /* ====================================================================
       AI coach
       ==================================================================== */

    async function coach(container) {
        container.innerHTML = `
          <div class="grid grid--split">
            <div class="card">
              <div class="row row--between" style="margin-bottom:var(--space-4)">
                <div class="card__title" style="margin:0"><span class="dot"></span>Wellness Coach</div>
                <button class="btn btn--ghost btn--sm" id="clearChat">Clear</button>
              </div>
              <div class="chat">
                <div class="chat__log" id="chatLog"></div>
                <div class="suggestions" id="suggestions"></div>
                <form class="chat__composer" id="chatForm">
                  <input class="chat__input" id="chatInput" placeholder="Ask me anything about your wellbeing…" autocomplete="off">
                  <button type="submit" class="btn btn--primary">Send</button>
                </form>
              </div>
            </div>
            <div class="stack">
              <div class="card">
                <div class="card__title"><span class="dot"></span>How the Coach Works</div>
                <div id="coachPipeline"></div>
              </div>
              <div class="card">
                <div class="card__title"><span class="dot"></span>Last Message Analysis</div>
                <div id="chatAnalysis" class="small muted">Send a message to see the NLP breakdown.</div>
              </div>
            </div>
          </div>`;

        const log = container.querySelector('#chatLog');
        const history = await api.chatHistory();
        history.messages.forEach((message) => appendMessage(log, message.role, message.content, false));
        scrollToEnd(log);

        renderSuggestions(container.querySelector('#suggestions'),
            ['Why is my score high?', 'How do I fix my sleep?', 'What is my forecast?'], container);

        container.querySelector('#coachPipeline').innerHTML = [
            ['1', 'Understand', 'Naive Bayes intent classification over 11 trained intents'],
            ['2', 'Feel', 'Lexicon sentiment with negation scope and five emotion channels'],
            ['3', 'Retrieve', 'TF-IDF cosine search across the wellness knowledge base'],
            ['4', 'Ground', 'Your live score, drivers and latest check-in are injected'],
            ['5', 'Compose', 'A grounded answer with exactly one concrete next step']
        ].map(([step, title, detail]) => `
          <div class="row" style="align-items:flex-start;margin-bottom:var(--space-3)">
            <div class="avatar" style="width:26px;height:26px;font-size:0.7rem">${step}</div>
            <div style="flex:1">
              <div style="font-weight:640;font-size:var(--text-sm)">${title}</div>
              <div class="small muted">${detail}</div>
            </div>
          </div>`).join('');

        container.querySelector('#chatForm').addEventListener('submit', async (event) => {
            event.preventDefault();
            const input = container.querySelector('#chatInput');
            const text = input.value.trim();
            if (!text) { return; }
            input.value = '';
            appendMessage(log, 'USER', text, true);
            const typing = appendTyping(log);

            try {
                const result = await api.chatSend(text);
                typing.remove();
                appendMessage(log, 'COACH', result.reply.content, true);
                renderChatAnalysis(container.querySelector('#chatAnalysis'), result.analysis);
                renderSuggestions(container.querySelector('#suggestions'),
                    result.analysis.suggestedReplies, container);
                if (result.analysis.escalate) {
                    ui.toast('Support flagged', 'Your mentor has been notified so they can check in with you.', 'warning', 9000);
                }
            } catch (error) {
                typing.remove();
                ui.toast('Coach unavailable', error.message, 'danger');
            }
        });

        container.querySelector('#clearChat').addEventListener('click', async () => {
            await api.chatClear();
            ui.clear(log);
            ui.toast('Conversation cleared', '', 'info');
            WT.navigate('coach');
        });

        ui.enhance(container);
        container.querySelector('#chatInput').focus();
    }

    function appendMessage(log, role, content, animate) {
        const isUser = role === 'USER';
        const node = el('div', { class: 'msg ' + (isUser ? 'msg--user' : '') }, [
            el('div', { class: 'msg__avatar', text: isUser ? '🙂' : '🧠' }),
            el('div', { class: 'msg__bubble', text: content })
        ]);
        if (!animate) { node.style.animation = 'none'; }
        log.appendChild(node);
        scrollToEnd(log);
        return node;
    }

    function appendTyping(log) {
        const node = el('div', { class: 'msg' }, [
            el('div', { class: 'msg__avatar', text: '🧠' }),
            el('div', { class: 'msg__bubble', style: 'padding:0' }, [
                el('div', { class: 'typing', html: '<span></span><span></span><span></span>' })
            ])
        ]);
        log.appendChild(node);
        scrollToEnd(log);
        return node;
    }

    function scrollToEnd(log) {
        requestAnimationFrame(() => { log.scrollTop = log.scrollHeight; });
    }

    function renderSuggestions(node, suggestions, container) {
        node.innerHTML = (suggestions || []).map((text) =>
            `<button class="suggestion">${esc(text)}</button>`).join('');
        node.querySelectorAll('.suggestion').forEach((button) => {
            button.addEventListener('click', () => {
                const input = container.querySelector('#chatInput');
                input.value = button.textContent;
                container.querySelector('#chatForm').dispatchEvent(new Event('submit', { cancelable: true }));
            });
        });
    }

    function renderChatAnalysis(node, analysis) {
        const emotions = Object.keys(analysis.sentiment.emotions)
            .map((key) => ({ key, value: analysis.sentiment.emotions[key] }))
            .filter((item) => item.value > 0.02)
            .sort((a, b) => b.value - a.value);
        node.innerHTML = `
          <div class="row" style="margin-bottom:var(--space-3)">
            <span class="chip">intent: ${esc(analysis.intent)}</span>
            <span class="chip">${Math.round(analysis.intentConfidence * 100)}% confident</span>
          </div>
          <div class="row" style="margin-bottom:var(--space-3)">
            <span class="chip"><span class="chip__dot" style="background:${analysis.sentiment.polarity < 0 ? 'var(--accent-rose)' : 'var(--accent-mint)'}"></span>${esc(analysis.sentiment.label)}</span>
            <span class="chip">dominant: ${esc(analysis.sentiment.dominantEmotion)}</span>
          </div>
          ${emotions.length ? '<div class="small muted" style="margin-bottom:6px">Emotion channels</div>' : ''}
          ${emotions.map((emotion) => `
            <div class="lever"><span style="text-transform:capitalize">${esc(emotion.key)}</span>
              <span class="lever__delta">${Math.round(emotion.value * 100)}%</span></div>`).join('')}
          ${analysis.sources.length ? '<div class="small muted" style="margin-top:var(--space-3)">Knowledge sources: '
            + analysis.sources.map(esc).join(', ') + '</div>' : ''}
          <div class="small muted" style="margin-top:var(--space-2)">Generated by ${esc(analysis.generator)}</div>`;
    }

    /* ====================================================================
       Plan — recommendations, badges, leaderboard
       ==================================================================== */

    async function plan(container) {
        container.innerHTML = skeletonGrid();
        const studentId = WT.state.user.id;
        const [recommendations, board, dashboard] = await Promise.all([
            api.recommendations(studentId), api.leaderboard(), api.dashboard()
        ]);

        container.innerHTML = `
          <div>
            <div class="section-title">Your Recovery Plan</div>
            <div class="section-sub">Generated from the same coefficients that produced your score — the advice and the explanation can never disagree.</div>
          </div>

          <div class="grid grid--split">
            <div class="card">
              <div class="card__title"><span class="dot"></span>Active Actions</div>
              <div id="planActive"></div>
            </div>
            <div class="stack">
              <div class="card">
                <div class="card__title"><span class="dot"></span>Badges Earned</div>
                <div class="badge-grid" id="badgeGrid"></div>
              </div>
              <div class="card">
                <div class="card__title"><span class="dot"></span>Wellness Leaderboard</div>
                <div id="leaderboard"></div>
              </div>
            </div>
          </div>

          <div class="card">
            <div class="card__title"><span class="dot"></span>Completed History</div>
            <div id="planHistory"></div>
          </div>`;

        renderRecommendations(container.querySelector('#planActive'), recommendations.active, false);

        const badges = dashboard.badges;
        container.querySelector('#badgeGrid').innerHTML = badges.length
            ? badges.map((badge) => `
                <div class="badge-tile tooltip" data-tip="${esc(badge.description)}">
                  <span class="badge-tile__glyph">${badge.glyph}</span>
                  <span class="badge-tile__name">${esc(badge.name)}</span>
                  <span class="badge-tile__tier" style="color:${badge.tierColour}">${esc(badge.tierLabel)}</span>
                </div>`).join('')
            : emptyState('🏅', 'Log check-ins to start earning badges.');

        container.querySelector('#leaderboard').innerHTML = `
          <div class="small muted" style="margin-bottom:var(--space-3)">
            You are ranked ${board.viewerRank} of ${board.totalStudents}. Names beyond the top three stay anonymous.
          </div>
          ${board.rows.map((row) => `
            <div class="rank-row ${row.isViewer ? 'is-viewer' : ''}">
              <span class="rank-row__pos">${row.rank}</span>
              <div class="avatar" style="width:28px;height:28px;font-size:0.66rem">${esc(row.initials)}</div>
              <div>
                <div style="font-size:var(--text-sm);font-weight:600">${esc(row.name)}</div>
                <div class="small muted">Level ${row.level} · ${esc(row.levelTitle)}</div>
              </div>
              <span class="rank-row__pts">${row.points}</span>
            </div>`).join('')}`;

        const completed = recommendations.history.filter((item) => item.completed);
        container.querySelector('#planHistory').innerHTML = completed.length
            ? completed.map((item) => `
                <div class="lever">
                  <span>${item.categoryGlyph} ${esc(item.title)}</span>
                  <span class="small muted">${ui.relativeTime(item.completedAt)}</span>
                </div>`).join('')
            : emptyState('✅', 'Nothing completed yet — start with the top action above.');

        ui.enhance(container);
    }

    /* ------------------------------------------------------------ helpers */

    function emptyState(glyph, message) {
        return `<div class="empty"><span class="empty__glyph">${glyph}</span>${esc(message)}</div>`;
    }

    function skeletonGrid() {
        return `<div class="grid grid--kpi">
            ${'<div class="skeleton" style="height:118px"></div>'.repeat(4)}
          </div>
          <div class="grid grid--split" style="margin-top:var(--space-4)">
            <div class="skeleton" style="height:330px"></div>
            <div class="skeleton" style="height:330px"></div>
          </div>`;
    }

    global.WT = global.WT || {};
    global.WT.studentViews = {
        overview, checkIn, insights, coach, plan,
        renderDrivers, renderAlerts, emptyState, skeletonGrid, riskColour, changeMarkup
    };
})(window);
