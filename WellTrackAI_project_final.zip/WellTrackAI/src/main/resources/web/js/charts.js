/**
 * WellTrack — Canvas chart library.
 *
 * Written from scratch rather than pulled from a CDN, so the whole application
 * stays dependency-free and works with no internet connection. Every chart is
 * device-pixel-ratio aware, animates its own draw-in, and reads its colours
 * from the CSS custom properties so it re-themes automatically.
 */
(function (global) {
    'use strict';

    const reduceMotion = global.matchMedia('(prefers-reduced-motion: reduce)').matches;

    function cssVar(name, fallback) {
        const value = getComputedStyle(document.documentElement).getPropertyValue(name).trim();
        return value || fallback;
    }

    /**
     * Canvas cannot parse CSS custom properties, so a colour such as
     * "var(--risk-high)" is resolved to its computed hex value before use.
     */
    function resolveColour(colour, fallback) {
        if (typeof colour !== 'string') { return fallback; }
        const match = colour.match(/^var\(\s*(--[\w-]+)\s*(?:,\s*([^)]+))?\)$/);
        return match ? cssVar(match[1], match[2] || fallback || '#818cf8') : colour;
    }

    /** Prepares a canvas for crisp rendering and returns its 2D context. */
    function prepare(canvas) {
        const ratio = Math.min(2, global.devicePixelRatio || 1);
        const width = canvas.clientWidth || canvas.parentElement.clientWidth || 320;
        const height = canvas.clientHeight || 200;
        canvas.width = width * ratio;
        canvas.height = height * ratio;
        const context = canvas.getContext('2d');
        context.setTransform(ratio, 0, 0, ratio, 0, 0);
        context.clearRect(0, 0, width, height);
        return { context, width, height };
    }

    /** Drives an animation from 0 to 1 with an ease-out-cubic curve. */
    function animate(duration, onFrame) {
        if (reduceMotion) { onFrame(1); return; }
        const started = performance.now();
        function frame(now) {
            const linear = Math.min(1, (now - started) / duration);
            onFrame(1 - Math.pow(1 - linear, 3));
            if (linear < 1) { requestAnimationFrame(frame); }
        }
        requestAnimationFrame(frame);
    }

    /** Catmull-Rom style smoothing so trend lines read as curves, not zigzags. */
    function smoothPath(context, points) {
        if (points.length < 2) { return; }
        context.moveTo(points[0].x, points[0].y);
        for (let i = 0; i < points.length - 1; i++) {
            const current = points[i];
            const next = points[i + 1];
            const midX = (current.x + next.x) / 2;
            context.bezierCurveTo(midX, current.y, midX, next.y, next.x, next.y);
        }
    }

    /**
     * Area chart with a gradient fill, optional forecast continuation drawn as
     * a dashed line inside a shaded confidence band, and hover read-out.
     */
    function areaChart(canvas, options) {
        const settings = options || {};
        let values = settings.values || [];
        const labels = settings.labels || [];
        const forecast = settings.forecast || [];
        // A single observation cannot describe a line; duplicate it so the
        // first-ever check-in still renders a sensible flat segment.
        if (values.length === 1) { values = [values[0], values[0]]; }
        const upper = settings.upper || [];
        const lower = settings.lower || [];
        if (values.length === 0) { return; }

        const stroke = resolveColour(settings.colour, cssVar('--brand-400', '#818cf8'));
        const gridColour = cssVar('--chart-grid', 'rgba(255,255,255,0.07)');
        const textColour = cssVar('--text-muted', '#6f7899');

        const padding = { top: 18, right: 14, bottom: 26, left: 34 };
        const total = values.length + forecast.length;

        const everything = values.concat(forecast, upper, lower);
        const rawMax = Math.max.apply(null, everything);
        const rawMin = Math.min.apply(null, everything);
        const max = settings.max !== undefined ? settings.max : Math.ceil((rawMax + 6) / 10) * 10;
        const min = settings.min !== undefined ? settings.min : Math.max(0, Math.floor((rawMin - 6) / 10) * 10);

        function render(progress) {
            const prepared = prepare(canvas);
            const context = prepared.context;
            const width = prepared.width;
            const height = prepared.height;
            const plotWidth = width - padding.left - padding.right;
            const plotHeight = height - padding.top - padding.bottom;

            const xAt = (index) => padding.left + (total <= 1 ? 0 : (index / (total - 1)) * plotWidth);
            const yAt = (value) => padding.top + plotHeight - ((value - min) / (max - min || 1)) * plotHeight;

            // Horizontal grid and axis labels.
            context.font = '10px ' + cssVar('--font-sans', 'sans-serif');
            context.fillStyle = textColour;
            context.strokeStyle = gridColour;
            context.lineWidth = 1;
            for (let step = 0; step <= 4; step++) {
                const value = min + ((max - min) / 4) * step;
                const y = yAt(value);
                context.beginPath();
                context.moveTo(padding.left, y);
                context.lineTo(width - padding.right, y);
                context.stroke();
                context.textAlign = 'right';
                context.fillText(Math.round(value), padding.left - 7, y + 3);
            }

            // Risk band shading behind the series.
            if (settings.bands) {
                const bands = [
                    { from: 60, to: max, colour: 'rgba(251, 113, 133, 0.07)' },
                    { from: 40, to: 60, colour: 'rgba(251, 191, 36, 0.06)' }
                ];
                bands.forEach((band) => {
                    if (band.to <= band.from) { return; }
                    const top = yAt(Math.min(band.to, max));
                    const bottom = yAt(Math.max(band.from, min));
                    context.fillStyle = band.colour;
                    context.fillRect(padding.left, top, plotWidth, bottom - top);
                });
            }

            const visibleCount = Math.max(2, Math.round(values.length * progress));
            const points = values.slice(0, visibleCount).map((value, index) => ({ x: xAt(index), y: yAt(value) }));

            // Gradient fill under the observed series.
            const gradient = context.createLinearGradient(0, padding.top, 0, height - padding.bottom);
            gradient.addColorStop(0, stroke + '55');
            gradient.addColorStop(1, stroke + '05');
            context.beginPath();
            smoothPath(context, points);
            context.lineTo(points[points.length - 1].x, height - padding.bottom);
            context.lineTo(points[0].x, height - padding.bottom);
            context.closePath();
            context.fillStyle = gradient;
            context.fill();

            // Observed line.
            context.beginPath();
            smoothPath(context, points);
            context.strokeStyle = stroke;
            context.lineWidth = 2.4;
            context.lineJoin = 'round';
            context.shadowColor = stroke + '80';
            context.shadowBlur = 12;
            context.stroke();
            context.shadowBlur = 0;

            // Forecast band and dashed continuation.
            if (forecast.length && progress > 0.75) {
                const alpha = (progress - 0.75) / 0.25;
                const offset = values.length - 1;

                if (upper.length === forecast.length && lower.length === forecast.length) {
                    context.beginPath();
                    context.moveTo(xAt(offset), yAt(values[values.length - 1]));
                    upper.forEach((value, index) => context.lineTo(xAt(offset + index + 1), yAt(value)));
                    for (let index = lower.length - 1; index >= 0; index--) {
                        context.lineTo(xAt(offset + index + 1), yAt(lower[index]));
                    }
                    context.closePath();
                    context.fillStyle = stroke + Math.round(alpha * 26).toString(16).padStart(2, '0');
                    context.fill();
                }

                context.beginPath();
                context.setLineDash([5, 5]);
                context.moveTo(xAt(offset), yAt(values[values.length - 1]));
                forecast.forEach((value, index) => context.lineTo(xAt(offset + index + 1), yAt(value)));
                context.strokeStyle = stroke + Math.round(alpha * 220).toString(16).padStart(2, '0');
                context.lineWidth = 2;
                context.stroke();
                context.setLineDash([]);
            }

            // Leading dot.
            const last = points[points.length - 1];
            context.beginPath();
            context.arc(last.x, last.y, 4.5, 0, Math.PI * 2);
            context.fillStyle = stroke;
            context.fill();
            context.beginPath();
            context.arc(last.x, last.y, 8.5, 0, Math.PI * 2);
            context.fillStyle = stroke + '33';
            context.fill();

            // X labels: first, middle and last only, to avoid clutter.
            if (labels.length) {
                context.fillStyle = textColour;
                context.textAlign = 'center';
                [0, Math.floor(labels.length / 2), labels.length - 1].forEach((index) => {
                    if (labels[index]) {
                        context.fillText(labels[index], xAt(index), height - 8);
                    }
                });
            }
        }

        animate(settings.duration || 1200, render);
        if (!canvas.dataset.resizeBound) {
            canvas.dataset.resizeBound = '1';
            global.addEventListener('resize', () => render(1));
        }
    }

    /** Compact sparkline for KPI tiles. */
    function sparkline(canvas, values, colour) {
        colour = resolveColour(colour, cssVar('--brand-400', '#818cf8'));
        if (!values || values.length < 2) { return; }
        const stroke = colour || cssVar('--brand-400', '#818cf8');
        function render(progress) {
            const prepared = prepare(canvas);
            const context = prepared.context;
            const width = prepared.width;
            const height = prepared.height;
            const max = Math.max.apply(null, values);
            const min = Math.min.apply(null, values);
            const count = Math.max(2, Math.round(values.length * progress));

            const points = values.slice(0, count).map((value, index) => ({
                x: (index / (values.length - 1)) * width,
                y: height - 4 - ((value - min) / (max - min || 1)) * (height - 10)
            }));

            const gradient = context.createLinearGradient(0, 0, 0, height);
            gradient.addColorStop(0, stroke + '4a');
            gradient.addColorStop(1, stroke + '00');
            context.beginPath();
            smoothPath(context, points);
            context.lineTo(points[points.length - 1].x, height);
            context.lineTo(points[0].x, height);
            context.closePath();
            context.fillStyle = gradient;
            context.fill();

            context.beginPath();
            smoothPath(context, points);
            context.strokeStyle = stroke;
            context.lineWidth = 1.8;
            context.stroke();
        }
        animate(900, render);
    }

    /** Vertical bar chart with rounded caps and grow-up animation. */
    function barChart(canvas, options) {
        const settings = options || {};
        const values = settings.values || [];
        const labels = settings.labels || [];
        const colours = (settings.colours || []).map((c) => resolveColour(c, '#818cf8'));
        if (!values.length) { return; }

        const textColour = cssVar('--text-muted', '#6f7899');
        const defaultColour = cssVar('--brand-400', '#818cf8');
        const max = Math.max.apply(null, values.concat([1]));

        function render(progress) {
            const prepared = prepare(canvas);
            const context = prepared.context;
            const width = prepared.width;
            const height = prepared.height;
            const bottom = height - 24;
            const slot = width / values.length;
            const barWidth = Math.min(46, slot * 0.56);

            context.font = '10px ' + cssVar('--font-sans', 'sans-serif');
            context.textAlign = 'center';

            values.forEach((value, index) => {
                const barHeight = (value / max) * (bottom - 20) * progress;
                const x = slot * index + slot / 2 - barWidth / 2;
                const y = bottom - barHeight;
                const colour = colours[index] || defaultColour;

                const gradient = context.createLinearGradient(0, y, 0, bottom);
                gradient.addColorStop(0, colour);
                gradient.addColorStop(1, colour + '44');
                context.fillStyle = gradient;

                const radius = Math.min(7, barWidth / 2, barHeight);
                context.beginPath();
                context.moveTo(x, bottom);
                context.lineTo(x, y + radius);
                context.quadraticCurveTo(x, y, x + radius, y);
                context.lineTo(x + barWidth - radius, y);
                context.quadraticCurveTo(x + barWidth, y, x + barWidth, y + radius);
                context.lineTo(x + barWidth, bottom);
                context.closePath();
                context.fill();

                context.fillStyle = textColour;
                context.fillText(labels[index] || '', x + barWidth / 2, height - 8);
                if (value > 0 && progress > 0.85) {
                    context.fillStyle = cssVar('--text-primary', '#fff');
                    context.fillText(String(value), x + barWidth / 2, y - 6);
                }
            });
        }
        animate(1000, render);
    }

    /** Donut chart with a sweep animation and a centred caption. */
    function donutChart(canvas, options) {
        const settings = options || {};
        const segments = (settings.segments || []).map((s) => Object.assign({}, s, { colour: resolveColour(s.colour, '#818cf8') }));
        const total = segments.reduce((sum, segment) => sum + segment.value, 0);
        if (total === 0) { return; }

        function render(progress) {
            const prepared = prepare(canvas);
            const context = prepared.context;
            const width = prepared.width;
            const height = prepared.height;
            const centreX = width / 2;
            const centreY = height / 2;
            const radius = Math.min(width, height) / 2 - 12;
            const thickness = Math.max(14, radius * 0.34);

            let angle = -Math.PI / 2;
            segments.forEach((segment) => {
                const sweep = (segment.value / total) * Math.PI * 2 * progress;
                context.beginPath();
                context.arc(centreX, centreY, radius - thickness / 2, angle, angle + sweep);
                context.strokeStyle = segment.colour;
                context.lineWidth = thickness;
                context.lineCap = 'butt';
                context.stroke();
                angle += sweep;
            });

            context.textAlign = 'center';
            context.fillStyle = cssVar('--text-primary', '#fff');
            context.font = '700 ' + Math.round(radius * 0.42) + 'px ' + cssVar('--font-sans', 'sans-serif');
            context.fillText(String(Math.round(total * progress)), centreX, centreY + 4);
            context.fillStyle = cssVar('--text-muted', '#6f7899');
            context.font = '10px ' + cssVar('--font-sans', 'sans-serif');
            context.fillText(settings.caption || '', centreX, centreY + radius * 0.42);
        }
        animate(1100, render);
    }

    /**
     * Scatter plot used for the cohort map — each point is a student placed by
     * two behavioural axes and coloured by their risk band.
     */
    function scatterChart(canvas, options) {
        const settings = options || {};
        const points = (settings.points || []).map((p) => Object.assign({}, p, { colour: resolveColour(p.colour, '#818cf8') }));
        if (!points.length) { return; }

        const gridColour = cssVar('--chart-grid', 'rgba(255,255,255,0.07)');
        const textColour = cssVar('--text-muted', '#6f7899');
        const padding = { top: 16, right: 16, bottom: 30, left: 40 };

        const xs = points.map((point) => point.x);
        const ys = points.map((point) => point.y);
        const xMin = Math.min.apply(null, xs) - 0.6;
        const xMax = Math.max.apply(null, xs) + 0.6;
        const yMin = Math.min.apply(null, ys) - 0.6;
        const yMax = Math.max.apply(null, ys) + 0.6;

        function render(progress) {
            const prepared = prepare(canvas);
            const context = prepared.context;
            const width = prepared.width;
            const height = prepared.height;
            const plotWidth = width - padding.left - padding.right;
            const plotHeight = height - padding.top - padding.bottom;

            context.strokeStyle = gridColour;
            context.lineWidth = 1;
            for (let step = 0; step <= 4; step++) {
                const y = padding.top + (plotHeight / 4) * step;
                context.beginPath();
                context.moveTo(padding.left, y);
                context.lineTo(width - padding.right, y);
                context.stroke();
                const x = padding.left + (plotWidth / 4) * step;
                context.beginPath();
                context.moveTo(x, padding.top);
                context.lineTo(x, height - padding.bottom);
                context.stroke();
            }

            points.forEach((point, index) => {
                const delay = index / points.length;
                const local = Math.max(0, Math.min(1, (progress - delay * 0.4) / 0.6));
                if (local <= 0) { return; }
                const px = padding.left + ((point.x - xMin) / (xMax - xMin)) * plotWidth;
                const py = padding.top + plotHeight - ((point.y - yMin) / (yMax - yMin)) * plotHeight;

                context.beginPath();
                context.arc(px, py, 13 * local, 0, Math.PI * 2);
                context.fillStyle = point.colour + '22';
                context.fill();

                context.beginPath();
                context.arc(px, py, 5.5 * local, 0, Math.PI * 2);
                context.fillStyle = point.colour;
                context.fill();
            });

            context.fillStyle = textColour;
            context.font = '10px ' + cssVar('--font-sans', 'sans-serif');
            context.textAlign = 'center';
            context.fillText(settings.xLabel || '', width / 2, height - 8);
            context.save();
            context.translate(11, height / 2);
            context.rotate(-Math.PI / 2);
            context.fillText(settings.yLabel || '', 0, 0);
            context.restore();
        }
        animate(1300, render);
    }

    /** Horizontal progress rings used for weekly metric comparisons. */
    function radialProgress(canvas, value, max, colour) {
        colour = resolveColour(colour, cssVar('--brand-400', '#818cf8'));
        function render(progress) {
            const prepared = prepare(canvas);
            const context = prepared.context;
            const width = prepared.width;
            const height = prepared.height;
            const centreX = width / 2;
            const centreY = height / 2;
            const radius = Math.min(width, height) / 2 - 8;

            context.beginPath();
            context.arc(centreX, centreY, radius, 0, Math.PI * 2);
            context.strokeStyle = cssVar('--surface-3', 'rgba(255,255,255,0.11)');
            context.lineWidth = 8;
            context.stroke();

            context.beginPath();
            context.arc(centreX, centreY, radius, -Math.PI / 2,
                -Math.PI / 2 + (Math.min(1, value / max) * Math.PI * 2 * progress));
            context.strokeStyle = colour || cssVar('--brand-400', '#818cf8');
            context.lineWidth = 8;
            context.lineCap = 'round';
            context.stroke();
        }
        animate(1000, render);
    }

    global.WT = global.WT || {};
    global.WT.charts = { areaChart, sparkline, barChart, donutChart, scatterChart, radialProgress, cssVar };
})(window);
