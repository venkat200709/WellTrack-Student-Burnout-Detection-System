/**
 * WellTrack — API client.
 *
 * A thin, promise-based wrapper over fetch that owns the session token,
 * normalises the server's response envelope and turns non-2xx responses into
 * rich errors carrying per-field validation messages.
 */
(function (global) {
    'use strict';

    const TOKEN_KEY = 'welltrack.token';
    let token = null;

    /** Error type that preserves the server's fieldErrors map. */
    class ApiError extends Error {
        constructor(message, status, fieldErrors) {
            super(message);
            this.name = 'ApiError';
            this.status = status;
            this.fieldErrors = fieldErrors || {};
        }
    }

    async function request(method, path, body, options) {
        const settings = options || {};
        const headers = { Accept: 'application/json' };
        if (body !== undefined && body !== null) {
            headers['Content-Type'] = 'application/json';
        }
        if (token) {
            headers.Authorization = 'Bearer ' + token;
        }

        let response;
        try {
            response = await fetch(path, {
                method: method,
                headers: headers,
                body: body === undefined || body === null ? undefined : JSON.stringify(body)
            });
        } catch (networkError) {
            throw new ApiError('Cannot reach the WellTrack server. Is it still running?', 0, {});
        }

        if (settings.raw) {
            if (!response.ok) {
                throw new ApiError('Download failed', response.status, {});
            }
            return response.text();
        }

        const text = await response.text();
        let payload = {};
        if (text) {
            try {
                payload = JSON.parse(text);
            } catch (parseError) {
                throw new ApiError('The server returned an unreadable response', response.status, {});
            }
        }

        if (!response.ok) {
            throw new ApiError(
                payload.message || 'Request failed (' + response.status + ')',
                response.status,
                payload.fieldErrors);
        }
        // Endpoints wrap their result in { success, data }; auth returns it flat.
        return payload.data !== undefined ? payload.data : payload;
    }

    const api = {
        ApiError: ApiError,

        get token() { return token; },

        setToken(value) {
            token = value;
            if (value) {
                sessionStorage.setItem(TOKEN_KEY, value);
            } else {
                sessionStorage.removeItem(TOKEN_KEY);
            }
        },

        restoreToken() {
            token = sessionStorage.getItem(TOKEN_KEY);
            return token;
        },

        get: (path) => request('GET', path),
        post: (path, body) => request('POST', path, body === undefined ? {} : body),
        put: (path, body) => request('PUT', path, body),
        del: (path) => request('DELETE', path),
        text: (path) => request('GET', path, null, { raw: true }),

        // ---- Named endpoints -------------------------------------------
        login: (identifier, password) => request('POST', '/api/auth/login', { identifier, password }),
        register: (payload) => request('POST', '/api/auth/register', payload),
        logout: () => request('POST', '/api/auth/logout', {}),
        me: () => request('GET', '/api/auth/me'),
        passwordStrength: (password) => request('POST', '/api/auth/password-strength', { password }),

        dashboard: (studentId) => request('GET', studentId ? '/api/dashboard/' + studentId : '/api/dashboard'),
        checkIn: (payload) => request('POST', '/api/behavior', payload),
        todayLog: (studentId) => request('GET', '/api/behavior/' + studentId + '/today'),
        behaviourHistory: (studentId, days) => request('GET', '/api/behavior/' + studentId + '?days=' + days),

        riskHistory: (studentId, limit) => request('GET', '/api/risk/' + studentId + '/history?limit=' + (limit || 60)),
        reanalyse: (studentId) => request('POST', '/api/risk/' + studentId + '/analyse', {}),

        aiModel: () => request('GET', '/api/ai/model'),
        aiCapabilities: () => request('GET', '/api/ai/capabilities'),
        aiCohorts: () => request('GET', '/api/ai/cohorts'),
        aiExplain: (studentId) => request('GET', '/api/ai/explain/' + studentId),
        simulate: (payload) => request('POST', '/api/ai/simulate', payload),

        chatHistory: () => request('GET', '/api/chat'),
        chatSend: (message) => request('POST', '/api/chat', { message }),
        chatClear: () => request('DELETE', '/api/chat'),

        recommendations: (studentId) => request('GET', '/api/recommendations/' + studentId),
        completeRecommendation: (id) => request('POST', '/api/recommendations/' + id + '/complete', {}),
        leaderboard: () => request('GET', '/api/recommendations/leaderboard'),

        facultyOverview: () => request('GET', '/api/faculty/overview'),
        facultyPriority: () => request('GET', '/api/faculty/priority'),
        facultyTimeline: (days) => request('GET', '/api/faculty/timeline?days=' + (days || 30)),
        facultyBehaviour: () => request('GET', '/api/faculty/behaviour'),
        facultyAlerts: () => request('GET', '/api/faculty/alerts'),
        acknowledgeAlert: (id) => request('POST', '/api/faculty/alerts/' + id + '/acknowledge', {}),
        departments: () => request('GET', '/api/faculty/departments'),

        systemHealth: () => request('GET', '/api/system/health'),
        systemMetrics: () => request('GET', '/api/system/metrics'),
        auditTrail: () => request('GET', '/api/system/audit?limit=60'),

        /** Opens the server-sent-events channel for live updates. */
        openStream(handlers) {
            if (!token) { return null; }
            const source = new EventSource('/api/stream?token=' + encodeURIComponent(token));
            Object.keys(handlers).forEach((eventName) => {
                source.addEventListener(eventName, (event) => {
                    try {
                        handlers[eventName](JSON.parse(event.data));
                    } catch (error) {
                        console.warn('Malformed stream event', error);
                    }
                });
            });
            return source;
        }
    };

    global.WT = global.WT || {};
    global.WT.api = api;
})(window);
