package com.welltrack.model.enums;

/**
 * The self-reported mood scale.
 *
 * <p>Every constant maps to a numeric valence so that categorical mood entries
 * can feed the machine-learning feature vector directly.</p>
 */
public enum Mood {

    ENERGISED("Energised", 1.0, "⚡"),
    HAPPY("Happy", 0.75, "😄"),
    CALM("Calm", 0.6, "🍃"),
    NEUTRAL("Neutral", 0.5, "😐"),
    TIRED("Tired", 0.35, "😴"),
    ANXIOUS("Anxious", 0.2, "😰"),
    STRESSED("Stressed", 0.15, "😤"),
    LOW("Low", 0.05, "😔");

    private final String label;
    private final double valence;
    private final String glyph;

    Mood(String label, double valence, String glyph) {
        this.label = label;
        this.valence = valence;
        this.glyph = glyph;
    }

    public String label() {
        return label;
    }

    /** @return 0.0 (very negative) to 1.0 (very positive). */
    public double valence() {
        return valence;
    }

    public String glyph() {
        return glyph;
    }

    public static Mood from(String raw) {
        if (raw == null) {
            return NEUTRAL;
        }
        for (Mood mood : values()) {
            if (mood.name().equalsIgnoreCase(raw.trim()) || mood.label.equalsIgnoreCase(raw.trim())) {
                return mood;
            }
        }
        return NEUTRAL;
    }

    /** Maps a continuous valence back to the closest categorical mood. */
    public static Mood closestTo(double valence) {
        Mood best = NEUTRAL;
        double bestDistance = Double.MAX_VALUE;
        for (Mood mood : values()) {
            double distance = Math.abs(mood.valence - valence);
            if (distance < bestDistance) {
                bestDistance = distance;
                best = mood;
            }
        }
        return best;
    }
}
