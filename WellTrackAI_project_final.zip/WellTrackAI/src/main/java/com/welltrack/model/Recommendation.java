package com.welltrack.model;

import com.welltrack.core.json.JsonObject;
import com.welltrack.core.json.JsonSerializable;
import com.welltrack.model.enums.RecommendationCategory;

import java.time.LocalDateTime;

/**
 * A personalised, actionable recovery step produced by the recommendation
 * engine. Each carries an estimated risk reduction so students can see the
 * expected pay-off before committing to it.
 */
public class Recommendation implements Identifiable, JsonSerializable {

    private long id;
    private long studentId;
    private RecommendationCategory category = RecommendationCategory.STRESS;
    private String title = "";
    private String detail = "";
    private String actionStep = "";
    private int priority = 3;
    private double estimatedRiskReduction;
    private double evidenceStrength = 0.5;
    private boolean completed;
    private LocalDateTime completedAt;
    private LocalDateTime createdAt = LocalDateTime.now();

    public Recommendation() {
    }

    public Recommendation(long studentId, RecommendationCategory category, String title,
                          String detail, String actionStep, int priority, double estimatedRiskReduction) {
        this.studentId = studentId;
        this.category = category;
        this.title = title;
        this.detail = detail;
        this.actionStep = actionStep;
        this.priority = priority;
        this.estimatedRiskReduction = estimatedRiskReduction;
    }

    public void markCompleted() {
        this.completed = true;
        this.completedAt = LocalDateTime.now();
    }

    @Override
    public JsonObject toJson() {
        return JsonObject.of()
                .set("id", id)
                .set("studentId", studentId)
                .set("category", category.name())
                .set("categoryLabel", category.label())
                .set("categoryGlyph", category.glyph())
                .set("title", title)
                .set("detail", detail)
                .set("actionStep", actionStep)
                .set("priority", priority)
                .set("estimatedRiskReduction", estimatedRiskReduction)
                .set("evidenceStrength", evidenceStrength)
                .set("completed", completed)
                .setIfPresent("completedAt", completedAt == null ? null : completedAt.toString())
                .set("createdAt", createdAt == null ? null : createdAt.toString());
    }

    @Override
    public long getId() {
        return id;
    }

    @Override
    public void setId(long id) {
        this.id = id;
    }

    public long getStudentId() {
        return studentId;
    }

    public void setStudentId(long studentId) {
        this.studentId = studentId;
    }

    public RecommendationCategory getCategory() {
        return category;
    }

    public void setCategory(RecommendationCategory category) {
        this.category = category;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getDetail() {
        return detail;
    }

    public void setDetail(String detail) {
        this.detail = detail;
    }

    public String getActionStep() {
        return actionStep;
    }

    public void setActionStep(String actionStep) {
        this.actionStep = actionStep;
    }

    public int getPriority() {
        return priority;
    }

    public void setPriority(int priority) {
        this.priority = priority;
    }

    public double getEstimatedRiskReduction() {
        return estimatedRiskReduction;
    }

    public void setEstimatedRiskReduction(double estimatedRiskReduction) {
        this.estimatedRiskReduction = estimatedRiskReduction;
    }

    public double getEvidenceStrength() {
        return evidenceStrength;
    }

    public void setEvidenceStrength(double evidenceStrength) {
        this.evidenceStrength = evidenceStrength;
    }

    public boolean isCompleted() {
        return completed;
    }

    public void setCompleted(boolean completed) {
        this.completed = completed;
    }

    public LocalDateTime getCompletedAt() {
        return completedAt;
    }

    public void setCompletedAt(LocalDateTime completedAt) {
        this.completedAt = completedAt;
    }

    public LocalDateTime getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(LocalDateTime createdAt) {
        this.createdAt = createdAt;
    }
}
