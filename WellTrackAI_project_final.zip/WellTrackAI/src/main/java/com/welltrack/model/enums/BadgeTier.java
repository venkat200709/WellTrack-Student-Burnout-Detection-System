package com.welltrack.model.enums;

/** Gamification tiers awarded for consistent self-care streaks. */
public enum BadgeTier {

    BRONZE("Bronze", "#cd7f32", 1),
    SILVER("Silver", "#c0c8d8", 2),
    GOLD("Gold", "#f5c451", 3),
    PLATINUM("Platinum", "#7dd3fc", 4);

    private final String label;
    private final String colour;
    private final int weight;

    BadgeTier(String label, String colour, int weight) {
        this.label = label;
        this.colour = colour;
        this.weight = weight;
    }

    public String label() {
        return label;
    }

    public String colour() {
        return colour;
    }

    public int weight() {
        return weight;
    }
}
