package com.welltrack.model.enums;

/** Direction of a metric over the analysis window. */
public enum TrendDirection {

    IMPROVING("Improving", "▼"),
    STABLE("Stable", "▶"),
    WORSENING("Worsening", "▲");

    private final String label;
    private final String glyph;

    TrendDirection(String label, String glyph) {
        this.label = label;
        this.glyph = glyph;
    }

    public String label() {
        return label;
    }

    public String glyph() {
        return glyph;
    }

    /** Note: for risk metrics a falling slope is an improvement. */
    public static TrendDirection fromSlope(double slope, double tolerance) {
        if (slope > tolerance) {
            return WORSENING;
        }
        if (slope < -tolerance) {
            return IMPROVING;
        }
        return STABLE;
    }
}
