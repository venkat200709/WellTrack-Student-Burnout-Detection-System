package com.welltrack.model.enums;

/** Thematic buckets used by the recommendation engine. */
public enum RecommendationCategory {

    SLEEP("Sleep & Recovery", "🌙"),
    STUDY("Study Strategy", "📚"),
    STRESS("Stress Regulation", "🧘"),
    MOVEMENT("Movement & Energy", "🏃"),
    SOCIAL("Social Connection", "🤝"),
    ACADEMIC("Academic Support", "🎓"),
    DIGITAL("Digital Balance", "📵"),
    NUTRITION("Nutrition & Hydration", "🥗");

    private final String label;
    private final String glyph;

    RecommendationCategory(String label, String glyph) {
        this.label = label;
        this.glyph = glyph;
    }

    public String label() {
        return label;
    }

    public String glyph() {
        return glyph;
    }
}
