package com.welltrack.model.enums;

/** Authorship of a message in the AI wellness-coach transcript. */
public enum ChatRole {
    USER, COACH, SYSTEM
}
