package com.welltrack.model;

import com.welltrack.core.json.JsonObject;
import com.welltrack.core.json.JsonSerializable;
import com.welltrack.model.enums.BadgeTier;

import java.time.LocalDateTime;

/** A gamification award that reinforces healthy, consistent behaviour. */
public class Badge implements Identifiable, JsonSerializable {

    private long id;
    private long studentId;
    private String code = "";
    private String name = "";
    private String description = "";
    private String glyph = "🏅";
    private BadgeTier tier = BadgeTier.BRONZE;
    private int points;
    private LocalDateTime earnedAt = LocalDateTime.now();

    public Badge() {
    }

    public Badge(long studentId, String code, String name, String description,
                 String glyph, BadgeTier tier, int points) {
        this.studentId = studentId;
        this.code = code;
        this.name = name;
        this.description = description;
        this.glyph = glyph;
        this.tier = tier;
        this.points = points;
    }

    @Override
    public JsonObject toJson() {
        return JsonObject.of()
                .set("id", id)
                .set("studentId", studentId)
                .set("code", code)
                .set("name", name)
                .set("description", description)
                .set("glyph", glyph)
                .set("tier", tier.name())
                .set("tierLabel", tier.label())
                .set("tierColour", tier.colour())
                .set("points", points)
                .set("earnedAt", earnedAt == null ? null : earnedAt.toString());
    }

    @Override
    public long getId() {
        return id;
    }

    @Override
    public void setId(long id) {
        this.id = id;
    }

    public long getStudentId() {
        return studentId;
    }

    public void setStudentId(long studentId) {
        this.studentId = studentId;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getGlyph() {
        return glyph;
    }

    public void setGlyph(String glyph) {
        this.glyph = glyph;
    }

    public BadgeTier getTier() {
        return tier;
    }

    public void setTier(BadgeTier tier) {
        this.tier = tier;
    }

    public int getPoints() {
        return points;
    }

    public void setPoints(int points) {
        this.points = points;
    }

    public LocalDateTime getEarnedAt() {
        return earnedAt;
    }

    public void setEarnedAt(LocalDateTime earnedAt) {
        this.earnedAt = earnedAt;
    }
}
