package com.welltrack.model;

import com.welltrack.core.json.JsonObject;
import com.welltrack.core.json.JsonSerializable;
import com.welltrack.core.util.Numbers;

/**
 * One explainability record: how much a single behavioural feature pushed the
 * burnout probability up or down, and why that matters in plain English.
 *
 * <p>Implemented as a {@code record} — an immutable, value-based carrier that
 * fits an explanation perfectly.</p>
 *
 * @param feature     the machine-readable feature name
 * @param label       a human-friendly label for the dashboard
 * @param value       the student's observed value
 * @param contribution signed contribution to the log-odds of burnout
 * @param explanation a sentence a non-technical reader can act on
 */
public record RiskDriver(String feature,
                         String label,
                         double value,
                         double contribution,
                         String explanation) implements JsonSerializable {

    /** @return true when the feature increases burnout risk. */
    public boolean isAggravating() {
        return contribution > 0;
    }

    /** @return the absolute influence, used for ranking and bar widths. */
    public double magnitude() {
        return Math.abs(contribution);
    }

    @Override
    public JsonObject toJson() {
        return JsonObject.of()
                .set("feature", feature)
                .set("label", label)
                .set("value", Numbers.round(value, 2))
                .set("contribution", Numbers.round(contribution, 4))
                .set("magnitude", Numbers.round(magnitude(), 4))
                .set("direction", isAggravating() ? "AGGRAVATING" : "PROTECTIVE")
                .set("explanation", explanation);
    }
}
