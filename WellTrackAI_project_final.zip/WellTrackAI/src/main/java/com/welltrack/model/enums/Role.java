package com.welltrack.model.enums;

/**
 * The security roles recognised by WellTrack.
 *
 * <p>Each constant carries its own default landing route and a rank used for
 * hierarchical checks — {@code ADMIN} implicitly satisfies any lower role.</p>
 */
public enum Role {

    STUDENT("Student", "/dashboard", 1),
    FACULTY("Faculty Mentor", "/faculty", 2),
    ADMIN("Administrator", "/admin", 3);

    private final String label;
    private final String landingRoute;
    private final int rank;

    Role(String label, String landingRoute, int rank) {
        this.label = label;
        this.landingRoute = landingRoute;
        this.rank = rank;
    }

    public String label() {
        return label;
    }

    public String landingRoute() {
        return landingRoute;
    }

    public int rank() {
        return rank;
    }

    /** @return true when this role satisfies the {@code required} role. */
    public boolean satisfies(Role required) {
        return this == required || this.rank >= required.rank;
    }

    public static Role from(String raw) {
        if (raw == null) {
            return STUDENT;
        }
        for (Role role : values()) {
            if (role.name().equalsIgnoreCase(raw.trim())) {
                return role;
            }
        }
        return STUDENT;
    }
}
