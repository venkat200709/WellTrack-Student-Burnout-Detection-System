package com.welltrack.model;

import com.welltrack.core.json.JsonObject;
import com.welltrack.core.json.JsonSerializable;

import java.time.LocalDateTime;

/**
 * An immutable security/audit record. Every authentication attempt, lockout,
 * role escalation and data export is written here, giving the system a
 * tamper-evident trail that can be reviewed by an administrator.
 */
public class AuditEvent implements Identifiable, JsonSerializable {

    private long id;
    private String actor = "anonymous";
    private String action = "";
    private String detail = "";
    private String ipAddress = "";
    private boolean successful = true;
    private LocalDateTime occurredAt = LocalDateTime.now();

    public AuditEvent() {
    }

    public AuditEvent(String actor, String action, String detail, String ipAddress, boolean successful) {
        this.actor = actor;
        this.action = action;
        this.detail = detail;
        this.ipAddress = ipAddress;
        this.successful = successful;
    }

    @Override
    public JsonObject toJson() {
        return JsonObject.of()
                .set("id", id)
                .set("actor", actor)
                .set("action", action)
                .set("detail", detail)
                .set("ipAddress", ipAddress)
                .set("successful", successful)
                .set("occurredAt", occurredAt == null ? null : occurredAt.toString());
    }

    @Override
    public long getId() {
        return id;
    }

    @Override
    public void setId(long id) {
        this.id = id;
    }

    public String getActor() {
        return actor;
    }

    public void setActor(String actor) {
        this.actor = actor;
    }

    public String getAction() {
        return action;
    }

    public void setAction(String action) {
        this.action = action;
    }

    public String getDetail() {
        return detail;
    }

    public void setDetail(String detail) {
        this.detail = detail;
    }

    public String getIpAddress() {
        return ipAddress;
    }

    public void setIpAddress(String ipAddress) {
        this.ipAddress = ipAddress;
    }

    public boolean isSuccessful() {
        return successful;
    }

    public void setSuccessful(boolean successful) {
        this.successful = successful;
    }

    public LocalDateTime getOccurredAt() {
        return occurredAt;
    }

    public void setOccurredAt(LocalDateTime occurredAt) {
        this.occurredAt = occurredAt;
    }
}
