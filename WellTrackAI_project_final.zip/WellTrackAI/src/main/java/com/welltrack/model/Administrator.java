package com.welltrack.model;

import com.welltrack.core.json.JsonObject;
import com.welltrack.model.enums.Role;

/** An institution-level administrator with full visibility over the platform. */
public class Administrator extends User {

    private String office = "Office of Student Welfare";

    public Administrator() {
        super();
    }

    public Administrator(String username, String email, String fullName, String passwordHash) {
        super(username, email, fullName, passwordHash, Role.ADMIN);
    }

    @Override
    public String headline() {
        return "Institution control centre";
    }

    @Override
    public String profileSummary() {
        return "Administrator · " + office;
    }

    @Override
    protected void decorate(JsonObject target) {
        target.set("office", office);
    }

    public String getOffice() {
        return office;
    }

    public void setOffice(String office) {
        this.office = office;
    }
}
