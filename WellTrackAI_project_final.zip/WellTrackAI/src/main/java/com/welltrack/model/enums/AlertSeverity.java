package com.welltrack.model.enums;

/** Severity ladder for wellness alerts. */
public enum AlertSeverity {

    INFO("Information", 1, "#38bdf8"),
    WARNING("Warning", 2, "#fbbf24"),
    URGENT("Urgent", 3, "#fb7185"),
    CRITICAL("Critical", 4, "#ef4444");

    private final String label;
    private final int weight;
    private final String colour;

    AlertSeverity(String label, int weight, String colour) {
        this.label = label;
        this.weight = weight;
        this.colour = colour;
    }

    public String label() {
        return label;
    }

    public int weight() {
        return weight;
    }

    public String colour() {
        return colour;
    }

    public static AlertSeverity forRisk(RiskLevel level) {
        return switch (level) {
            case CRITICAL -> CRITICAL;
            case HIGH -> URGENT;
            case ELEVATED -> WARNING;
            default -> INFO;
        };
    }
}
