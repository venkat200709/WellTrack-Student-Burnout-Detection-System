package com.welltrack.model;

import com.welltrack.core.json.JsonObject;
import com.welltrack.core.json.JsonSerializable;
import com.welltrack.model.enums.AlertSeverity;

import java.time.LocalDateTime;

/**
 * A proactive early-warning notification raised by the analysis pipeline and
 * routed to the student and their faculty mentor.
 */
public class Alert implements Identifiable, JsonSerializable {

    private long id;
    private long studentId;
    private String studentName = "";
    private AlertSeverity severity = AlertSeverity.INFO;
    private String title = "";
    private String message = "";
    private String category = "GENERAL";
    private double triggeringScore;
    private boolean acknowledged;
    private String acknowledgedBy;
    private LocalDateTime acknowledgedAt;
    private LocalDateTime createdAt = LocalDateTime.now();

    public Alert() {
    }

    public Alert(long studentId, AlertSeverity severity, String title, String message) {
        this.studentId = studentId;
        this.severity = severity;
        this.title = title;
        this.message = message;
    }

    public void acknowledge(String actor) {
        this.acknowledged = true;
        this.acknowledgedBy = actor;
        this.acknowledgedAt = LocalDateTime.now();
    }

    /** @return minutes since the alert was raised — drives the "x min ago" chip. */
    public long ageInMinutes() {
        return java.time.Duration.between(createdAt, LocalDateTime.now()).toMinutes();
    }

    @Override
    public JsonObject toJson() {
        return JsonObject.of()
                .set("id", id)
                .set("studentId", studentId)
                .set("studentName", studentName)
                .set("severity", severity.name())
                .set("severityLabel", severity.label())
                .set("severityColour", severity.colour())
                .set("severityWeight", severity.weight())
                .set("title", title)
                .set("message", message)
                .set("category", category)
                .set("triggeringScore", triggeringScore)
                .set("acknowledged", acknowledged)
                .setIfPresent("acknowledgedBy", acknowledgedBy)
                .setIfPresent("acknowledgedAt", acknowledgedAt == null ? null : acknowledgedAt.toString())
                .set("createdAt", createdAt == null ? null : createdAt.toString())
                .set("ageMinutes", ageInMinutes());
    }

    @Override
    public long getId() {
        return id;
    }

    @Override
    public void setId(long id) {
        this.id = id;
    }

    public long getStudentId() {
        return studentId;
    }

    public void setStudentId(long studentId) {
        this.studentId = studentId;
    }

    public String getStudentName() {
        return studentName;
    }

    public void setStudentName(String studentName) {
        this.studentName = studentName;
    }

    public AlertSeverity getSeverity() {
        return severity;
    }

    public void setSeverity(AlertSeverity severity) {
        this.severity = severity;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public double getTriggeringScore() {
        return triggeringScore;
    }

    public void setTriggeringScore(double triggeringScore) {
        this.triggeringScore = triggeringScore;
    }

    public boolean isAcknowledged() {
        return acknowledged;
    }

    public void setAcknowledged(boolean acknowledged) {
        this.acknowledged = acknowledged;
    }

    public String getAcknowledgedBy() {
        return acknowledgedBy;
    }

    public void setAcknowledgedBy(String acknowledgedBy) {
        this.acknowledgedBy = acknowledgedBy;
    }

    public LocalDateTime getAcknowledgedAt() {
        return acknowledgedAt;
    }

    public void setAcknowledgedAt(LocalDateTime acknowledgedAt) {
        this.acknowledgedAt = acknowledgedAt;
    }

    public LocalDateTime getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(LocalDateTime createdAt) {
        this.createdAt = createdAt;
    }
}
