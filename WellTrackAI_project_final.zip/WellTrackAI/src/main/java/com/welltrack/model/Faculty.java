package com.welltrack.model;

import com.welltrack.core.json.JsonObject;
import com.welltrack.model.enums.Role;

/**
 * A faculty mentor who supervises a cohort of students and receives their
 * early-warning alerts.
 */
public class Faculty extends User {

    private String employeeCode;
    private String department;
    private String designation;
    private int menteeCapacity = 40;

    public Faculty() {
        super();
    }

    public Faculty(String username, String email, String fullName, String passwordHash,
                   String employeeCode, String department, String designation) {
        super(username, email, fullName, passwordHash, Role.FACULTY);
        this.employeeCode = employeeCode;
        this.department = department;
        this.designation = designation;
    }

    @Override
    public String headline() {
        return "Mentor console · " + (department == null ? "Department" : department);
    }

    @Override
    public String profileSummary() {
        return "%s · %s".formatted(
                designation == null ? "Faculty" : designation,
                employeeCode == null ? "Staff" : employeeCode);
    }

    @Override
    protected void decorate(JsonObject target) {
        target.set("employeeCode", employeeCode)
                .set("department", department)
                .set("designation", designation)
                .set("menteeCapacity", menteeCapacity);
    }

    public String getEmployeeCode() {
        return employeeCode;
    }

    public void setEmployeeCode(String employeeCode) {
        this.employeeCode = employeeCode;
    }

    public String getDepartment() {
        return department;
    }

    public void setDepartment(String department) {
        this.department = department;
    }

    public String getDesignation() {
        return designation;
    }

    public void setDesignation(String designation) {
        this.designation = designation;
    }

    public int getMenteeCapacity() {
        return menteeCapacity;
    }

    public void setMenteeCapacity(int menteeCapacity) {
        this.menteeCapacity = menteeCapacity;
    }
}
