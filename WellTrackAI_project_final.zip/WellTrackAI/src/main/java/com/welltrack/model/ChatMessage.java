package com.welltrack.model;

import com.welltrack.core.json.JsonObject;
import com.welltrack.core.json.JsonSerializable;
import com.welltrack.model.enums.ChatRole;

import java.time.LocalDateTime;

/** One turn in the conversation with the AI wellness coach. */
public class ChatMessage implements Identifiable, JsonSerializable {

    private long id;
    private long studentId;
    private ChatRole role = ChatRole.USER;
    private String content = "";
    private String detectedIntent = "";
    private double sentiment;
    private double confidence;
    private String source = "local";
    private LocalDateTime createdAt = LocalDateTime.now();

    public ChatMessage() {
    }

    public ChatMessage(long studentId, ChatRole role, String content) {
        this.studentId = studentId;
        this.role = role;
        this.content = content;
    }

    @Override
    public JsonObject toJson() {
        return JsonObject.of()
                .set("id", id)
                .set("studentId", studentId)
                .set("role", role.name())
                .set("content", content)
                .set("detectedIntent", detectedIntent)
                .set("sentiment", sentiment)
                .set("confidence", confidence)
                .set("source", source)
                .set("createdAt", createdAt == null ? null : createdAt.toString());
    }

    @Override
    public long getId() {
        return id;
    }

    @Override
    public void setId(long id) {
        this.id = id;
    }

    public long getStudentId() {
        return studentId;
    }

    public void setStudentId(long studentId) {
        this.studentId = studentId;
    }

    public ChatRole getRole() {
        return role;
    }

    public void setRole(ChatRole role) {
        this.role = role;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public String getDetectedIntent() {
        return detectedIntent;
    }

    public void setDetectedIntent(String detectedIntent) {
        this.detectedIntent = detectedIntent;
    }

    public double getSentiment() {
        return sentiment;
    }

    public void setSentiment(double sentiment) {
        this.sentiment = sentiment;
    }

    public double getConfidence() {
        return confidence;
    }

    public void setConfidence(double confidence) {
        this.confidence = confidence;
    }

    public String getSource() {
        return source;
    }

    public void setSource(String source) {
        this.source = source;
    }

    public LocalDateTime getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(LocalDateTime createdAt) {
        this.createdAt = createdAt;
    }
}
