package com.welltrack.model;

/**
 * Contract for anything the generic repository layer can persist.
 *
 * <p>Keeping identity behind an interface lets {@code Repository<T>} stay fully
 * generic while remaining type-safe — a textbook use of abstraction.</p>
 */
public interface Identifiable {

    long getId();

    void setId(long id);
}
