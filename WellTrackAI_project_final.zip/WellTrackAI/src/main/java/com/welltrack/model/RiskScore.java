package com.welltrack.model;

import com.welltrack.core.json.JsonArray;
import com.welltrack.core.json.JsonObject;
import com.welltrack.core.json.JsonSerializable;
import com.welltrack.core.util.Numbers;
import com.welltrack.model.enums.RiskLevel;
import com.welltrack.model.enums.TrendDirection;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * The output of the burnout analysis pipeline for one student at one instant.
 *
 * <p>A score is deliberately not a single number: it records the contribution
 * of each ensemble member (model, heuristic, anomaly, trend), the confidence,
 * the ranked drivers behind the verdict and the seven-day forecast. Storing the
 * full explanation makes the system auditable — a mentor can always see why a
 * student was flagged.</p>
 */
public class RiskScore implements Identifiable, JsonSerializable {

    private long id;
    private long studentId;
    private LocalDateTime computedAt = LocalDateTime.now();
    private double score;
    private double modelProbability;
    private double heuristicScore;
    private double anomalyScore;
    private double trendScore;
    private double confidence;
    private RiskLevel level = RiskLevel.STABLE;
    private TrendDirection trend = TrendDirection.STABLE;
    private int windowDays;
    private String summary = "";
    private List<RiskDriver> drivers = new ArrayList<>();
    private double[] forecast = new double[0];

    public RiskScore() {
    }

    public RiskScore(long studentId, double score) {
        this.studentId = studentId;
        setScore(score);
    }

    public final void setScore(double score) {
        this.score = Numbers.clamp(score, 0, 100);
        this.level = RiskLevel.of(this.score);
    }

    /** @return the strongest aggravating drivers, highest influence first. */
    public List<RiskDriver> topAggravators(int limit) {
        List<RiskDriver> aggravating = new ArrayList<>();
        for (RiskDriver driver : drivers) {
            if (driver.isAggravating()) {
                aggravating.add(driver);
            }
        }
        aggravating.sort((a, b) -> Double.compare(b.magnitude(), a.magnitude()));
        return aggravating.subList(0, Math.min(limit, aggravating.size()));
    }

    /** @return the strongest protective drivers — the habits worth reinforcing. */
    public List<RiskDriver> topProtectors(int limit) {
        List<RiskDriver> protective = new ArrayList<>();
        for (RiskDriver driver : drivers) {
            if (!driver.isAggravating()) {
                protective.add(driver);
            }
        }
        protective.sort((a, b) -> Double.compare(b.magnitude(), a.magnitude()));
        return protective.subList(0, Math.min(limit, protective.size()));
    }

    @Override
    public JsonObject toJson() {
        JsonArray driverArray = new JsonArray();
        for (RiskDriver driver : drivers) {
            driverArray.add(driver.toJson());
        }
        JsonArray forecastArray = new JsonArray();
        for (double value : forecast) {
            forecastArray.add(Numbers.round(value, 1));
        }
        return JsonObject.of()
                .set("id", id)
                .set("studentId", studentId)
                .set("computedAt", computedAt == null ? null : computedAt.toString())
                .set("score", Numbers.round(score, 1))
                .set("level", level.name())
                .set("levelLabel", level.label())
                .set("levelColour", level.colour())
                .set("guidance", level.guidance())
                .set("requiresIntervention", level.requiresIntervention())
                .set("modelProbability", Numbers.round(modelProbability, 4))
                .set("heuristicScore", Numbers.round(heuristicScore, 1))
                .set("anomalyScore", Numbers.round(anomalyScore, 1))
                .set("trendScore", Numbers.round(trendScore, 1))
                .set("confidence", Numbers.round(confidence, 3))
                .set("trend", trend.name())
                .set("trendLabel", trend.label())
                .set("trendGlyph", trend.glyph())
                .set("windowDays", windowDays)
                .set("summary", summary)
                .set("drivers", driverArray)
                .set("forecast", forecastArray);
    }

    @Override
    public long getId() {
        return id;
    }

    @Override
    public void setId(long id) {
        this.id = id;
    }

    public long getStudentId() {
        return studentId;
    }

    public void setStudentId(long studentId) {
        this.studentId = studentId;
    }

    public LocalDateTime getComputedAt() {
        return computedAt;
    }

    public void setComputedAt(LocalDateTime computedAt) {
        this.computedAt = computedAt;
    }

    public double getScore() {
        return score;
    }

    public double getModelProbability() {
        return modelProbability;
    }

    public void setModelProbability(double modelProbability) {
        this.modelProbability = modelProbability;
    }

    public double getHeuristicScore() {
        return heuristicScore;
    }

    public void setHeuristicScore(double heuristicScore) {
        this.heuristicScore = heuristicScore;
    }

    public double getAnomalyScore() {
        return anomalyScore;
    }

    public void setAnomalyScore(double anomalyScore) {
        this.anomalyScore = anomalyScore;
    }

    public double getTrendScore() {
        return trendScore;
    }

    public void setTrendScore(double trendScore) {
        this.trendScore = trendScore;
    }

    public double getConfidence() {
        return confidence;
    }

    public void setConfidence(double confidence) {
        this.confidence = Numbers.clamp(confidence, 0, 1);
    }

    public RiskLevel getLevel() {
        return level;
    }

    public void setLevel(RiskLevel level) {
        this.level = level;
    }

    public TrendDirection getTrend() {
        return trend;
    }

    public void setTrend(TrendDirection trend) {
        this.trend = trend;
    }

    public int getWindowDays() {
        return windowDays;
    }

    public void setWindowDays(int windowDays) {
        this.windowDays = windowDays;
    }

    public String getSummary() {
        return summary;
    }

    public void setSummary(String summary) {
        this.summary = summary;
    }

    public List<RiskDriver> getDrivers() {
        return Collections.unmodifiableList(drivers);
    }

    public void setDrivers(List<RiskDriver> drivers) {
        this.drivers = drivers == null ? new ArrayList<>() : new ArrayList<>(drivers);
    }

    public double[] getForecast() {
        return forecast.clone();
    }

    public void setForecast(double[] forecast) {
        this.forecast = forecast == null ? new double[0] : forecast.clone();
    }

    @Override
    public String toString() {
        return "RiskScore{student=%d, score=%.1f, level=%s, confidence=%.2f}"
                .formatted(studentId, score, level, confidence);
    }
}
