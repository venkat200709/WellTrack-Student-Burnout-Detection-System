package com.welltrack.model.enums;

/**
 * Burnout risk bands. The colour and advice attached to each band drive both
 * the dashboard gauge and the wording of generated alerts.
 */
public enum RiskLevel {

    THRIVING(0, 20, "Thriving", "#22d3a7", "Excellent balance. Keep your current rhythm."),
    STABLE(20, 40, "Stable", "#4ade80", "Healthy patterns with minor fluctuations."),
    ELEVATED(40, 60, "Elevated", "#fbbf24", "Early warning signs are appearing this week."),
    HIGH(60, 80, "High Risk", "#fb7185", "Sustained strain detected. Intervene now."),
    CRITICAL(80, 101, "Critical", "#ef4444", "Severe burnout indicators. Mentor contact advised.");

    private final double lowerBound;
    private final double upperBound;
    private final String label;
    private final String colour;
    private final String guidance;

    RiskLevel(double lowerBound, double upperBound, String label, String colour, String guidance) {
        this.lowerBound = lowerBound;
        this.upperBound = upperBound;
        this.label = label;
        this.colour = colour;
        this.guidance = guidance;
    }

    /** Maps a 0-100 score onto its band. */
    public static RiskLevel of(double score) {
        for (RiskLevel level : values()) {
            if (score >= level.lowerBound && score < level.upperBound) {
                return level;
            }
        }
        return score >= 80 ? CRITICAL : THRIVING;
    }

    public String label() {
        return label;
    }

    public String colour() {
        return colour;
    }

    public String guidance() {
        return guidance;
    }

    public double lowerBound() {
        return lowerBound;
    }

    public boolean requiresIntervention() {
        return this == HIGH || this == CRITICAL;
    }
}
