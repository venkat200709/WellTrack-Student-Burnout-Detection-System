package com.welltrack.model;

import com.welltrack.core.json.JsonObject;
import com.welltrack.core.json.JsonSerializable;
import com.welltrack.model.enums.Role;

import java.time.LocalDateTime;
import java.util.Objects;

/**
 * Abstract base of every account in WellTrack.
 *
 * <p>This class is the root of the project's inheritance hierarchy —
 * {@link Student}, {@link Faculty} and {@link Administrator} extend it. It owns
 * identity, credentials and the account-security state machine (failed
 * attempts, lockout window, activation), while leaving the presentation of a
 * profile to its subclasses through the abstract {@link #profileSummary()} and
 * {@link #headline()} methods.</p>
 *
 * <p>All fields are private and reached through accessors, demonstrating strict
 * encapsulation; the credential fields are additionally never exposed by
 * {@link #toJson()}.</p>
 */
public abstract class User implements Identifiable, JsonSerializable {

    private long id;
    private String username;
    private String email;
    private String fullName;
    private String passwordHash;
    private Role role;
    private boolean active = true;
    private int failedLoginAttempts;
    private LocalDateTime lockedUntil;
    private LocalDateTime createdAt = LocalDateTime.now();
    private LocalDateTime lastLoginAt;
    private String avatarSeed;

    protected User() {
        // Required by the datastore mapper.
    }

    protected User(String username, String email, String fullName, String passwordHash, Role role) {
        this.username = username;
        this.email = email;
        this.fullName = fullName;
        this.passwordHash = passwordHash;
        this.role = role;
        this.avatarSeed = username == null ? "wt" : username;
    }

    /** @return a one-line description of the account, rendered on the profile card. */
    public abstract String profileSummary();

    /** @return the greeting headline shown at the top of the dashboard. */
    public abstract String headline();

    /** Polymorphic hook: subclasses add their own attributes to the JSON view. */
    protected void decorate(JsonObject target) {
        // Default implementation adds nothing.
    }

    @Override
    public final JsonObject toJson() {
        JsonObject json = JsonObject.of()
                .set("id", id)
                .set("username", username)
                .set("email", email)
                .set("fullName", fullName)
                .set("role", role == null ? Role.STUDENT.name() : role.name())
                .set("roleLabel", role == null ? Role.STUDENT.label() : role.label())
                .set("landingRoute", role == null ? Role.STUDENT.landingRoute() : role.landingRoute())
                .set("active", active)
                .set("avatarSeed", avatarSeed)
                .set("initials", initials())
                .set("headline", headline())
                .set("profileSummary", profileSummary())
                .setIfPresent("lastLoginAt", lastLoginAt == null ? null : lastLoginAt.toString())
                .setIfPresent("createdAt", createdAt == null ? null : createdAt.toString());
        decorate(json);
        return json;
    }

    /** @return up to two uppercase initials for the avatar chip. */
    public String initials() {
        if (fullName == null || fullName.isBlank()) {
            return username == null ? "WT" : username.substring(0, Math.min(2, username.length())).toUpperCase();
        }
        String[] parts = fullName.trim().split("\\s+");
        if (parts.length == 1) {
            return parts[0].substring(0, Math.min(2, parts[0].length())).toUpperCase();
        }
        return ("" + parts[0].charAt(0) + parts[parts.length - 1].charAt(0)).toUpperCase();
    }

    /** @return true when the account is currently locked out of the system. */
    public boolean isLocked() {
        return lockedUntil != null && lockedUntil.isAfter(LocalDateTime.now());
    }

    /** Records a failed sign-in and applies the lockout policy. */
    public void registerFailedLogin(int maxAttempts, int lockMinutes) {
        failedLoginAttempts++;
        if (failedLoginAttempts >= maxAttempts) {
            lockedUntil = LocalDateTime.now().plusMinutes(lockMinutes);
        }
    }

    /** Clears the lockout state after a successful sign-in. */
    public void registerSuccessfulLogin() {
        failedLoginAttempts = 0;
        lockedUntil = null;
        lastLoginAt = LocalDateTime.now();
    }

    public int remainingAttempts(int maxAttempts) {
        return Math.max(0, maxAttempts - failedLoginAttempts);
    }

    @Override
    public long getId() {
        return id;
    }

    @Override
    public void setId(long id) {
        this.id = id;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getFullName() {
        return fullName;
    }

    public void setFullName(String fullName) {
        this.fullName = fullName;
    }

    public String getPasswordHash() {
        return passwordHash;
    }

    public void setPasswordHash(String passwordHash) {
        this.passwordHash = passwordHash;
    }

    public Role getRole() {
        return role;
    }

    public void setRole(Role role) {
        this.role = role;
    }

    public boolean isActive() {
        return active;
    }

    public void setActive(boolean active) {
        this.active = active;
    }

    public int getFailedLoginAttempts() {
        return failedLoginAttempts;
    }

    public void setFailedLoginAttempts(int failedLoginAttempts) {
        this.failedLoginAttempts = failedLoginAttempts;
    }

    public LocalDateTime getLockedUntil() {
        return lockedUntil;
    }

    public void setLockedUntil(LocalDateTime lockedUntil) {
        this.lockedUntil = lockedUntil;
    }

    public LocalDateTime getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(LocalDateTime createdAt) {
        this.createdAt = createdAt;
    }

    public LocalDateTime getLastLoginAt() {
        return lastLoginAt;
    }

    public void setLastLoginAt(LocalDateTime lastLoginAt) {
        this.lastLoginAt = lastLoginAt;
    }

    public String getAvatarSeed() {
        return avatarSeed;
    }

    public void setAvatarSeed(String avatarSeed) {
        this.avatarSeed = avatarSeed;
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (!(other instanceof User user)) {
            return false;
        }
        return id != 0 && id == user.id;
    }

    @Override
    public int hashCode() {
        return Objects.hash(id);
    }

    @Override
    public String toString() {
        return "%s{id=%d, username='%s', role=%s}"
                .formatted(getClass().getSimpleName(), id, username, role);
    }
}
