package com.welltrack.model;

import com.welltrack.core.json.JsonObject;
import com.welltrack.model.enums.Role;

/**
 * A student account together with the academic profile that feeds the
 * burnout model.
 *
 * <p>Extends {@link User} and overrides {@link #headline()} and
 * {@link #profileSummary()} — run-time polymorphism the dashboard relies on
 * without ever testing the concrete type.</p>
 */
public class Student extends User {

    private String registerNumber;
    private String department;
    private String section;
    private int yearOfStudy;
    private double cgpa;
    private double attendancePercentage;
    private long mentorId;
    private int streakDays;
    private int wellnessPoints;
    private int creditLoad;
    private String hostelStatus = "Day Scholar";

    public Student() {
        super();
    }

    public Student(String username, String email, String fullName, String passwordHash) {
        super(username, email, fullName, passwordHash, Role.STUDENT);
    }

    /** Convenience constructor used by the seeder — demonstrates constructor overloading. */
    public Student(String username, String email, String fullName, String passwordHash,
                   String registerNumber, String department, String section, int yearOfStudy) {
        this(username, email, fullName, passwordHash);
        this.registerNumber = registerNumber;
        this.department = department;
        this.section = section;
        this.yearOfStudy = yearOfStudy;
    }

    @Override
    public String headline() {
        String name = getFullName() == null ? "Student" : getFullName().split("\\s+")[0];
        return "Welcome back, " + name;
    }

    @Override
    public String profileSummary() {
        return "%s · %s Year %d%s".formatted(
                registerNumber == null ? "Unregistered" : registerNumber,
                department == null ? "CSE" : department,
                yearOfStudy,
                section == null || section.isBlank() ? "" : " · Section " + section);
    }

    @Override
    protected void decorate(JsonObject target) {
        target.set("registerNumber", registerNumber)
                .set("department", department)
                .set("section", section)
                .set("yearOfStudy", yearOfStudy)
                .set("cgpa", cgpa)
                .set("attendancePercentage", attendancePercentage)
                .set("mentorId", mentorId)
                .set("streakDays", streakDays)
                .set("wellnessPoints", wellnessPoints)
                .set("creditLoad", creditLoad)
                .set("hostelStatus", hostelStatus)
                .set("level", level())
                .set("levelTitle", levelTitle());
    }

    /** Gamification level derived from accumulated wellness points. */
    public int level() {
        return 1 + (int) Math.floor(Math.sqrt(Math.max(0, wellnessPoints) / 40.0));
    }

    public String levelTitle() {
        return switch (Math.min(6, level())) {
            case 1 -> "Getting Started";
            case 2 -> "Consistent";
            case 3 -> "Balanced";
            case 4 -> "Resilient";
            case 5 -> "Thriving";
            default -> "Wellness Champion";
        };
    }

    public void awardPoints(int points) {
        this.wellnessPoints = Math.max(0, this.wellnessPoints + points);
    }

    public String getRegisterNumber() {
        return registerNumber;
    }

    public void setRegisterNumber(String registerNumber) {
        this.registerNumber = registerNumber;
    }

    public String getDepartment() {
        return department;
    }

    public void setDepartment(String department) {
        this.department = department;
    }

    public String getSection() {
        return section;
    }

    public void setSection(String section) {
        this.section = section;
    }

    public int getYearOfStudy() {
        return yearOfStudy;
    }

    public void setYearOfStudy(int yearOfStudy) {
        this.yearOfStudy = yearOfStudy;
    }

    public double getCgpa() {
        return cgpa;
    }

    public void setCgpa(double cgpa) {
        this.cgpa = cgpa;
    }

    public double getAttendancePercentage() {
        return attendancePercentage;
    }

    public void setAttendancePercentage(double attendancePercentage) {
        this.attendancePercentage = attendancePercentage;
    }

    public long getMentorId() {
        return mentorId;
    }

    public void setMentorId(long mentorId) {
        this.mentorId = mentorId;
    }

    public int getStreakDays() {
        return streakDays;
    }

    public void setStreakDays(int streakDays) {
        this.streakDays = streakDays;
    }

    public int getWellnessPoints() {
        return wellnessPoints;
    }

    public void setWellnessPoints(int wellnessPoints) {
        this.wellnessPoints = wellnessPoints;
    }

    public int getCreditLoad() {
        return creditLoad;
    }

    public void setCreditLoad(int creditLoad) {
        this.creditLoad = creditLoad;
    }

    public String getHostelStatus() {
        return hostelStatus;
    }

    public void setHostelStatus(String hostelStatus) {
        this.hostelStatus = hostelStatus;
    }
}
