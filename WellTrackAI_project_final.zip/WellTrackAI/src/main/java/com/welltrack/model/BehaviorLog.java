package com.welltrack.model;

import com.welltrack.core.json.JsonObject;
import com.welltrack.core.json.JsonSerializable;
import com.welltrack.core.util.Numbers;
import com.welltrack.model.enums.Mood;

import java.time.LocalDate;
import java.time.LocalDateTime;

/**
 * One day of behavioural telemetry for a single student.
 *
 * <p>This is the atom of the entire system: every risk score, forecast, cohort
 * and recommendation is derived from a sequence of these entries. The class
 * also knows how to project itself into the numeric feature vector consumed by
 * the machine-learning layer, keeping feature construction in exactly one
 * place.</p>
 */
public class BehaviorLog implements Identifiable, JsonSerializable {

    /** Order of the features produced by {@link #toFeatureVector()}. */
    public static final String[] FEATURE_NAMES = {
            "sleepHours",
            "sleepDebt",
            "studyHours",
            "studyOverload",
            "screenTimeHours",
            "exerciseMinutes",
            "socialMinutes",
            "stressLevel",
            "moodValence",
            "attendanceRatio",
            "assignmentsPending",
            "caffeineCups",
            "mealsSkipped",
            "deadlinePressure"
    };

    private long id;
    private long studentId;
    private LocalDate logDate = LocalDate.now();
    private double sleepHours = 7;
    private double studyHours = 4;
    private double screenTimeHours = 4;
    private int exerciseMinutes = 20;
    private int socialMinutes = 60;
    private int stressLevel = 5;
    private Mood mood = Mood.NEUTRAL;
    private int classesAttended = 5;
    private int classesScheduled = 6;
    private int assignmentsPending = 2;
    private int caffeineCups = 1;
    private int mealsSkipped;
    private int deadlinePressure = 3;
    private String journalNote = "";
    private LocalDateTime createdAt = LocalDateTime.now();

    public BehaviorLog() {
    }

    public BehaviorLog(long studentId, LocalDate logDate) {
        this.studentId = studentId;
        this.logDate = logDate;
    }

    /**
     * Full constructor used by the seeder and the import tools.
     */
    public BehaviorLog(long studentId, LocalDate logDate, double sleepHours, double studyHours,
                       double screenTimeHours, int exerciseMinutes, int socialMinutes,
                       int stressLevel, Mood mood, int classesAttended, int classesScheduled,
                       int assignmentsPending, int caffeineCups, int mealsSkipped, int deadlinePressure) {
        this.studentId = studentId;
        this.logDate = logDate;
        this.sleepHours = sleepHours;
        this.studyHours = studyHours;
        this.screenTimeHours = screenTimeHours;
        this.exerciseMinutes = exerciseMinutes;
        this.socialMinutes = socialMinutes;
        this.stressLevel = stressLevel;
        this.mood = mood;
        this.classesAttended = classesAttended;
        this.classesScheduled = classesScheduled;
        this.assignmentsPending = assignmentsPending;
        this.caffeineCups = caffeineCups;
        this.mealsSkipped = mealsSkipped;
        this.deadlinePressure = deadlinePressure;
    }

    /**
     * Projects the entry into the model's feature space.
     *
     * <p>Two engineered features are added on top of the raw measurements:
     * <em>sleep debt</em> (how far below the eight-hour target the student is)
     * and <em>study overload</em> (hours beyond a sustainable six-hour day).
     * Both are clamped at zero so that a well-rested student contributes no
     * positive risk pressure.</p>
     *
     * @return a vector aligned with {@link #FEATURE_NAMES}
     */
    public double[] toFeatureVector() {
        return new double[]{
                sleepHours,
                Math.max(0, 8.0 - sleepHours),
                studyHours,
                Math.max(0, studyHours - 6.0),
                screenTimeHours,
                exerciseMinutes,
                socialMinutes,
                stressLevel,
                mood == null ? 0.5 : mood.valence(),
                attendanceRatio(),
                assignmentsPending,
                caffeineCups,
                mealsSkipped,
                deadlinePressure
        };
    }

    public double attendanceRatio() {
        if (classesScheduled <= 0) {
            return 1.0;
        }
        return Numbers.clamp((double) classesAttended / classesScheduled, 0, 1);
    }

    /**
     * A transparent, hand-tuned wellness heuristic in the 0-100 range used as
     * one member of the risk ensemble and as a fallback before the model has
     * been trained.
     */
    public double heuristicStrainScore() {
        double strain = 0;
        strain += Math.max(0, 8.0 - sleepHours) * 6.5;
        strain += Math.max(0, studyHours - 6.0) * 4.0;
        strain += Math.max(0, screenTimeHours - 5.0) * 2.5;
        strain += stressLevel * 4.2;
        strain += (1.0 - (mood == null ? 0.5 : mood.valence())) * 14.0;
        strain += (1.0 - attendanceRatio()) * 18.0;
        strain += assignmentsPending * 1.8;
        strain += mealsSkipped * 3.0;
        strain += Math.max(0, caffeineCups - 2) * 2.2;
        strain += deadlinePressure * 2.0;
        strain -= Math.min(exerciseMinutes, 60) * 0.18;
        strain -= Math.min(socialMinutes, 120) * 0.06;
        return Numbers.clamp(strain, 0, 100);
    }

    @Override
    public JsonObject toJson() {
        return JsonObject.of()
                .set("id", id)
                .set("studentId", studentId)
                .set("logDate", logDate == null ? null : logDate.toString())
                .set("sleepHours", Numbers.round(sleepHours, 2))
                .set("studyHours", Numbers.round(studyHours, 2))
                .set("screenTimeHours", Numbers.round(screenTimeHours, 2))
                .set("exerciseMinutes", exerciseMinutes)
                .set("socialMinutes", socialMinutes)
                .set("stressLevel", stressLevel)
                .set("mood", mood == null ? Mood.NEUTRAL.name() : mood.name())
                .set("moodLabel", mood == null ? Mood.NEUTRAL.label() : mood.label())
                .set("moodGlyph", mood == null ? Mood.NEUTRAL.glyph() : mood.glyph())
                .set("classesAttended", classesAttended)
                .set("classesScheduled", classesScheduled)
                .set("attendanceRatio", Numbers.round(attendanceRatio(), 3))
                .set("assignmentsPending", assignmentsPending)
                .set("caffeineCups", caffeineCups)
                .set("mealsSkipped", mealsSkipped)
                .set("deadlinePressure", deadlinePressure)
                .set("journalNote", journalNote == null ? "" : journalNote)
                .set("strainScore", Numbers.round(heuristicStrainScore(), 1))
                .set("createdAt", createdAt == null ? null : createdAt.toString());
    }

    @Override
    public long getId() {
        return id;
    }

    @Override
    public void setId(long id) {
        this.id = id;
    }

    public long getStudentId() {
        return studentId;
    }

    public void setStudentId(long studentId) {
        this.studentId = studentId;
    }

    public LocalDate getLogDate() {
        return logDate;
    }

    public void setLogDate(LocalDate logDate) {
        this.logDate = logDate;
    }

    public double getSleepHours() {
        return sleepHours;
    }

    public void setSleepHours(double sleepHours) {
        this.sleepHours = sleepHours;
    }

    public double getStudyHours() {
        return studyHours;
    }

    public void setStudyHours(double studyHours) {
        this.studyHours = studyHours;
    }

    public double getScreenTimeHours() {
        return screenTimeHours;
    }

    public void setScreenTimeHours(double screenTimeHours) {
        this.screenTimeHours = screenTimeHours;
    }

    public int getExerciseMinutes() {
        return exerciseMinutes;
    }

    public void setExerciseMinutes(int exerciseMinutes) {
        this.exerciseMinutes = exerciseMinutes;
    }

    public int getSocialMinutes() {
        return socialMinutes;
    }

    public void setSocialMinutes(int socialMinutes) {
        this.socialMinutes = socialMinutes;
    }

    public int getStressLevel() {
        return stressLevel;
    }

    public void setStressLevel(int stressLevel) {
        this.stressLevel = stressLevel;
    }

    public Mood getMood() {
        return mood;
    }

    public void setMood(Mood mood) {
        this.mood = mood;
    }

    public int getClassesAttended() {
        return classesAttended;
    }

    public void setClassesAttended(int classesAttended) {
        this.classesAttended = classesAttended;
    }

    public int getClassesScheduled() {
        return classesScheduled;
    }

    public void setClassesScheduled(int classesScheduled) {
        this.classesScheduled = classesScheduled;
    }

    public int getAssignmentsPending() {
        return assignmentsPending;
    }

    public void setAssignmentsPending(int assignmentsPending) {
        this.assignmentsPending = assignmentsPending;
    }

    public int getCaffeineCups() {
        return caffeineCups;
    }

    public void setCaffeineCups(int caffeineCups) {
        this.caffeineCups = caffeineCups;
    }

    public int getMealsSkipped() {
        return mealsSkipped;
    }

    public void setMealsSkipped(int mealsSkipped) {
        this.mealsSkipped = mealsSkipped;
    }

    public int getDeadlinePressure() {
        return deadlinePressure;
    }

    public void setDeadlinePressure(int deadlinePressure) {
        this.deadlinePressure = deadlinePressure;
    }

    public String getJournalNote() {
        return journalNote;
    }

    public void setJournalNote(String journalNote) {
        this.journalNote = journalNote;
    }

    public LocalDateTime getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(LocalDateTime createdAt) {
        this.createdAt = createdAt;
    }

    @Override
    public String toString() {
        return "BehaviorLog{student=%d, date=%s, sleep=%.1fh, study=%.1fh, stress=%d, mood=%s}"
                .formatted(studentId, logDate, sleepHours, studyHours, stressLevel, mood);
    }
}
