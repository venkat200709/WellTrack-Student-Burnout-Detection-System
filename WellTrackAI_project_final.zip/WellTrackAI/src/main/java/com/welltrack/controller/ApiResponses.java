package com.welltrack.controller;

import com.welltrack.core.http.HttpResponse;
import com.welltrack.core.http.HttpStatus;
import com.welltrack.core.json.JsonObject;

/**
 * Uniform response envelopes.
 *
 * <p>Every endpoint returns the same shape — {@code success}, {@code message}
 * and {@code data} — so the front end has exactly one code path for handling
 * results and one for handling failures.</p>
 */
final class ApiResponses {

    private ApiResponses() {
    }

    static HttpResponse ok(Object data) {
        return HttpResponse.ok(JsonObject.of().set("success", true).set("data", data));
    }

    static HttpResponse ok(String message, Object data) {
        return HttpResponse.ok(JsonObject.of()
                .set("success", true)
                .set("message", message)
                .set("data", data));
    }

    static HttpResponse created(String message, Object data) {
        return HttpResponse.json(HttpStatus.CREATED, JsonObject.of()
                .set("success", true)
                .set("message", message)
                .set("data", data));
    }

    static HttpResponse message(String message) {
        return HttpResponse.ok(JsonObject.of().set("success", true).set("message", message));
    }
}
