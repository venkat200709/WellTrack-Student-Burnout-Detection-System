package com.welltrack.controller;

import com.welltrack.core.http.HttpRequest;
import com.welltrack.core.http.HttpResponse;
import com.welltrack.core.http.Router;
import com.welltrack.core.json.JsonArray;
import com.welltrack.core.json.JsonObject;
import com.welltrack.model.RiskScore;
import com.welltrack.model.Student;
import com.welltrack.repository.RiskScoreRepository;
import com.welltrack.security.SecurityFilter;
import com.welltrack.service.RiskAnalysisService;
import com.welltrack.service.StudentService;

/** Endpoints for computing, reading and explaining burnout risk. */
public final class RiskController {

    private final RiskAnalysisService riskAnalysisService;
    private final StudentService studentService;
    private final RiskScoreRepository riskScores;

    public RiskController(RiskAnalysisService riskAnalysisService,
                          StudentService studentService,
                          RiskScoreRepository riskScores) {
        this.riskAnalysisService = riskAnalysisService;
        this.studentService = studentService;
        this.riskScores = riskScores;
    }

    public void register(Router router) {
        router.group("/api/risk")
                .get("/{studentId}", this::latest).authenticated()
                .post("/{studentId}/analyse", this::analyse).authenticated()
                .get("/{studentId}/history", this::history).authenticated()
                .get("/{studentId}/forecast", this::forecast).authenticated()
                .post("/analyse-all", this::analyseAll).roles("FACULTY", "ADMIN")
                .get("/distribution", this::distribution).roles("FACULTY", "ADMIN");
    }

    /** GET /api/risk/{studentId} */
    private HttpResponse latest(HttpRequest request) {
        long studentId = request.pathVariableLong("studentId");
        SecurityFilter.requireSelfOrElevated(request.requirePrincipal(), studentId);
        Student student = studentService.require(studentId);
        RiskScore score = riskAnalysisService.latest(studentId)
                .orElseGet(() -> riskAnalysisService.analyse(student, false));
        return ApiResponses.ok(score.toJson());
    }

    /** POST /api/risk/{studentId}/analyse — forces an immediate re-analysis. */
    private HttpResponse analyse(HttpRequest request) {
        long studentId = request.pathVariableLong("studentId");
        SecurityFilter.requireSelfOrElevated(request.requirePrincipal(), studentId);
        RiskScore score = riskAnalysisService.analyse(studentService.require(studentId), true);
        return ApiResponses.ok("Analysis complete", score.toJson());
    }

    /** GET /api/risk/{studentId}/history */
    private HttpResponse history(HttpRequest request) {
        long studentId = request.pathVariableLong("studentId");
        SecurityFilter.requireSelfOrElevated(request.requirePrincipal(), studentId);
        int limit = request.queryInt("limit", 60);

        JsonArray array = new JsonArray();
        for (RiskScore score : riskScores.findHistory(studentId, limit)) {
            array.add(JsonObject.of()
                    .set("computedAt", String.valueOf(score.getComputedAt()))
                    .set("score", com.welltrack.core.util.Numbers.round(score.getScore(), 1))
                    .set("level", score.getLevel().name())
                    .set("levelColour", score.getLevel().colour())
                    .set("confidence", com.welltrack.core.util.Numbers.round(score.getConfidence(), 2)));
        }
        return ApiResponses.ok(JsonObject.of().set("count", array.size()).set("history", array));
    }

    /** GET /api/risk/{studentId}/forecast */
    private HttpResponse forecast(HttpRequest request) {
        long studentId = request.pathVariableLong("studentId");
        SecurityFilter.requireSelfOrElevated(request.requirePrincipal(), studentId);
        return ApiResponses.ok(riskAnalysisService.forecastFor(studentId).toJson());
    }

    /** POST /api/risk/analyse-all — parallel sweep across the whole cohort. */
    private HttpResponse analyseAll(HttpRequest request) {
        long started = System.currentTimeMillis();
        int analysed = riskAnalysisService.analyseAll().size();
        return ApiResponses.ok("Cohort analysis complete", JsonObject.of()
                .set("studentsAnalysed", analysed)
                .set("elapsedMillis", System.currentTimeMillis() - started));
    }

    /** GET /api/risk/distribution */
    private HttpResponse distribution(HttpRequest request) {
        JsonObject distribution = new JsonObject();
        riskAnalysisService.riskDistribution()
                .forEach((level, count) -> distribution.set(level.name(), count));
        return ApiResponses.ok(distribution);
    }
}
