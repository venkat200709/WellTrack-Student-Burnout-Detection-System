package com.welltrack.controller;

import com.welltrack.core.http.HttpRequest;
import com.welltrack.core.http.HttpResponse;
import com.welltrack.core.http.Router;
import com.welltrack.core.json.JsonObject;
import com.welltrack.core.util.Validation;
import com.welltrack.dto.AuthResult;
import com.welltrack.dto.LoginRequest;
import com.welltrack.dto.RegistrationRequest;
import com.welltrack.model.User;
import com.welltrack.security.AuthService;

/**
 * Authentication endpoints: sign in, register, sign out, session introspection
 * and password change.
 *
 * <p>Note the deliberate absence of security logic here. Route-level
 * authorisation is declared in {@link #register(Router)} and enforced by
 * {@link com.welltrack.security.SecurityFilter}, so a controller can never
 * forget to protect an endpoint.</p>
 */
public final class AuthController {

    private final AuthService authService;

    public AuthController(AuthService authService) {
        this.authService = authService;
    }

    public void register(Router router) {
        router.group("/api/auth")
                .post("/login", this::login)
                .post("/register", this::signUp)
                .post("/logout", this::logout)
                .get("/me", this::me).authenticated()
                .post("/password", this::changePassword).authenticated()
                .post("/password-strength", this::passwordStrength)
                .get("/policy", this::policy);
    }

    /** POST /api/auth/login */
    private HttpResponse login(HttpRequest request) {
        LoginRequest credentials = LoginRequest.from(request.json());
        AuthResult result = authService.login(credentials, request.remoteAddress());
        return HttpResponse.ok(result.toJson());
    }

    /** POST /api/auth/register */
    private HttpResponse signUp(HttpRequest request) {
        RegistrationRequest registration = RegistrationRequest.from(request.json());
        AuthResult result = authService.register(registration, request.remoteAddress());
        return HttpResponse.ok(result.toJson());
    }

    /** POST /api/auth/logout */
    private HttpResponse logout(HttpRequest request) {
        authService.logout(request.header("authorization"), request.remoteAddress());
        return ApiResponses.message("You have been signed out. See you soon.");
    }

    /** GET /api/auth/me */
    private HttpResponse me(HttpRequest request) {
        User user = request.requirePrincipal();
        return ApiResponses.ok(user.toJson());
    }

    /** POST /api/auth/password */
    private HttpResponse changePassword(HttpRequest request) {
        JsonObject body = request.json();
        User user = request.requirePrincipal();
        authService.changePassword(user,
                body.getString("currentPassword", ""),
                body.getString("newPassword", ""),
                request.remoteAddress());
        return ApiResponses.message("Password updated. Please sign in again on your other devices.");
    }

    /**
     * POST /api/auth/password-strength
     *
     * <p>Powers the live strength meter on the registration form. Scoring runs
     * server-side so the policy has exactly one definition.</p>
     */
    private HttpResponse passwordStrength(HttpRequest request) {
        String password = request.json().getString("password", "");
        int score = Validation.passwordStrength(password);
        String label = score >= 80 ? "Excellent"
                : score >= 60 ? "Strong"
                : score >= 40 ? "Fair"
                : score >= 20 ? "Weak"
                : "Very weak";
        return ApiResponses.ok(JsonObject.of()
                .set("score", score)
                .set("label", label)
                .set("meetsPolicy", Validation.check().password("password", password).isValid()
                        && password.length() >= 8));
    }

    /** GET /api/auth/policy — lets the UI describe the rules before they are broken. */
    private HttpResponse policy(HttpRequest request) {
        return ApiResponses.ok(JsonObject.of()
                .set("minLength", 8)
                .set("requiresUppercase", true)
                .set("requiresLowercase", true)
                .set("requiresDigit", true)
                .set("maxFailedAttempts", authService.maxFailedAttempts())
                .set("hashing", "PBKDF2-HMAC-SHA256, 210,000 iterations, 16-byte random salt")
                .set("tokens", "HMAC-SHA256 signed JWT with server-side revocation"));
    }
}
