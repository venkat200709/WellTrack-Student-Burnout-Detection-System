package com.welltrack.controller;

import com.welltrack.core.http.HttpRequest;
import com.welltrack.core.http.HttpResponse;
import com.welltrack.core.http.Router;
import com.welltrack.core.json.JsonArray;
import com.welltrack.core.json.JsonObject;
import com.welltrack.model.Student;
import com.welltrack.model.User;
import com.welltrack.model.enums.Role;
import com.welltrack.security.SecurityFilter;
import com.welltrack.service.StudentService;

/** CRUD endpoints for student records. */
public final class StudentController {

    private final StudentService studentService;

    public StudentController(StudentService studentService) {
        this.studentService = studentService;
    }

    public void register(Router router) {
        router.group("/api/students")
                .get("", this::list).roles("FACULTY", "ADMIN")
                .get("/{id}", this::detail).authenticated()
                .put("/{id}", this::update).authenticated()
                .post("/{id}/mentor", this::assignMentor).roles("FACULTY", "ADMIN")
                .post("/{id}/deactivate", this::deactivate).roles("ADMIN")
                .post("/{id}/reactivate", this::reactivate).roles("ADMIN")
                .delete("/{id}", this::delete).roles("ADMIN");
    }

    /** GET /api/students?q=... — searchable roster, scoped to the caller's mentees. */
    private HttpResponse list(HttpRequest request) {
        User principal = request.requirePrincipal();
        String query = request.query("q", "");
        java.util.List<Student> students = studentService.search(query);

        if (principal.getRole() == Role.FACULTY && request.query("scope", "mine").equals("mine")) {
            students = students.stream()
                    .filter(student -> student.getMentorId() == principal.getId())
                    .toList();
        }

        JsonArray array = new JsonArray();
        students.forEach(student -> array.add(student.toJson()));
        return ApiResponses.ok(JsonObject.of()
                .set("count", array.size())
                .set("students", array));
    }

    /** GET /api/students/{id} */
    private HttpResponse detail(HttpRequest request) {
        long id = request.pathVariableLong("id");
        SecurityFilter.requireSelfOrElevated(request.requirePrincipal(), id);
        return ApiResponses.ok(studentService.require(id).toJson());
    }

    /** PUT /api/students/{id} */
    private HttpResponse update(HttpRequest request) {
        long id = request.pathVariableLong("id");
        SecurityFilter.requireSelfOrElevated(request.requirePrincipal(), id);
        JsonObject body = request.json();
        Student existing = studentService.require(id);

        Student updated = studentService.updateProfile(id,
                body.getString("fullName", existing.getFullName()),
                body.getString("department", existing.getDepartment()),
                body.getString("section", existing.getSection()),
                body.getInt("yearOfStudy", existing.getYearOfStudy()),
                body.getDouble("cgpa", existing.getCgpa()),
                body.getDouble("attendancePercentage", existing.getAttendancePercentage()),
                body.getInt("creditLoad", existing.getCreditLoad()),
                body.getString("hostelStatus", existing.getHostelStatus()));
        return ApiResponses.ok("Profile updated", updated.toJson());
    }

    /** POST /api/students/{id}/mentor */
    private HttpResponse assignMentor(HttpRequest request) {
        long id = request.pathVariableLong("id");
        long mentorId = request.json().getLong("mentorId", 0);
        return ApiResponses.ok("Mentor assigned",
                studentService.assignMentor(id, mentorId).toJson());
    }

    private HttpResponse deactivate(HttpRequest request) {
        studentService.deactivate(request.pathVariableLong("id"));
        return ApiResponses.message("Account deactivated");
    }

    private HttpResponse reactivate(HttpRequest request) {
        studentService.reactivate(request.pathVariableLong("id"));
        return ApiResponses.message("Account reactivated");
    }

    /** DELETE /api/students/{id} — removes the student and all their records. */
    private HttpResponse delete(HttpRequest request) {
        studentService.delete(request.pathVariableLong("id"));
        return ApiResponses.message("Student record and all associated data deleted");
    }
}
