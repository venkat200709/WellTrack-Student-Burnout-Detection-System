package com.welltrack.controller;

import com.welltrack.core.http.HttpRequest;
import com.welltrack.core.http.HttpResponse;
import com.welltrack.core.http.Router;
import com.welltrack.core.http.WebServer;
import com.welltrack.core.json.JsonArray;
import com.welltrack.core.json.JsonObject;
import com.welltrack.model.AuditEvent;
import com.welltrack.repository.AuditEventRepository;
import com.welltrack.repository.BehaviorLogRepository;
import com.welltrack.repository.UserRepository;
import com.welltrack.repository.datastore.Datastore;
import com.welltrack.security.SessionRegistry;
import com.welltrack.service.EventBus;

import java.lang.management.ManagementFactory;
import java.time.LocalDateTime;
import java.util.function.Supplier;

/**
 * Operational endpoints: health, runtime metrics, live sessions and the
 * security audit trail.
 */
public final class SystemController {

    private final Supplier<WebServer> serverSupplier;
    private final Datastore datastore;
    private final UserRepository users;
    private final BehaviorLogRepository behaviorLogs;
    private final AuditEventRepository auditEvents;
    private final SessionRegistry sessions;
    private final EventBus eventBus;
    private final LocalDateTime startedAt = LocalDateTime.now();

    public SystemController(Supplier<WebServer> serverSupplier,
                            Datastore datastore,
                            UserRepository users,
                            BehaviorLogRepository behaviorLogs,
                            AuditEventRepository auditEvents,
                            SessionRegistry sessions,
                            EventBus eventBus) {
        this.serverSupplier = serverSupplier;
        this.datastore = datastore;
        this.users = users;
        this.behaviorLogs = behaviorLogs;
        this.auditEvents = auditEvents;
        this.sessions = sessions;
        this.eventBus = eventBus;
    }

    public void register(Router router) {
        router.group("/api/system")
                .get("/health", this::health)
                .get("/metrics", this::metrics).roles("ADMIN")
                .get("/sessions", this::activeSessions).roles("ADMIN")
                .get("/audit", this::audit).roles("ADMIN");
    }

    /** GET /api/system/health — public liveness probe. */
    private HttpResponse health(HttpRequest request) {
        return HttpResponse.ok(JsonObject.of()
                .set("status", "UP")
                .set("application", "WellTrack")
                .set("version", "2.0.0")
                .set("startedAt", startedAt.toString())
                .set("javaVersion", System.getProperty("java.version"))
                .set("datastore", datastore.describe()));
    }

    /** GET /api/system/metrics — runtime and domain counters. */
    private HttpResponse metrics(HttpRequest request) {
        Runtime runtime = Runtime.getRuntime();
        long usedMemory = (runtime.totalMemory() - runtime.freeMemory()) / (1024 * 1024);

        return ApiResponses.ok(JsonObject.of()
                .set("http", serverSupplier.get().metrics())
                .set("jvm", JsonObject.of()
                        .set("usedMemoryMb", usedMemory)
                        .set("maxMemoryMb", runtime.maxMemory() / (1024 * 1024))
                        .set("availableProcessors", runtime.availableProcessors())
                        .set("threadCount", ManagementFactory.getThreadMXBean().getThreadCount())
                        .set("uptimeSeconds", ManagementFactory.getRuntimeMXBean().getUptime() / 1000))
                .set("domain", JsonObject.of()
                        .set("users", users.count())
                        .set("students", users.findAllStudents().size())
                        .set("behaviourLogs", behaviorLogs.count())
                        .set("auditEvents", auditEvents.count()))
                .set("realtime", JsonObject.of()
                        .set("activeSessions", sessions.activeCount())
                        .set("liveListeners", eventBus.listenerCount())
                        .set("eventsPublished", eventBus.publishedCount())));
    }

    private HttpResponse activeSessions(HttpRequest request) {
        return ApiResponses.ok(JsonObject.of()
                .set("count", sessions.activeCount())
                .set("sessions", sessions.describeAll()));
    }

    /** GET /api/system/audit — the security trail. */
    private HttpResponse audit(HttpRequest request) {
        JsonArray array = new JsonArray();
        for (AuditEvent event : auditEvents.recent(request.queryInt("limit", 100))) {
            array.add(event.toJson());
        }
        return ApiResponses.ok(JsonObject.of().set("count", array.size()).set("events", array));
    }
}
