package com.welltrack.controller;

import com.welltrack.core.http.HttpRequest;
import com.welltrack.core.http.HttpResponse;
import com.welltrack.core.http.Router;
import com.welltrack.core.json.JsonArray;
import com.welltrack.core.json.JsonObject;
import com.welltrack.model.Alert;
import com.welltrack.model.Student;
import com.welltrack.model.User;
import com.welltrack.model.enums.AlertSeverity;
import com.welltrack.model.enums.Role;
import com.welltrack.service.AlertService;
import com.welltrack.service.AnalyticsService;
import com.welltrack.service.StudentService;

import java.util.List;

/** The mentor and administrator console. */
public final class FacultyController {

    private final AnalyticsService analyticsService;
    private final StudentService studentService;
    private final AlertService alertService;

    public FacultyController(AnalyticsService analyticsService,
                             StudentService studentService,
                             AlertService alertService) {
        this.analyticsService = analyticsService;
        this.studentService = studentService;
        this.alertService = alertService;
    }

    public void register(Router router) {
        router.group("/api/faculty")
                .get("/overview", this::overview).roles("FACULTY", "ADMIN")
                .get("/priority", this::priority).roles("FACULTY", "ADMIN")
                .get("/timeline", this::timeline).roles("FACULTY", "ADMIN")
                .get("/behaviour", this::behaviour).roles("FACULTY", "ADMIN")
                .get("/departments", this::departments).roles("ADMIN")
                .get("/alerts", this::alerts).roles("FACULTY", "ADMIN")
                .post("/alerts/{id}/acknowledge", this::acknowledge).roles("FACULTY", "ADMIN")
                .post("/alerts/raise", this::raise).roles("FACULTY", "ADMIN");
    }

    /**
     * Resolves the caller's scope: an administrator sees the whole institution,
     * a mentor sees their own mentees (falling back to the full roster when they
     * have not been assigned any yet, so the console is never blank).
     */
    private List<Student> scopeFor(User principal) {
        if (principal.getRole() == Role.ADMIN) {
            return studentService.findAll();
        }
        List<Student> mentees = studentService.forMentor(principal.getId());
        return mentees.isEmpty() ? studentService.findAll() : mentees;
    }

    private HttpResponse overview(HttpRequest request) {
        User principal = request.requirePrincipal();
        List<Student> scope = scopeFor(principal);
        return ApiResponses.ok(analyticsService.overview(scope)
                .set("scope", principal.getRole() == Role.ADMIN ? "institution" : "mentees")
                .set("mentor", principal.toJson()));
    }

    private HttpResponse priority(HttpRequest request) {
        List<Student> scope = scopeFor(request.requirePrincipal());
        return ApiResponses.ok(JsonObject.of()
                .set("queue", analyticsService.priorityQueue(scope, request.queryInt("limit", 10))));
    }

    private HttpResponse timeline(HttpRequest request) {
        List<Student> scope = scopeFor(request.requirePrincipal());
        return ApiResponses.ok(JsonObject.of()
                .set("series", analyticsService.riskTimeline(scope, request.queryInt("days", 30))));
    }

    private HttpResponse behaviour(HttpRequest request) {
        List<Student> scope = scopeFor(request.requirePrincipal());
        return ApiResponses.ok(analyticsService.behaviourAverages(scope));
    }

    private HttpResponse departments(HttpRequest request) {
        return ApiResponses.ok(JsonObject.of()
                .set("departments", analyticsService.departmentBreakdown()));
    }

    private HttpResponse alerts(HttpRequest request) {
        List<Long> ids = scopeFor(request.requirePrincipal()).stream()
                .map(Student::getId).toList();
        JsonArray array = new JsonArray();
        alertService.forStudents(ids).stream()
                .limit(request.queryInt("limit", 40))
                .forEach(alert -> array.add(alert.toJson()));
        return ApiResponses.ok(JsonObject.of()
                .set("count", array.size())
                .set("alerts", array));
    }

    private HttpResponse acknowledge(HttpRequest request) {
        Alert alert = alertService.acknowledge(request.pathVariableLong("id"),
                request.requirePrincipal().getFullName());
        return ApiResponses.ok("Alert acknowledged", alert.toJson());
    }

    /** POST /api/faculty/alerts/raise — a mentor escalates manually. */
    private HttpResponse raise(HttpRequest request) {
        JsonObject body = request.json();
        Student student = studentService.require(body.getLong("studentId", 0));
        Alert alert = alertService.raiseManual(student,
                body.getString("title", "Mentor follow-up requested"),
                body.getString("message", "Your mentor would like to speak with you this week."),
                AlertSeverity.valueOf(body.getString("severity", AlertSeverity.WARNING.name())));
        return ApiResponses.created("Alert raised", alert.toJson());
    }
}
