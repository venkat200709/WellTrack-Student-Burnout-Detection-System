package com.welltrack.controller;

import com.welltrack.core.http.HttpRequest;
import com.welltrack.core.http.HttpResponse;
import com.welltrack.core.http.Router;
import com.welltrack.core.json.JsonArray;
import com.welltrack.core.json.JsonObject;
import com.welltrack.core.util.Numbers;
import com.welltrack.model.RiskScore;
import com.welltrack.model.Student;
import com.welltrack.model.User;
import com.welltrack.security.SecurityFilter;
import com.welltrack.service.AlertService;
import com.welltrack.service.BehaviorService;
import com.welltrack.service.GamificationService;
import com.welltrack.service.RecommendationService;
import com.welltrack.service.RiskAnalysisService;
import com.welltrack.service.StudentService;
import com.welltrack.ai.CohortAnalyzer;
import com.welltrack.ai.ForecastEngine;

import java.util.Optional;

/**
 * The single aggregated endpoint that paints the student dashboard.
 *
 * <p>Assembling the whole view server-side means one network round trip instead
 * of eight, which is the difference between a dashboard that fades in smoothly
 * and one that pops in piece by piece.</p>
 */
public final class DashboardController {

    private final StudentService studentService;
    private final BehaviorService behaviorService;
    private final RiskAnalysisService riskAnalysisService;
    private final RecommendationService recommendationService;
    private final AlertService alertService;
    private final GamificationService gamificationService;
    private final CohortAnalyzer cohortAnalyzer;

    public DashboardController(StudentService studentService,
                               BehaviorService behaviorService,
                               RiskAnalysisService riskAnalysisService,
                               RecommendationService recommendationService,
                               AlertService alertService,
                               GamificationService gamificationService,
                               CohortAnalyzer cohortAnalyzer) {
        this.studentService = studentService;
        this.behaviorService = behaviorService;
        this.riskAnalysisService = riskAnalysisService;
        this.recommendationService = recommendationService;
        this.alertService = alertService;
        this.gamificationService = gamificationService;
        this.cohortAnalyzer = cohortAnalyzer;
    }

    public void register(Router router) {
        router.group("/api/dashboard")
                .get("", this::dashboard).authenticated()
                .get("/{studentId}", this::dashboardFor).authenticated();
    }

    private HttpResponse dashboard(HttpRequest request) {
        return build(request.requirePrincipal().getId(), request.requirePrincipal());
    }

    private HttpResponse dashboardFor(HttpRequest request) {
        long studentId = request.pathVariableLong("studentId");
        SecurityFilter.requireSelfOrElevated(request.requirePrincipal(), studentId);
        return build(studentId, request.requirePrincipal());
    }

    private HttpResponse build(long studentId, User viewer) {
        Student student = studentService.require(studentId);

        Optional<RiskScore> latest = riskAnalysisService.latest(studentId);
        RiskScore score = latest.orElseGet(() -> riskAnalysisService.analyse(student, false));
        ForecastEngine.Forecast forecast = riskAnalysisService.forecastFor(studentId);

        JsonArray history = new JsonArray();
        behaviorService.history(studentId, 30).forEach(log -> history.add(log.toJson()));

        JsonArray recommendations = new JsonArray();
        recommendationService.active(studentId)
                .forEach(item -> recommendations.add(item.toJson()));

        JsonArray alerts = new JsonArray();
        alertService.forStudent(studentId).stream().limit(8)
                .forEach(alert -> alerts.add(alert.toJson()));

        JsonArray badges = new JsonArray();
        gamificationService.badgesOf(studentId).forEach(badge -> badges.add(badge.toJson()));

        CohortAnalyzer.Cohort cohort = cohortAnalyzer.cohortOf(studentId);
        JsonObject cohortJson = cohort == null
                ? JsonObject.of().set("assigned", false)
                : JsonObject.of()
                .set("assigned", true)
                .set("name", cohort.name())
                .set("description", cohort.description())
                .set("size", cohort.size())
                .set("averageRisk", Numbers.round(cohort.averageRisk(), 1))
                .set("comparedToCohort", Numbers.round(score.getScore() - cohort.averageRisk(), 1));

        return ApiResponses.ok(JsonObject.of()
                .set("student", student.toJson())
                .set("viewer", viewer.toJson())
                .set("risk", score.toJson())
                .set("forecast", forecast.toJson())
                .set("weekly", behaviorService.weeklySummary(studentId))
                .set("history", history)
                .set("recommendations", recommendations)
                .set("alerts", alerts)
                .set("badges", badges)
                .set("cohort", cohortJson)
                .set("journal", behaviorService.journalInsight(studentId, 21))
                .set("leaderboard", gamificationService.leaderboard(studentId, 8))
                .set("completeness", behaviorService.completeness(studentId, 14))
                .set("unacknowledgedAlerts", alertService.unacknowledgedCount(studentId)));
    }
}
