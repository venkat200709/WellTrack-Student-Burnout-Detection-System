package com.welltrack.controller;

import com.welltrack.core.http.HttpRequest;
import com.welltrack.core.http.HttpResponse;
import com.welltrack.core.http.HttpStatus;
import com.welltrack.core.http.Router;
import com.welltrack.model.Student;
import com.welltrack.model.User;
import com.welltrack.model.enums.Role;
import com.welltrack.security.SecurityFilter;
import com.welltrack.service.ExportService;
import com.welltrack.service.StudentService;

import java.util.List;

/** Download endpoints for CSV data and printable wellness reports. */
public final class ExportController {

    private final ExportService exportService;
    private final StudentService studentService;

    public ExportController(ExportService exportService, StudentService studentService) {
        this.exportService = exportService;
        this.studentService = studentService;
    }

    public void register(Router router) {
        router.group("/api/export")
                .get("/behaviour/{studentId}", this::behaviourCsv).authenticated()
                .get("/report/{studentId}", this::report).authenticated()
                .get("/cohort", this::cohortCsv).roles("FACULTY", "ADMIN");
    }

    private HttpResponse behaviourCsv(HttpRequest request) {
        long studentId = request.pathVariableLong("studentId");
        SecurityFilter.requireSelfOrElevated(request.requirePrincipal(), studentId);
        Student student = studentService.require(studentId);
        String csv = exportService.behaviourCsv(student);
        return HttpResponse.text(HttpStatus.OK, csv, "text/csv; charset=utf-8")
                .header("Content-Disposition",
                        "attachment; filename=\"welltrack-" + student.getRegisterNumber() + ".csv\"");
    }

    private HttpResponse report(HttpRequest request) {
        long studentId = request.pathVariableLong("studentId");
        SecurityFilter.requireSelfOrElevated(request.requirePrincipal(), studentId);
        Student student = studentService.require(studentId);
        return HttpResponse.text(HttpStatus.OK,
                exportService.wellnessReportHtml(student), "text/html; charset=utf-8");
    }

    private HttpResponse cohortCsv(HttpRequest request) {
        User principal = request.requirePrincipal();
        List<Student> scope = principal.getRole() == Role.ADMIN
                ? studentService.findAll()
                : studentService.forMentor(principal.getId());
        if (scope.isEmpty()) {
            scope = studentService.findAll();
        }
        return HttpResponse.text(HttpStatus.OK, exportService.cohortCsv(scope), "text/csv; charset=utf-8")
                .header("Content-Disposition", "attachment; filename=\"welltrack-cohort.csv\"");
    }
}
