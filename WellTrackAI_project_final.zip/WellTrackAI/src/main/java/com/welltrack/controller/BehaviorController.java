package com.welltrack.controller;

import com.welltrack.core.http.HttpRequest;
import com.welltrack.core.http.HttpResponse;
import com.welltrack.core.http.Router;
import com.welltrack.core.json.JsonArray;
import com.welltrack.core.json.JsonObject;
import com.welltrack.dto.BehaviorLogRequest;
import com.welltrack.model.Badge;
import com.welltrack.model.BehaviorLog;
import com.welltrack.model.RiskScore;
import com.welltrack.model.Student;
import com.welltrack.model.User;
import com.welltrack.security.SecurityFilter;
import com.welltrack.service.BehaviorService;
import com.welltrack.service.GamificationService;
import com.welltrack.service.RiskAnalysisService;
import com.welltrack.service.StudentService;

import java.time.LocalDate;
import java.util.List;

/**
 * Daily check-in endpoints.
 *
 * <p>Submitting a check-in triggers the whole chain synchronously — persist,
 * re-score, refresh recommendations, evaluate alerts, award badges — so the
 * response the student receives already contains their updated score. That
 * immediacy is what makes the interface feel alive.</p>
 */
public final class BehaviorController {

    private final BehaviorService behaviorService;
    private final StudentService studentService;
    private final RiskAnalysisService riskAnalysisService;
    private final GamificationService gamificationService;

    public BehaviorController(BehaviorService behaviorService,
                              StudentService studentService,
                              RiskAnalysisService riskAnalysisService,
                              GamificationService gamificationService) {
        this.behaviorService = behaviorService;
        this.studentService = studentService;
        this.riskAnalysisService = riskAnalysisService;
        this.gamificationService = gamificationService;
    }

    public void register(Router router) {
        router.group("/api/behavior")
                .post("", this::create).authenticated()
                .get("/{studentId}", this::history).authenticated()
                .get("/{studentId}/today", this::today).authenticated()
                .get("/{studentId}/weekly", this::weekly).authenticated()
                .get("/{studentId}/journal", this::journal).authenticated()
                .delete("/{studentId}/{logId}", this::delete).authenticated();
    }

    /** POST /api/behavior — records today's check-in and re-scores immediately. */
    private HttpResponse create(HttpRequest request) {
        User principal = request.requirePrincipal();
        JsonObject body = request.json();
        long studentId = body.getLong("studentId", principal.getId());
        SecurityFilter.requireSelfOrElevated(principal, studentId);

        Student student = studentService.require(studentId);
        BehaviorLogRequest logRequest = BehaviorLogRequest.from(body);
        BehaviorLog log = behaviorService.record(student, logRequest);

        RiskScore score = riskAnalysisService.analyse(student, true);
        List<Badge> badges = gamificationService.onCheckIn(student);

        JsonArray badgeArray = new JsonArray();
        badges.forEach(badge -> badgeArray.add(badge.toJson()));

        return ApiResponses.created("Check-in recorded — your analysis has been updated",
                JsonObject.of()
                        .set("log", log.toJson())
                        .set("risk", score.toJson())
                        .set("streak", student.getStreakDays())
                        .set("wellnessPoints", student.getWellnessPoints())
                        .set("newBadges", badgeArray));
    }

    /** GET /api/behavior/{studentId}?days=30 */
    private HttpResponse history(HttpRequest request) {
        long studentId = request.pathVariableLong("studentId");
        SecurityFilter.requireSelfOrElevated(request.requirePrincipal(), studentId);
        int days = request.queryInt("days", 30);

        JsonArray array = new JsonArray();
        behaviorService.history(studentId, days).forEach(log -> array.add(log.toJson()));
        return ApiResponses.ok(JsonObject.of()
                .set("days", days)
                .set("count", array.size())
                .set("completeness", behaviorService.completeness(studentId, days))
                .set("logs", array));
    }

    /** GET /api/behavior/{studentId}/today — pre-fills the check-in form. */
    private HttpResponse today(HttpRequest request) {
        long studentId = request.pathVariableLong("studentId");
        SecurityFilter.requireSelfOrElevated(request.requirePrincipal(), studentId);
        return behaviorService.onDate(studentId, LocalDate.now())
                .map(log -> ApiResponses.ok(JsonObject.of()
                        .set("exists", true).set("log", log.toJson())))
                .orElseGet(() -> ApiResponses.ok(JsonObject.of().set("exists", false)));
    }

    /** GET /api/behavior/{studentId}/weekly */
    private HttpResponse weekly(HttpRequest request) {
        long studentId = request.pathVariableLong("studentId");
        SecurityFilter.requireSelfOrElevated(request.requirePrincipal(), studentId);
        return ApiResponses.ok(behaviorService.weeklySummary(studentId));
    }

    /** GET /api/behavior/{studentId}/journal — NLP over the free-text notes. */
    private HttpResponse journal(HttpRequest request) {
        long studentId = request.pathVariableLong("studentId");
        SecurityFilter.requireSelfOrElevated(request.requirePrincipal(), studentId);
        return ApiResponses.ok(behaviorService.journalInsight(studentId, request.queryInt("days", 21)));
    }

    /** DELETE /api/behavior/{studentId}/{logId} */
    private HttpResponse delete(HttpRequest request) {
        long studentId = request.pathVariableLong("studentId");
        SecurityFilter.requireSelfOrElevated(request.requirePrincipal(), studentId);
        boolean removed = behaviorService.delete(studentId, request.pathVariableLong("logId"));
        if (!removed) {
            throw new com.welltrack.exception.NotFoundException("Behaviour log",
                    request.pathVariable("logId"));
        }
        riskAnalysisService.analyse(studentService.require(studentId), false);
        return ApiResponses.message("Check-in deleted and analysis recalculated");
    }
}
