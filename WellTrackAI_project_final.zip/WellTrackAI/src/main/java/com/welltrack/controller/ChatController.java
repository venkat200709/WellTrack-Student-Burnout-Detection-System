package com.welltrack.controller;

import com.welltrack.core.http.HttpRequest;
import com.welltrack.core.http.HttpResponse;
import com.welltrack.core.http.Router;
import com.welltrack.core.json.JsonObject;
import com.welltrack.model.Student;
import com.welltrack.model.User;
import com.welltrack.security.SecurityFilter;
import com.welltrack.service.ChatService;
import com.welltrack.service.StudentService;

/** Endpoints for the AI wellness-coach conversation. */
public final class ChatController {

    private final ChatService chatService;
    private final StudentService studentService;

    public ChatController(ChatService chatService, StudentService studentService) {
        this.chatService = chatService;
        this.studentService = studentService;
    }

    public void register(Router router) {
        router.group("/api/chat")
                .get("", this::transcript).authenticated()
                .post("", this::send).authenticated()
                .delete("", this::clear).authenticated();
    }

    /** GET /api/chat — the transcript, seeded with a greeting when empty. */
    private HttpResponse transcript(HttpRequest request) {
        User principal = request.requirePrincipal();
        Student student = studentService.require(principal.getId());
        chatService.greeting(student);
        return ApiResponses.ok(JsonObject.of()
                .set("messages", chatService.transcript(student.getId(), 60)));
    }

    /** POST /api/chat — one conversational turn. */
    private HttpResponse send(HttpRequest request) {
        User principal = request.requirePrincipal();
        SecurityFilter.requireSelfOrElevated(principal, principal.getId());
        Student student = studentService.require(principal.getId());
        String message = request.json().getString("message", "");
        return ApiResponses.ok(chatService.send(student, message));
    }

    /** DELETE /api/chat — clears the transcript. */
    private HttpResponse clear(HttpRequest request) {
        int removed = chatService.clear(request.requirePrincipal().getId());
        return ApiResponses.ok("Conversation cleared",
                JsonObject.of().set("removed", removed));
    }
}
