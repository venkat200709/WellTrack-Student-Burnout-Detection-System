package com.welltrack.controller;

import com.welltrack.ai.BurnoutPredictor;
import com.welltrack.ai.CohortAnalyzer;
import com.welltrack.ai.RecommendationEngine;
import com.welltrack.ai.WellnessCoach;
import com.welltrack.core.http.HttpRequest;
import com.welltrack.core.http.HttpResponse;
import com.welltrack.core.http.Router;
import com.welltrack.core.json.JsonArray;
import com.welltrack.core.json.JsonObject;
import com.welltrack.core.util.Numbers;
import com.welltrack.model.BehaviorLog;
import com.welltrack.model.RiskDriver;
import com.welltrack.model.Student;
import com.welltrack.model.enums.RiskLevel;
import com.welltrack.security.SecurityFilter;
import com.welltrack.service.RiskAnalysisService;
import com.welltrack.service.StudentService;

import java.util.List;

/**
 * Endpoints that expose the AI layer itself: model transparency, explanations,
 * discovered cohorts and the interactive what-if simulator.
 *
 * <p>The simulator is the feature that turns the model from a verdict into a
 * tool. A student moves sliders for sleep, study, stress and screen time and
 * the <em>same trained model</em> re-scores the hypothetical day instantly, so
 * they can see which single change actually buys them the most relief before
 * committing a week of effort to it.</p>
 */
public final class AiController {

    private final BurnoutPredictor predictor;
    private final CohortAnalyzer cohortAnalyzer;
    private final WellnessCoach coach;
    private final RecommendationEngine recommendationEngine;
    private final RiskAnalysisService riskAnalysisService;
    private final StudentService studentService;

    public AiController(BurnoutPredictor predictor,
                        CohortAnalyzer cohortAnalyzer,
                        WellnessCoach coach,
                        RecommendationEngine recommendationEngine,
                        RiskAnalysisService riskAnalysisService,
                        StudentService studentService) {
        this.predictor = predictor;
        this.cohortAnalyzer = cohortAnalyzer;
        this.coach = coach;
        this.recommendationEngine = recommendationEngine;
        this.riskAnalysisService = riskAnalysisService;
        this.studentService = studentService;
    }

    public void register(Router router) {
        router.group("/api/ai")
                .get("/model", this::model).authenticated()
                .get("/cohorts", this::cohorts).authenticated()
                .get("/explain/{studentId}", this::explain).authenticated()
                .post("/simulate", this::simulate).authenticated()
                .get("/capabilities", this::capabilities);
    }

    /** GET /api/ai/model — full transparency panel: weights, metrics, thresholds. */
    private HttpResponse model(HttpRequest request) {
        return ApiResponses.ok(JsonObject.of()
                .set("burnoutModel", predictor.describe())
                .set("coach", coach.describe())
                .set("recommendationKnowledgeBase", recommendationEngine.knowledgeBaseSize())
                .set("ensemble", JsonObject.of()
                        .set("logisticRegression", 0.50)
                        .set("ruleHeuristic", 0.25)
                        .set("anomalyDetection", 0.15)
                        .set("trend", 0.10))
                .set("analysisWindowDays", riskAnalysisService.windowDays()));
    }

    /** GET /api/ai/cohorts — the unsupervised clustering result. */
    private HttpResponse cohorts(HttpRequest request) {
        return ApiResponses.ok(cohortAnalyzer.toJson());
    }

    /** GET /api/ai/explain/{studentId} — the ranked explanation behind a score. */
    private HttpResponse explain(HttpRequest request) {
        long studentId = request.pathVariableLong("studentId");
        SecurityFilter.requireSelfOrElevated(request.requirePrincipal(), studentId);

        double[] features = riskAnalysisService.aggregatedFeatures(studentId);
        List<RiskDriver> drivers = predictor.explain(features, 14);

        JsonArray array = new JsonArray();
        drivers.forEach(driver -> array.add(driver.toJson()));

        double probability = predictor.isReady() ? predictor.probability(features) : 0;
        return ApiResponses.ok(JsonObject.of()
                .set("probability", Numbers.round(probability, 4))
                .set("score", Numbers.round(predictor.toScore(probability), 1))
                .set("featureVector", features)
                .set("featureNames", BehaviorLog.FEATURE_NAMES)
                .set("drivers", array));
    }

    /**
     * POST /api/ai/simulate — the what-if engine.
     *
     * <p>Accepts a hypothetical day, scores it with the live model, and returns
     * both the new score and a per-lever sensitivity analysis showing how much
     * each individual change is worth.</p>
     */
    private HttpResponse simulate(HttpRequest request) {
        JsonObject body = request.json();
        long studentId = body.getLong("studentId", request.requirePrincipal().getId());
        SecurityFilter.requireSelfOrElevated(request.requirePrincipal(), studentId);
        Student student = studentService.require(studentId);

        double[] baseline = riskAnalysisService.aggregatedFeatures(student.getId());
        double[] hypothetical = applyOverrides(baseline, body);

        if (!predictor.isReady()) {
            return ApiResponses.ok(JsonObject.of()
                    .set("ready", false)
                    .set("message", "The model is still training — try again in a moment."));
        }

        double baselineScore = predictor.toScore(predictor.probability(baseline));
        double simulatedScore = predictor.toScore(predictor.probability(hypothetical));

        // Per-lever sensitivity: change one variable at a time from the baseline.
        JsonArray levers = new JsonArray();
        levers.add(sensitivity("sleepHours", "Sleep +1 hour", baseline, baselineScore, 0, +1));
        levers.add(sensitivity("studyHours", "Study -1 hour", baseline, baselineScore, 2, -1));
        levers.add(sensitivity("screenTimeHours", "Screen time -2 hours", baseline, baselineScore, 4, -2));
        levers.add(sensitivity("exerciseMinutes", "Exercise +20 minutes", baseline, baselineScore, 5, +20));
        levers.add(sensitivity("socialMinutes", "Social contact +30 minutes", baseline, baselineScore, 6, +30));
        levers.add(sensitivity("stressLevel", "Stress -2 points", baseline, baselineScore, 7, -2));
        levers.add(sensitivity("caffeineCups", "Caffeine -2 cups", baseline, baselineScore, 11, -2));

        return ApiResponses.ok(JsonObject.of()
                .set("ready", true)
                .set("baselineScore", Numbers.round(baselineScore, 1))
                .set("simulatedScore", Numbers.round(simulatedScore, 1))
                .set("delta", Numbers.round(simulatedScore - baselineScore, 1))
                .set("baselineLevel", RiskLevel.of(baselineScore).label())
                .set("simulatedLevel", RiskLevel.of(simulatedScore).label())
                .set("simulatedColour", RiskLevel.of(simulatedScore).colour())
                .set("levers", levers)
                .set("narrative", narrate(simulatedScore - baselineScore)));
    }

    /**
     * Applies the caller's overrides onto the baseline vector, keeping the two
     * engineered features consistent with the values they derive from.
     */
    private double[] applyOverrides(double[] baseline, JsonObject body) {
        double[] modified = baseline.clone();
        String[] names = BehaviorLog.FEATURE_NAMES;
        for (int i = 0; i < names.length; i++) {
            if (body.has(names[i])) {
                modified[i] = body.getDouble(names[i], modified[i]);
            }
        }
        // Recompute the derived features so the vector stays internally valid.
        modified[1] = Math.max(0, 8.0 - modified[0]);
        modified[3] = Math.max(0, modified[2] - 6.0);
        return modified;
    }

    private JsonObject sensitivity(String feature, String label, double[] baseline,
                                   double baselineScore, int index, double delta) {
        double[] variant = baseline.clone();
        variant[index] = Math.max(0, variant[index] + delta);
        variant[1] = Math.max(0, 8.0 - variant[0]);
        variant[3] = Math.max(0, variant[2] - 6.0);

        double variantScore = predictor.toScore(predictor.probability(variant));
        double change = variantScore - baselineScore;
        return JsonObject.of()
                .set("feature", feature)
                .set("label", label)
                .set("scoreChange", Numbers.round(change, 1))
                .set("improves", change < 0)
                .set("magnitude", Numbers.round(Math.abs(change), 1));
    }

    private String narrate(double delta) {
        if (delta <= -12) {
            return "That combination would move you down a full risk band. It is worth the effort.";
        }
        if (delta <= -4) {
            return "A meaningful improvement — roughly %.0f points off your score.".formatted(Math.abs(delta));
        }
        if (delta < 0) {
            return "A small improvement. Combine it with one more change for a bigger effect.";
        }
        if (delta < 4) {
            return "Broadly neutral against your current pattern.";
        }
        return "That combination would push your risk up by about %.0f points.".formatted(delta);
    }

    /** GET /api/ai/capabilities — public description of the AI stack. */
    private HttpResponse capabilities(HttpRequest request) {
        JsonArray capabilities = JsonArray.of(
                capability("Burnout Prediction",
                        "Logistic regression trained by mini-batch gradient descent with L2 "
                                + "regularisation, momentum, class weighting and early stopping.", "🧠"),
                capability("Explainable Scoring",
                        "Exact per-feature log-odds contributions, ranked and rendered as plain "
                                + "English — every point of your score is attributable.", "🔍"),
                capability("Seven-Day Forecasting",
                        "Damped Holt linear exponential smoothing with grid-searched constants "
                                + "and residual-based prediction intervals.", "📈"),
                capability("Anomaly Detection",
                        "Modified z-score on the median absolute deviation plus EWMA drift, "
                                + "robust to the very outliers it hunts.", "⚡"),
                capability("Cohort Discovery",
                        "K-means with k-means++ seeding and silhouette-based selection of k, "
                                + "surfacing behavioural peer groups.", "🧬"),
                capability("Natural Language Understanding",
                        "Multinomial Naive Bayes intent classification with Laplace smoothing "
                                + "and log-space inference.", "💬"),
                capability("Sentiment & Emotion Analysis",
                        "Domain lexicon with negation scope, intensifier handling and five "
                                + "emotion channels, applied to journal entries and chat.", "❤️"),
                capability("Retrieval-Augmented Coaching",
                        "TF-IDF vector search with cosine similarity over a curated wellness "
                                + "knowledge base, grounded in the student's live data.", "🎓"),
                capability("Hybrid Recommender",
                        "Content-based matching against the explanation, boosted by "
                                + "collaborative evidence from behaviourally similar peers.", "🎯"),
                capability("What-If Simulator",
                        "Counterfactual scoring through the live model with per-lever "
                                + "sensitivity analysis.", "🎛️"));
        JsonObject summary = JsonObject.of()
                .set("engine", "WellTrack engine — implemented from first principles in pure Java")
                .set("externalDependencies", 0)
                .set("modelReady", predictor.isReady())
                .set("capabilities", capabilities);
        if (predictor.isReady() && predictor.metrics() != null) {
            summary.set("accuracy", Numbers.round(predictor.metrics().accuracy() * 100, 1))
                    .set("recall", Numbers.round(predictor.metrics().recall() * 100, 1))
                    .set("rocAuc", Numbers.round(predictor.metrics().rocAuc(), 3));
        }
        return ApiResponses.ok(summary);
    }

    private JsonObject capability(String name, String description, String glyph) {
        return JsonObject.of().set("name", name).set("description", description).set("glyph", glyph);
    }
}
