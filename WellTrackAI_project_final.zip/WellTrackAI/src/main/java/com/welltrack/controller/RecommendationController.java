package com.welltrack.controller;

import com.welltrack.core.http.HttpRequest;
import com.welltrack.core.http.HttpResponse;
import com.welltrack.core.http.Router;
import com.welltrack.core.json.JsonArray;
import com.welltrack.core.json.JsonObject;
import com.welltrack.model.Badge;
import com.welltrack.model.Recommendation;
import com.welltrack.model.Student;
import com.welltrack.security.SecurityFilter;
import com.welltrack.service.GamificationService;
import com.welltrack.service.RecommendationService;
import com.welltrack.service.StudentService;

import java.util.List;

/** Endpoints for the personalised recovery plan and gamification. */
public final class RecommendationController {

    private final RecommendationService recommendationService;
    private final GamificationService gamificationService;
    private final StudentService studentService;

    public RecommendationController(RecommendationService recommendationService,
                                    GamificationService gamificationService,
                                    StudentService studentService) {
        this.recommendationService = recommendationService;
        this.gamificationService = gamificationService;
        this.studentService = studentService;
    }

    public void register(Router router) {
        router.group("/api/recommendations")
                .get("/{studentId}", this::list).authenticated()
                .post("/{id}/complete", this::complete).authenticated()
                .get("/badges/{studentId}", this::badges).authenticated()
                .get("/leaderboard", this::leaderboard).authenticated();
    }

    private HttpResponse list(HttpRequest request) {
        long studentId = request.pathVariableLong("studentId");
        SecurityFilter.requireSelfOrElevated(request.requirePrincipal(), studentId);

        JsonArray active = new JsonArray();
        recommendationService.active(studentId).forEach(item -> active.add(item.toJson()));
        JsonArray all = new JsonArray();
        recommendationService.all(studentId).forEach(item -> all.add(item.toJson()));

        return ApiResponses.ok(JsonObject.of()
                .set("active", active)
                .set("history", all)
                .set("completed", recommendationService.completedCount(studentId)));
    }

    /** POST /api/recommendations/{id}/complete — marks an action step done. */
    private HttpResponse complete(HttpRequest request) {
        long id = request.pathVariableLong("id");
        Student student = studentService.require(request.requirePrincipal().getId());
        Recommendation recommendation = recommendationService.complete(id, student.getId());
        List<Badge> badges = gamificationService.onRecommendationCompleted(student);

        JsonArray badgeArray = new JsonArray();
        badges.forEach(badge -> badgeArray.add(badge.toJson()));

        return ApiResponses.ok("Nicely done — that is a real change",
                JsonObject.of()
                        .set("recommendation", recommendation.toJson())
                        .set("wellnessPoints", student.getWellnessPoints())
                        .set("level", student.level())
                        .set("levelTitle", student.levelTitle())
                        .set("newBadges", badgeArray));
    }

    private HttpResponse badges(HttpRequest request) {
        long studentId = request.pathVariableLong("studentId");
        SecurityFilter.requireSelfOrElevated(request.requirePrincipal(), studentId);
        JsonArray array = new JsonArray();
        gamificationService.badgesOf(studentId).forEach(badge -> array.add(badge.toJson()));
        return ApiResponses.ok(JsonObject.of().set("badges", array));
    }

    private HttpResponse leaderboard(HttpRequest request) {
        return ApiResponses.ok(gamificationService.leaderboard(
                request.requirePrincipal().getId(), request.queryInt("limit", 10)));
    }
}
