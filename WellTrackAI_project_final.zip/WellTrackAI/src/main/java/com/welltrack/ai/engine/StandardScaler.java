package com.welltrack.ai.engine;

import com.welltrack.core.json.JsonArray;
import com.welltrack.core.json.JsonObject;
import com.welltrack.core.json.JsonSerializable;

/**
 * Z-score feature standardisation: {@code z = (x - mean) / standardDeviation}.
 *
 * <p>Gradient descent converges far faster when every feature shares a common
 * scale. Sleep hours (roughly 4-9) and social minutes (0-300) would otherwise
 * produce wildly different gradient magnitudes and force an impractically small
 * learning rate. Fitting the scaler on the training set and reusing exactly
 * those statistics at inference time also prevents train/serve skew.</p>
 */
public final class StandardScaler implements JsonSerializable {

    private double[] means = new double[0];
    private double[] deviations = new double[0];
    private boolean fitted;

    /** Learns the per-column mean and standard deviation of the design matrix. */
    public void fit(double[][] samples) {
        if (samples == null || samples.length == 0) {
            throw new IllegalArgumentException("Cannot fit a scaler on an empty dataset");
        }
        int columns = samples[0].length;
        means = new double[columns];
        deviations = new double[columns];

        for (double[] row : samples) {
            for (int c = 0; c < columns; c++) {
                means[c] += row[c];
            }
        }
        for (int c = 0; c < columns; c++) {
            means[c] /= samples.length;
        }
        for (double[] row : samples) {
            for (int c = 0; c < columns; c++) {
                double delta = row[c] - means[c];
                deviations[c] += delta * delta;
            }
        }
        for (int c = 0; c < columns; c++) {
            deviations[c] = Math.sqrt(deviations[c] / Math.max(1, samples.length - 1));
            if (deviations[c] < 1e-8) {
                // A constant column carries no information; neutralise it.
                deviations[c] = 1.0;
            }
        }
        fitted = true;
    }

    /** Standardises a single observation. */
    public double[] transform(double[] sample) {
        requireFitted();
        double[] scaled = new double[sample.length];
        for (int i = 0; i < sample.length; i++) {
            scaled[i] = (sample[i] - means[i]) / deviations[i];
        }
        return scaled;
    }

    /** Standardises a whole matrix in place-safe fashion. */
    public double[][] transform(double[][] samples) {
        requireFitted();
        double[][] scaled = new double[samples.length][];
        for (int i = 0; i < samples.length; i++) {
            scaled[i] = transform(samples[i]);
        }
        return scaled;
    }

    public double[][] fitTransform(double[][] samples) {
        fit(samples);
        return transform(samples);
    }

    public double meanOf(int column) {
        requireFitted();
        return means[column];
    }

    public double deviationOf(int column) {
        requireFitted();
        return deviations[column];
    }

    public boolean isFitted() {
        return fitted;
    }

    private void requireFitted() {
        if (!fitted) {
            throw new IllegalStateException("StandardScaler has not been fitted yet");
        }
    }

    @Override
    public JsonObject toJson() {
        JsonArray meanArray = new JsonArray();
        JsonArray deviationArray = new JsonArray();
        for (int i = 0; i < means.length; i++) {
            meanArray.add(means[i]);
            deviationArray.add(deviations[i]);
        }
        return JsonObject.of()
                .set("fitted", fitted)
                .set("means", meanArray)
                .set("deviations", deviationArray);
    }
}
