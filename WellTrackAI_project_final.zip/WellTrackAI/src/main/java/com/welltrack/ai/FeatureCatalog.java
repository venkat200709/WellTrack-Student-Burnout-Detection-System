package com.welltrack.ai;

import com.welltrack.model.BehaviorLog;

import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Human-readable metadata for every model feature.
 *
 * <p>Explainability is only useful if the explanation is in the student's
 * language. This catalogue turns {@code sleepDebt = 2.4} into "You are running
 * about 2.4 hours short of a healthy night's sleep", which is what actually
 * appears on the dashboard.</p>
 */
public final class FeatureCatalog {

    /** Descriptor for one feature: a label, a unit and phrasing for both directions. */
    public record FeatureInfo(String key,
                              String label,
                              String unit,
                              String aggravatingTemplate,
                              String protectiveTemplate) {

        public String describe(double value, boolean aggravating) {
            String template = aggravating ? aggravatingTemplate : protectiveTemplate;
            return template.replace("{value}", format(value));
        }

        private static String format(double value) {
            return value == Math.rint(value)
                    ? String.valueOf((long) value)
                    : String.format("%.1f", value);
        }
    }

    private static final Map<String, FeatureInfo> CATALOG = new LinkedHashMap<>();

    static {
        put("sleepHours", "Sleep duration", "hours",
                "You are averaging only {value} hours of sleep, which is the single strongest predictor of burnout.",
                "You are averaging {value} hours of sleep — this is protecting you more than anything else.");
        put("sleepDebt", "Sleep debt", "hours",
                "You are carrying about {value} hours of nightly sleep debt against an eight-hour target.",
                "You have almost no accumulated sleep debt ({value} hours).");
        put("studyHours", "Study load", "hours",
                "You are studying {value} hours a day, past the point where retention starts to fall.",
                "Your {value} hours of daily study sits in a sustainable band.");
        put("studyOverload", "Study overload", "hours",
                "You are {value} hours beyond a sustainable six-hour study day.",
                "You are staying within a sustainable study day.");
        put("screenTimeHours", "Screen time", "hours",
                "{value} hours of daily screen time is fragmenting your attention and delaying sleep onset.",
                "Your screen time of {value} hours is well controlled.");
        put("exerciseMinutes", "Physical activity", "minutes",
                "Only {value} minutes of daily movement — activity is usually the first thing dropped under strain.",
                "{value} minutes of daily movement is actively buffering your stress response.");
        put("socialMinutes", "Social contact", "minutes",
                "Just {value} minutes of social contact a day; withdrawal both signals and accelerates burnout.",
                "{value} minutes of daily social contact is a strong protective factor.");
        put("stressLevel", "Self-reported stress", "/10",
                "You are rating your stress at {value} out of 10.",
                "Your self-reported stress of {value} out of 10 is comfortably manageable.");
        put("moodValence", "Mood valence", "",
                "Your logged mood has been persistently low (valence {value}).",
                "Your logged mood has been consistently positive (valence {value}).");
        put("attendanceRatio", "Class attendance", "",
                "Attendance has slipped to {value} of scheduled classes — often the last visible warning sign.",
                "You are attending {value} of scheduled classes, keeping you academically anchored.");
        put("assignmentsPending", "Pending assignments", "items",
                "{value} pending assignments are creating a compounding backlog.",
                "With only {value} pending assignments your workload is under control.");
        put("caffeineCups", "Caffeine intake", "cups",
                "{value} cups of caffeine a day is masking fatigue and pushing your sleep window later.",
                "Your caffeine intake of {value} cups is modest.");
        put("mealsSkipped", "Skipped meals", "meals",
                "Skipping {value} meals a day removes the metabolic base your recovery depends on.",
                "You are eating regularly, which supports recovery.");
        put("deadlinePressure", "Deadline pressure", "/10",
                "Deadline pressure is sitting at {value} out of 10.",
                "Deadline pressure of {value} out of 10 is well within reach.");
    }

    private FeatureCatalog() {
    }

    private static void put(String key, String label, String unit,
                            String aggravating, String protective) {
        CATALOG.put(key, new FeatureInfo(key, label, unit, aggravating, protective));
    }

    public static FeatureInfo of(String key) {
        return CATALOG.getOrDefault(key,
                new FeatureInfo(key, key, "", "{value}", "{value}"));
    }

    public static FeatureInfo byIndex(int index) {
        String[] names = BehaviorLog.FEATURE_NAMES;
        return of(index >= 0 && index < names.length ? names[index] : "unknown");
    }

    public static Map<String, FeatureInfo> all() {
        return Map.copyOf(CATALOG);
    }
}
