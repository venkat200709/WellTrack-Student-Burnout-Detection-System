package com.welltrack.ai.engine;

import com.welltrack.core.json.JsonArray;
import com.welltrack.core.json.JsonObject;
import com.welltrack.core.json.JsonSerializable;
import com.welltrack.core.util.Numbers;

/**
 * Holt's linear (double) exponential smoothing — a time-series forecaster
 * implemented from the original recurrence relations.
 *
 * <p>The state is a <b>level</b> {@code ℓ} and a <b>trend</b> {@code b}, both
 * updated after every observation:</p>
 * <pre>
 *   ℓₜ = α·yₜ + (1-α)·(ℓₜ₋₁ + bₜ₋₁)
 *   bₜ = β·(ℓₜ - ℓₜ₋₁) + (1-β)·bₜ₋₁
 *   ŷₜ₊ₕ = ℓₜ + h·φ·bₜ
 * </pre>
 *
 * <p>A <b>damping factor</b> {@code φ} is applied to the projected trend, which
 * stops a short burst of exam-week stress from extrapolating into an absurd
 * score two weeks out — real-world forecasts flatten, they do not run away.</p>
 *
 * <p>The smoothing constants are not guessed: {@link #fit(double[])} grid-searches
 * α and β to minimise one-step-ahead squared error on the student's own
 * history, so the model adapts to a volatile student differently from a steady
 * one. Prediction intervals come from the residual standard deviation, widening
 * with the square root of the horizon exactly as forecast uncertainty does.</p>
 */
public final class HoltLinearForecaster implements JsonSerializable {

    private double alpha = 0.5;
    private double beta = 0.2;
    private double damping = 0.92;
    private double level;
    private double trend;
    private double residualDeviation;
    private int observations;
    private boolean fitted;

    /** Grid-searches the smoothing constants, then fits the final state. */
    public void fit(double[] series) {
        if (series == null || series.length < 3) {
            // Too little history to smooth: fall back to the last value.
            this.level = series == null || series.length == 0 ? 0 : series[series.length - 1];
            this.trend = 0;
            this.residualDeviation = 0;
            this.observations = series == null ? 0 : series.length;
            this.fitted = true;
            return;
        }

        double bestAlpha = 0.5;
        double bestBeta = 0.2;
        double bestError = Double.MAX_VALUE;

        for (double a = 0.10; a <= 0.90; a += 0.05) {
            for (double b = 0.02; b <= 0.60; b += 0.04) {
                double error = oneStepError(series, a, b);
                if (error < bestError) {
                    bestError = error;
                    bestAlpha = a;
                    bestBeta = b;
                }
            }
        }

        this.alpha = bestAlpha;
        this.beta = bestBeta;
        applySmoothing(series, bestAlpha, bestBeta, true);
        this.observations = series.length;
        this.fitted = true;
    }

    private double oneStepError(double[] series, double a, double b) {
        double l = series[0];
        double t = series[1] - series[0];
        double sum = 0;
        for (int i = 1; i < series.length; i++) {
            double prediction = l + t;
            double error = series[i] - prediction;
            sum += error * error;
            double previousLevel = l;
            l = a * series[i] + (1 - a) * (l + t);
            t = b * (l - previousLevel) + (1 - b) * t;
        }
        return sum / (series.length - 1);
    }

    private void applySmoothing(double[] series, double a, double b, boolean captureResiduals) {
        double l = series[0];
        double t = series[1] - series[0];
        double squaredResiduals = 0;
        for (int i = 1; i < series.length; i++) {
            double prediction = l + t;
            double error = series[i] - prediction;
            squaredResiduals += error * error;
            double previousLevel = l;
            l = a * series[i] + (1 - a) * (l + t);
            t = b * (l - previousLevel) + (1 - b) * t;
        }
        this.level = l;
        this.trend = t;
        if (captureResiduals) {
            this.residualDeviation = Math.sqrt(squaredResiduals / Math.max(1, series.length - 1));
        }
    }

    /**
     * Projects the series forward.
     *
     * @param horizon number of future steps
     * @param floor   lower clamp (0 for a risk score)
     * @param ceiling upper clamp (100 for a risk score)
     */
    public double[] forecast(int horizon, double floor, double ceiling) {
        requireFitted();
        double[] projection = new double[horizon];
        double cumulativeDamping = 0;
        for (int h = 1; h <= horizon; h++) {
            cumulativeDamping += Math.pow(damping, h);
            projection[h - 1] = Numbers.clamp(level + cumulativeDamping * trend, floor, ceiling);
        }
        return projection;
    }

    /** @return {@code [lower, upper]} bounds at roughly 80% confidence. */
    public double[][] predictionInterval(int horizon, double floor, double ceiling) {
        double[] central = forecast(horizon, floor, ceiling);
        double[][] bounds = new double[2][horizon];
        for (int h = 1; h <= horizon; h++) {
            double width = 1.28 * residualDeviation * Math.sqrt(h);
            bounds[0][h - 1] = Numbers.clamp(central[h - 1] - width, floor, ceiling);
            bounds[1][h - 1] = Numbers.clamp(central[h - 1] + width, floor, ceiling);
        }
        return bounds;
    }

    /** @return the projected change over the horizon, in score points. */
    public double projectedChange(int horizon) {
        requireFitted();
        double[] projection = forecast(horizon, -1000, 1000);
        return projection[horizon - 1] - level;
    }

    private void requireFitted() {
        if (!fitted) {
            throw new IllegalStateException("The forecaster has not been fitted yet");
        }
    }

    public double level() {
        return level;
    }

    public double trend() {
        return trend;
    }

    public double alpha() {
        return alpha;
    }

    public double beta() {
        return beta;
    }

    public double residualDeviation() {
        return residualDeviation;
    }

    /** Confidence falls as residual noise rises and grows with more history. */
    public double confidence() {
        double noisePenalty = 1.0 / (1.0 + residualDeviation / 8.0);
        double historyBonus = Math.min(1.0, observations / 21.0);
        return Numbers.clamp(0.35 + 0.65 * noisePenalty * historyBonus, 0, 1);
    }

    @Override
    public JsonObject toJson() {
        JsonArray projection = new JsonArray();
        if (fitted) {
            for (double value : forecast(7, 0, 100)) {
                projection.add(Numbers.round(value, 1));
            }
        }
        return JsonObject.of()
                .set("algorithm", "Holt's linear exponential smoothing (damped, grid-searched)")
                .set("alpha", Numbers.round(alpha, 3))
                .set("beta", Numbers.round(beta, 3))
                .set("damping", damping)
                .set("level", Numbers.round(level, 2))
                .set("trend", Numbers.round(trend, 3))
                .set("residualDeviation", Numbers.round(residualDeviation, 3))
                .set("confidence", Numbers.round(confidence(), 3))
                .set("observations", observations)
                .set("sevenDayProjection", projection);
    }
}
