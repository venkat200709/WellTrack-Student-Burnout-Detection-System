package com.welltrack.ai.nlp;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * A TF-IDF vector-space index with cosine-similarity retrieval.
 *
 * <p>This is the retrieval half of WellTrack's retrieval-augmented wellness
 * coach. Every knowledge-base article is embedded as a sparse TF-IDF vector;
 * an incoming question is embedded the same way and the closest articles are
 * returned by cosine similarity.</p>
 *
 * <p>Term frequency is sub-linearly scaled ({@code 1 + log tf}) so a word
 * repeated ten times does not count ten times as much, and inverse document
 * frequency is smoothed ({@code log((N+1)/(df+1)) + 1}) so a term appearing in
 * every document still receives a small non-zero weight instead of vanishing.
 * Vectors are L2-normalised at index time, which reduces the cosine similarity
 * at query time to a simple dot product.</p>
 */
public final class TfIdfIndex {

    /** One indexed document. */
    public record Document(String id, String title, String body, Map<String, Double> vector) {
    }

    /** A scored retrieval hit. */
    public record Hit(Document document, double score) {
    }

    private final List<Document> documents = new ArrayList<>();
    private final Map<String, Integer> documentFrequency = new HashMap<>();
    private final List<String[]> pending = new ArrayList<>();
    private boolean built;

    /** Queues a document; call {@link #build()} once all documents are added. */
    public void add(String id, String title, String body) {
        pending.add(new String[]{id, title, body});
        built = false;
    }

    /** Computes document frequencies and materialises the normalised vectors. */
    public void build() {
        documents.clear();
        documentFrequency.clear();

        List<List<String>> tokenised = new ArrayList<>(pending.size());
        for (String[] entry : pending) {
            List<String> tokens = Tokenizer.normalise(entry[1] + " " + entry[2]);
            tokens.addAll(Tokenizer.bigrams(tokens));
            tokenised.add(tokens);
            for (String term : new java.util.HashSet<>(tokens)) {
                documentFrequency.merge(term, 1, Integer::sum);
            }
        }

        for (int i = 0; i < pending.size(); i++) {
            String[] entry = pending.get(i);
            documents.add(new Document(entry[0], entry[1], entry[2], vectorise(tokenised.get(i))));
        }
        built = true;
    }

    private Map<String, Double> vectorise(List<String> tokens) {
        Map<String, Integer> counts = new HashMap<>();
        for (String token : tokens) {
            counts.merge(token, 1, Integer::sum);
        }
        Map<String, Double> vector = new HashMap<>();
        int corpusSize = Math.max(1, pending.size());
        double norm = 0;
        for (Map.Entry<String, Integer> entry : counts.entrySet()) {
            double tf = 1 + Math.log(entry.getValue());
            int df = documentFrequency.getOrDefault(entry.getKey(), 0);
            double idf = Math.log((corpusSize + 1.0) / (df + 1.0)) + 1.0;
            double weight = tf * idf;
            vector.put(entry.getKey(), weight);
            norm += weight * weight;
        }
        double magnitude = Math.sqrt(norm);
        if (magnitude > 0) {
            vector.replaceAll((term, weight) -> weight / magnitude);
        }
        return vector;
    }

    /** @return the {@code limit} most similar documents to the query. */
    public List<Hit> search(String query, int limit) {
        if (!built) {
            build();
        }
        List<String> tokens = Tokenizer.normalise(query);
        tokens.addAll(Tokenizer.bigrams(tokens));
        Map<String, Double> queryVector = vectorise(tokens);

        List<Hit> hits = new ArrayList<>();
        for (Document document : documents) {
            double similarity = cosine(queryVector, document.vector());
            if (similarity > 0.01) {
                hits.add(new Hit(document, similarity));
            }
        }
        hits.sort(Comparator.comparingDouble(Hit::score).reversed());
        return hits.size() <= limit ? hits : hits.subList(0, limit);
    }

    /**
     * Cosine similarity of two L2-normalised sparse vectors, which reduces to
     * their dot product. Iterating over the smaller map keeps this O(min(n,m)).
     */
    private static double cosine(Map<String, Double> left, Map<String, Double> right) {
        Map<String, Double> smaller = left.size() <= right.size() ? left : right;
        Map<String, Double> larger = smaller == left ? right : left;
        double dot = 0;
        for (Map.Entry<String, Double> entry : smaller.entrySet()) {
            Double other = larger.get(entry.getKey());
            if (other != null) {
                dot += entry.getValue() * other;
            }
        }
        return dot;
    }

    public int size() {
        return pending.size();
    }
}
