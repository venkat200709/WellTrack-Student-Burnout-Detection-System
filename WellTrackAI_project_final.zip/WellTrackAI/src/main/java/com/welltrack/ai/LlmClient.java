package com.welltrack.ai;

import com.welltrack.core.json.Json;
import com.welltrack.core.json.JsonArray;
import com.welltrack.core.json.JsonObject;
import com.welltrack.core.util.AppConfig;
import com.welltrack.core.util.Log;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.util.Optional;

/**
 * Optional bridge to an external large language model.
 *
 * <p>WellTrack is fully functional without this class — the local NLP pipeline
 * in {@link WellnessCoach} answers every question offline. When an institution
 * does want richer phrasing, setting an API key switches the final composition
 * step to a hosted model while keeping <em>all</em> analysis local: the request
 * carries only the grounded summary the coach already produced, never raw
 * behavioural records.</p>
 *
 * <p>Configuration ({@code config/application.properties} or environment):</p>
 * <pre>
 * welltrack.ai.llm.enabled=true
 * welltrack.ai.llm.endpoint=https://api.anthropic.com/v1/messages
 * welltrack.ai.llm.model=claude-sonnet-4-5
 * welltrack.ai.llm.api-key=sk-...
 * </pre>
 *
 * <p>The client uses the JDK's own {@link HttpClient}, so this remains a
 * zero-dependency implementation. Every call is guarded: a timeout, a
 * non-2xx response or an unparseable body simply falls back to the local
 * answer, so the coach can never be taken offline by a third party.</p>
 */
public final class LlmClient {

    private static final String SYSTEM_PROMPT = """
            You are the WellTrack wellness coach for university students.
            You will be given: (1) the student's question, (2) a factual grounding \
            summary produced by WellTrack's own analytics, and (3) a draft answer.
            Rewrite the draft so it is warm, concise and specific. Obey these rules:
            - Use only facts present in the grounding summary. Never invent numbers.
            - Never diagnose, and never give clinical or medication advice.
            - Keep it under 160 words, in second person, with one concrete next step.
            - If the student appears to be in crisis, advise contacting their mentor \
            or student welfare office today.
            """;

    private final boolean enabled;
    private final String endpoint;
    private final String model;
    private final String apiKey;
    private final HttpClient httpClient;

    public LlmClient() {
        AppConfig config = AppConfig.get();
        this.endpoint = config.string("ai.llm.endpoint", "https://api.anthropic.com/v1/messages");
        this.model = config.string("ai.llm.model", "claude-sonnet-4-5");
        this.apiKey = config.string("ai.llm.api-key", "");
        this.enabled = config.flag("ai.llm.enabled", false) && !apiKey.isBlank();
        this.httpClient = HttpClient.newBuilder()
                .connectTimeout(Duration.ofSeconds(5))
                .build();

        if (enabled) {
            Log.info("LlmClient", "External language model enabled (" + model + ")");
        } else {
            Log.info("LlmClient", "Running fully offline — local NLP pipeline will answer every message");
        }
    }

    public boolean isEnabled() {
        return enabled;
    }

    public String modelName() {
        return enabled ? model : "welltrack-local-nlp";
    }

    /**
     * Asks the hosted model to polish a grounded draft.
     *
     * @return the improved answer, or {@link Optional#empty()} when the call
     *         fails for any reason — the caller then keeps the local answer
     */
    public Optional<String> enhance(String question, String groundingContext, String draftAnswer) {
        if (!enabled) {
            return Optional.empty();
        }
        try {
            String payload = Json.write(JsonObject.of()
                    .set("model", model)
                    .set("max_tokens", 400)
                    .set("system", SYSTEM_PROMPT)
                    .set("messages", JsonArray.of(JsonObject.of()
                            .set("role", "user")
                            .set("content", """
                                    STUDENT QUESTION:
                                    %s

                                    GROUNDING SUMMARY (facts you may use):
                                    %s

                                    DRAFT ANSWER TO IMPROVE:
                                    %s
                                    """.formatted(question, groundingContext, draftAnswer)))));

            HttpRequest request = HttpRequest.newBuilder(URI.create(endpoint))
                    .timeout(Duration.ofSeconds(12))
                    .header("content-type", "application/json")
                    .header("x-api-key", apiKey)
                    .header("anthropic-version", "2023-06-01")
                    .POST(HttpRequest.BodyPublishers.ofString(payload, StandardCharsets.UTF_8))
                    .build();

            HttpResponse<String> response =
                    httpClient.send(request, HttpResponse.BodyHandlers.ofString(StandardCharsets.UTF_8));

            if (response.statusCode() / 100 != 2) {
                Log.warn("LlmClient", "Model returned HTTP " + response.statusCode()
                        + " — falling back to the local coach");
                return Optional.empty();
            }
            return extractText(response.body());
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            return Optional.empty();
        } catch (Exception e) {
            Log.warn("LlmClient", "Model call failed (" + e.getClass().getSimpleName()
                    + ") — falling back to the local coach");
            return Optional.empty();
        }
    }

    /** Pulls the assistant text out of the response envelope. */
    private Optional<String> extractText(String body) {
        try {
            JsonObject root = Json.parseObject(body);
            JsonArray content = root.getArray("content");
            if (content != null && !content.isEmpty()) {
                JsonObject first = content.objectAt(0);
                if (first != null) {
                    String text = first.getString("text");
                    if (text != null && !text.isBlank()) {
                        return Optional.of(text.trim());
                    }
                }
            }
            // Tolerate an OpenAI-shaped response as well.
            JsonArray choices = root.getArray("choices");
            if (choices != null && !choices.isEmpty()) {
                JsonObject choice = choices.objectAt(0);
                if (choice != null) {
                    JsonObject message = choice.getObject("message");
                    if (message != null) {
                        return Optional.ofNullable(message.getString("content"));
                    }
                }
            }
        } catch (RuntimeException e) {
            Log.warn("LlmClient", "Could not parse the model response");
        }
        return Optional.empty();
    }
}
