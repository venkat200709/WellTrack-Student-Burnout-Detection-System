package com.welltrack.ai.engine;

import com.welltrack.core.json.JsonArray;
import com.welltrack.core.json.JsonObject;
import com.welltrack.core.json.JsonSerializable;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Random;

/**
 * K-means clustering with k-means++ seeding and silhouette-based model
 * selection — implemented from scratch.
 *
 * <p>WellTrack uses it to discover <em>wellness cohorts</em>: groups of students
 * whose behavioural signatures resemble one another. That unlocks two things a
 * per-student score cannot give you — peer-relative context ("your sleep is the
 * lowest in your cohort") and collaborative recommendations ("students with
 * your profile improved most by fixing their sleep window").</p>
 *
 * <p>Plain k-means is sensitive to its starting centroids, so this
 * implementation seeds with <b>k-means++</b>: the first centre is random and
 * each subsequent centre is drawn with probability proportional to its squared
 * distance from the nearest existing centre. That spreads the seeds out and
 * dramatically reduces the chance of a poor local optimum.</p>
 */
public final class KMeansClusterer implements JsonSerializable {

    private final int maxIterations;
    private final long seed;

    private double[][] centroids = new double[0][];
    private int[] assignments = new int[0];
    private double inertia;
    private double silhouette;
    private int clusterCount;

    public KMeansClusterer(int maxIterations, long seed) {
        this.maxIterations = maxIterations;
        this.seed = seed;
    }

    /**
     * Fits the model for a fixed number of clusters.
     *
     * @return the cluster index assigned to each observation
     */
    public int[] fit(double[][] samples, int k) {
        if (samples.length == 0) {
            throw new IllegalArgumentException("Cannot cluster an empty dataset");
        }
        int effectiveK = Math.max(1, Math.min(k, samples.length));
        this.clusterCount = effectiveK;
        Random random = new Random(seed);

        centroids = seedWithKMeansPlusPlus(samples, effectiveK, random);
        assignments = new int[samples.length];
        Arrays.fill(assignments, -1);

        for (int iteration = 0; iteration < maxIterations; iteration++) {
            boolean changed = false;

            // Assignment step.
            for (int i = 0; i < samples.length; i++) {
                int nearest = nearestCentroid(samples[i]);
                if (assignments[i] != nearest) {
                    assignments[i] = nearest;
                    changed = true;
                }
            }

            // Update step.
            double[][] sums = new double[effectiveK][samples[0].length];
            int[] counts = new int[effectiveK];
            for (int i = 0; i < samples.length; i++) {
                int cluster = assignments[i];
                counts[cluster]++;
                for (int f = 0; f < samples[i].length; f++) {
                    sums[cluster][f] += samples[i][f];
                }
            }
            for (int c = 0; c < effectiveK; c++) {
                if (counts[c] == 0) {
                    // Re-seed an emptied cluster onto the most isolated point.
                    centroids[c] = samples[random.nextInt(samples.length)].clone();
                    continue;
                }
                for (int f = 0; f < sums[c].length; f++) {
                    centroids[c][f] = sums[c][f] / counts[c];
                }
            }

            if (!changed) {
                break;
            }
        }

        this.inertia = computeInertia(samples);
        this.silhouette = computeSilhouette(samples);
        return assignments.clone();
    }

    /**
     * Chooses the number of clusters automatically by maximising the mean
     * silhouette coefficient over the candidate range.
     */
    public int fitBest(double[][] samples, int minK, int maxK) {
        int bestK = minK;
        double bestScore = -2;
        int[] bestAssignments = null;
        double[][] bestCentroids = null;
        double bestInertia = 0;

        int ceiling = Math.min(maxK, Math.max(minK, samples.length - 1));
        for (int k = minK; k <= ceiling; k++) {
            fit(samples, k);
            if (silhouette > bestScore) {
                bestScore = silhouette;
                bestK = k;
                bestAssignments = assignments.clone();
                bestCentroids = deepCopy(centroids);
                bestInertia = inertia;
            }
        }
        if (bestAssignments != null) {
            assignments = bestAssignments;
            centroids = bestCentroids;
            silhouette = bestScore;
            inertia = bestInertia;
            clusterCount = bestK;
        }
        return bestK;
    }

    private double[][] seedWithKMeansPlusPlus(double[][] samples, int k, Random random) {
        double[][] seeds = new double[k][];
        seeds[0] = samples[random.nextInt(samples.length)].clone();

        for (int c = 1; c < k; c++) {
            double[] squaredDistances = new double[samples.length];
            double total = 0;
            for (int i = 0; i < samples.length; i++) {
                double nearest = Double.MAX_VALUE;
                for (int j = 0; j < c; j++) {
                    nearest = Math.min(nearest, squaredDistance(samples[i], seeds[j]));
                }
                squaredDistances[i] = nearest;
                total += nearest;
            }
            double target = random.nextDouble() * total;
            double running = 0;
            int chosen = samples.length - 1;
            for (int i = 0; i < samples.length; i++) {
                running += squaredDistances[i];
                if (running >= target) {
                    chosen = i;
                    break;
                }
            }
            seeds[c] = samples[chosen].clone();
        }
        return seeds;
    }

    public int predict(double[] sample) {
        return nearestCentroid(sample);
    }

    private int nearestCentroid(double[] sample) {
        int best = 0;
        double bestDistance = Double.MAX_VALUE;
        for (int c = 0; c < centroids.length; c++) {
            double distance = squaredDistance(sample, centroids[c]);
            if (distance < bestDistance) {
                bestDistance = distance;
                best = c;
            }
        }
        return best;
    }

    private double computeInertia(double[][] samples) {
        double total = 0;
        for (int i = 0; i < samples.length; i++) {
            total += squaredDistance(samples[i], centroids[assignments[i]]);
        }
        return total;
    }

    /**
     * Mean silhouette coefficient: for each point, how much closer it sits to
     * its own cluster than to the nearest rival cluster. Ranges from -1 (badly
     * clustered) through 0 (on a boundary) to +1 (tight, well-separated).
     */
    private double computeSilhouette(double[][] samples) {
        if (clusterCount < 2 || samples.length <= clusterCount) {
            return 0;
        }
        double total = 0;
        for (int i = 0; i < samples.length; i++) {
            double intra = 0;
            int intraCount = 0;
            double[] interSums = new double[clusterCount];
            int[] interCounts = new int[clusterCount];

            for (int j = 0; j < samples.length; j++) {
                if (i == j) {
                    continue;
                }
                double distance = Math.sqrt(squaredDistance(samples[i], samples[j]));
                if (assignments[j] == assignments[i]) {
                    intra += distance;
                    intraCount++;
                } else {
                    interSums[assignments[j]] += distance;
                    interCounts[assignments[j]]++;
                }
            }

            double a = intraCount == 0 ? 0 : intra / intraCount;
            double b = Double.MAX_VALUE;
            for (int c = 0; c < clusterCount; c++) {
                if (c != assignments[i] && interCounts[c] > 0) {
                    b = Math.min(b, interSums[c] / interCounts[c]);
                }
            }
            if (b == Double.MAX_VALUE) {
                continue;
            }
            double denominator = Math.max(a, b);
            total += denominator == 0 ? 0 : (b - a) / denominator;
        }
        return total / samples.length;
    }

    private static double squaredDistance(double[] left, double[] right) {
        double sum = 0;
        for (int i = 0; i < left.length; i++) {
            double delta = left[i] - right[i];
            sum += delta * delta;
        }
        return sum;
    }

    private static double[][] deepCopy(double[][] source) {
        double[][] copy = new double[source.length][];
        for (int i = 0; i < source.length; i++) {
            copy[i] = source[i].clone();
        }
        return copy;
    }

    public double[][] centroids() {
        return deepCopy(centroids);
    }

    public int[] assignments() {
        return assignments.clone();
    }

    public double inertia() {
        return inertia;
    }

    public double silhouette() {
        return silhouette;
    }

    public int clusterCount() {
        return clusterCount;
    }

    /** @return how many observations landed in each cluster. */
    public int[] clusterSizes() {
        int[] sizes = new int[clusterCount];
        for (int assignment : assignments) {
            if (assignment >= 0 && assignment < clusterCount) {
                sizes[assignment]++;
            }
        }
        return sizes;
    }

    @Override
    public JsonObject toJson() {
        JsonArray sizes = new JsonArray();
        for (int size : clusterSizes()) {
            sizes.add(size);
        }
        List<Object> centroidList = new ArrayList<>();
        for (double[] centroid : centroids) {
            JsonArray values = new JsonArray();
            for (double value : centroid) {
                values.add(com.welltrack.core.util.Numbers.round(value, 3));
            }
            centroidList.add(values);
        }
        return JsonObject.of()
                .set("algorithm", "K-Means (k-means++ seeding, silhouette model selection)")
                .set("clusters", clusterCount)
                .set("silhouette", com.welltrack.core.util.Numbers.round(silhouette, 4))
                .set("inertia", com.welltrack.core.util.Numbers.round(inertia, 3))
                .set("clusterSizes", sizes)
                .set("centroids", new JsonArray(centroidList));
    }
}
