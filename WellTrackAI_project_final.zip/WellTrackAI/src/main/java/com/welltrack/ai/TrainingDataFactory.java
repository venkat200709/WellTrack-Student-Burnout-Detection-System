package com.welltrack.ai;

import com.welltrack.model.BehaviorLog;

import java.util.Random;

/**
 * Builds the labelled dataset the burnout classifier learns from.
 *
 * <p>A student wellness system faces a genuine cold-start problem: on day one
 * there is no historical corpus of students who did or did not burn out, and no
 * public dataset can be shipped inside a coursework project. WellTrack solves
 * this with a <b>generative simulation grounded in occupational-health
 * research</b>.</p>
 *
 * <p>Each simulated student is given a hidden <em>burnout propensity</em>
 * λ ∈ [0,1]. Every observable behaviour is then sampled as a noisy function of
 * λ, using effect directions that are well established in the literature:
 * sleep duration falls, screen time and caffeine climb, exercise and social
 * contact are the first things sacrificed, attendance erodes late, and
 * self-reported stress rises roughly linearly. Because the observations are
 * <em>noisy</em>, no single feature can recover λ on its own — the model has to
 * learn how the signals combine, which is exactly the skill we need it to
 * have.</p>
 *
 * <p>Two details keep the resulting model honest:</p>
 * <ul>
 *   <li><b>Label noise.</b> Roughly 6% of labels are flipped, so the classes
 *       are not linearly separable and the model cannot memorise a shortcut —
 *       without this the reported accuracy would be a meaningless 100%.</li>
 *   <li><b>Reproducibility.</b> Every draw comes from a seeded {@link Random},
 *       so the same seed always yields the same model, which makes the
 *       reported metrics verifiable.</li>
 * </ul>
 *
 * <p>The simulator is also reused to fabricate realistic ninety-day histories
 * for the demonstration accounts, so the dashboards have believable data the
 * moment the application starts.</p>
 */
public final class TrainingDataFactory {

    /** An immutable design matrix with its labels. */
    public record Dataset(double[][] features, int[] labels, int positives) {

        public int size() {
            return labels.length;
        }

        public double positiveRate() {
            return labels.length == 0 ? 0 : positives / (double) labels.length;
        }
    }

    private TrainingDataFactory() {
    }

    /**
     * Generates a labelled dataset.
     *
     * @param samples number of simulated student-days
     * @param seed    random seed for reproducibility
     */
    public static Dataset generate(int samples, long seed) {
        Random random = new Random(seed);
        double[][] features = new double[samples][];
        int[] labels = new int[samples];
        int positives = 0;

        for (int i = 0; i < samples; i++) {
            double propensity = random.nextDouble();
            features[i] = simulateDay(propensity, random);

            // The outcome depends on the latent state plus unobservable factors.
            double outcome = propensity + random.nextGaussian() * 0.12;
            int label = outcome > 0.62 ? 1 : 0;

            // Deliberate label noise keeps the problem realistically hard.
            if (random.nextDouble() < 0.06) {
                label = 1 - label;
            }
            labels[i] = label;
            positives += label;
        }
        return new Dataset(features, labels, positives);
    }

    /**
     * Samples one day of observable behaviour for a student whose hidden
     * burnout propensity is {@code lambda}.
     *
     * @return a vector aligned with {@link BehaviorLog#FEATURE_NAMES}
     */
    public static double[] simulateDay(double lambda, Random random) {
        double sleep = clamp(gaussian(random, 8.1 - 3.1 * lambda, 0.85), 3.0, 10.5);
        double study = clamp(gaussian(random, 3.4 + 4.3 * lambda, 1.25), 0, 14);
        double screen = clamp(gaussian(random, 2.9 + 4.2 * lambda, 1.15), 0, 14);
        double exercise = clamp(gaussian(random, 48 - 38 * lambda, 16), 0, 150);
        double social = clamp(gaussian(random, 115 - 85 * lambda, 32), 0, 300);
        double stress = clamp(Math.round(gaussian(random, 2.2 + 7.0 * lambda, 1.1)), 1, 10);
        double mood = clamp(gaussian(random, 0.86 - 0.70 * lambda, 0.10), 0.02, 1.0);
        double attendance = clamp(gaussian(random, 0.97 - 0.36 * lambda, 0.07), 0.25, 1.0);
        double assignments = clamp(Math.round(gaussian(random, 1.0 + 7.5 * lambda, 1.6)), 0, 20);
        double caffeine = clamp(Math.round(gaussian(random, 0.6 + 3.6 * lambda, 1.0)), 0, 10);
        double meals = clamp(Math.round(gaussian(random, 0.15 + 2.3 * lambda, 0.7)), 0, 4);
        double deadline = clamp(Math.round(gaussian(random, 1.4 + 7.6 * lambda, 1.3)), 0, 10);

        return new double[]{
                sleep,
                Math.max(0, 8.0 - sleep),
                study,
                Math.max(0, study - 6.0),
                screen,
                exercise,
                social,
                stress,
                mood,
                attendance,
                assignments,
                caffeine,
                meals,
                deadline
        };
    }

    /**
     * Produces a smoothly varying propensity for one simulated student across a
     * term, combining a personal baseline, a slow drift and a mid-term
     * examination bump. Used by the data seeder so the demonstration charts show
     * a believable narrative rather than white noise.
     */
    public static double propensityForDay(double baseline, double drift, int dayIndex,
                                          int totalDays, Random random) {
        double progress = totalDays <= 1 ? 0 : dayIndex / (double) (totalDays - 1);
        double examBump = 0.22 * Math.exp(-Math.pow((progress - 0.72) / 0.10, 2));
        double weekly = 0.05 * Math.sin(dayIndex / 7.0 * 2 * Math.PI);
        double value = baseline + drift * progress + examBump + weekly + random.nextGaussian() * 0.045;
        return clamp(value, 0.02, 0.98);
    }

    private static double gaussian(Random random, double mean, double deviation) {
        return mean + random.nextGaussian() * deviation;
    }

    private static double clamp(double value, double min, double max) {
        return Math.max(min, Math.min(max, value));
    }
}
