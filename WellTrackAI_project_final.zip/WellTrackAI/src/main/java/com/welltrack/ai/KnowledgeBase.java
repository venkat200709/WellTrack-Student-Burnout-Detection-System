package com.welltrack.ai;

import com.welltrack.ai.nlp.TfIdfIndex;

/**
 * The curated wellness knowledge base behind the AI coach's retrieval step.
 *
 * <p>Each article is short, actionable and evidence-oriented. Keeping the
 * corpus inside the application means the coach works offline, cites material
 * an institution can review, and can never hallucinate clinical advice it was
 * not given.</p>
 */
public final class KnowledgeBase {

    private KnowledgeBase() {
    }

    /** Builds and returns the searchable index. */
    public static TfIdfIndex build() {
        TfIdfIndex index = new TfIdfIndex();

        index.add("sleep-window", "Building a stable sleep window",
                "A consistent bedtime matters more than total duration. Going to sleep and waking within the same "
                        + "30-minute window every day stabilises your circadian rhythm, which improves both sleep quality and "
                        + "next-day concentration. Start by fixing your wake time, because it anchors everything else. "
                        + "Avoid bright screens for the final hour and keep the room cool and dark.");

        index.add("sleep-debt", "Recovering from sleep deprivation",
                "Sleep debt accumulates and cannot be cleared with a single long weekend. Adding 30 to 45 minutes per "
                        + "night across a week restores alertness and memory consolidation more effectively. Napping is useful "
                        + "but keep naps under 25 minutes and before 3 pm so they do not push your night-time sleep later.");

        index.add("focus-blocks", "Studying in focused blocks",
                "Attention degrades sharply after about 50 minutes of continuous study. Working in blocks of 50 minutes "
                        + "with 10-minute movement breaks preserves retention and reduces the total hours needed. Studying "
                        + "beyond six hours a day usually produces diminishing returns and eats into recovery time.");

        index.add("procrastination", "Breaking a procrastination loop",
                "Procrastination is usually avoidance of an unpleasant emotion, not laziness. Shrink the first step until "
                        + "it is almost trivially easy — open the document and write one sentence. Starting reliably breaks the "
                        + "avoidance loop, because the anticipated discomfort is nearly always worse than the task itself.");

        index.add("exam-stress", "Managing examination pressure",
                "Exam stress peaks in anticipation rather than during the exam. Convert an overwhelming syllabus into a "
                        + "dated sequence and commit only to the nearest two items. Practising under timed conditions reduces "
                        + "anxiety more than re-reading notes, because it makes the situation familiar.");

        index.add("breathing", "Fast physiological down-regulation",
                "A longer exhale than inhale activates the parasympathetic nervous system. Breathe in for four seconds "
                        + "and out for six, for three minutes. Doing this before a study block is more effective than after, "
                        + "because physiological arousal decays slowly once triggered.");

        index.add("burnout-signs", "Recognising early burnout",
                "Burnout develops through exhaustion, then cynicism or detachment, and finally reduced effectiveness. "
                        + "Early signals include shortened sleep, withdrawal from friends, dropping exercise, rising caffeine "
                        + "and a sense that effort no longer produces results. Recognising it at the exhaustion stage makes "
                        + "recovery a matter of weeks rather than months.");

        index.add("movement", "Movement as a stress buffer",
                "Twenty minutes of moderate activity measurably lowers cortisol and improves sleep onset the same night. "
                        + "Intensity matters less than consistency. Walking outdoors adds daylight exposure, which further "
                        + "stabilises your sleep timing.");

        index.add("social", "Social connection and isolation",
                "Withdrawal is both a symptom of burnout and an accelerator of it. One unhurried conversation a day is "
                        + "enough to interrupt the loop. If reaching out feels effortful, choose the lowest-friction option: "
                        + "a message today, a shared meal this week.");

        index.add("caffeine", "Caffeine, alertness and sleep",
                "Caffeine has a half-life of five to six hours, so a 4 pm coffee is still measurably active at midnight. "
                        + "It masks fatigue without removing it, which quietly sustains sleep debt. A 2 pm cut-off usually "
                        + "improves sleep quality within a few days.");

        index.add("nutrition", "Eating under academic pressure",
                "Skipped meals destabilise blood glucose and amplify the perception of stress. Anchoring one reliable meal "
                        + "a day is more effective than an ambitious plan you abandon. Hydration matters too: mild dehydration "
                        + "measurably reduces concentration.");

        index.add("workload", "Managing an unmanageable workload",
                "When everything feels urgent, ambiguity is the real problem. Write every commitment down with its actual "
                        + "deadline. Most lists shrink dramatically once written, and the two genuinely urgent items become "
                        + "obvious. Ask for an extension early rather than late; it is far better received.");

        index.add("motivation", "When motivation disappears",
                "Motivation follows action more often than it precedes it. If you are waiting to feel motivated, start "
                        + "with a two-minute version of the task instead. Persistent absence of motivation over several weeks, "
                        + "combined with low mood, is worth discussing with a counsellor.");

        index.add("support", "Getting support",
                "Talking to your faculty mentor early is a routine academic step, not an admission of failure. Institutions "
                        + "have counselling services precisely because academic pressure is a normal and expected difficulty. "
                        + "If distress feels overwhelming, contact your student welfare office or a trusted person today.");

        index.add("scores", "How WellTrack calculates your score",
                "Your burnout score combines four signals: a trained logistic-regression model, a transparent rule-based "
                        + "strain heuristic, a statistical anomaly detector and your recent trend. Every point is attributable "
                        + "to a specific behaviour, which is why the dashboard can always tell you exactly what is driving it.");

        index.build();
        return index;
    }
}
