package com.welltrack.ai.nlp;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Set;

/**
 * A lightweight English tokeniser with stop-word removal and suffix stemming.
 *
 * <p>Everything downstream in the NLP stack — sentiment, TF-IDF retrieval and
 * intent classification — consumes tokens from here, so normalisation happens
 * exactly once and stays consistent across the whole pipeline.</p>
 */
public final class Tokenizer {

    private static final Set<String> STOP_WORDS = Set.of(
            "a", "an", "the", "and", "or", "but", "if", "then", "than", "so", "because",
            "of", "at", "by", "for", "with", "about", "into", "to", "from", "in", "on",
            "is", "am", "are", "was", "were", "be", "been", "being", "do", "does", "did",
            "have", "has", "had", "will", "would", "shall", "should", "can", "could",
            "may", "might", "must", "this", "that", "these", "those", "it", "its",
            "as", "up", "down", "out", "over", "under", "again", "there", "here");

    /** Words that must survive stop-word removal because they carry the signal. */
    private static final Set<String> PROTECTED = Set.of(
            "not", "no", "never", "i", "me", "my", "you", "your", "we", "our");

    private Tokenizer() {
    }

    /** Splits text into lowercase alphabetic tokens. */
    public static List<String> tokenize(String text) {
        List<String> tokens = new ArrayList<>();
        if (text == null || text.isBlank()) {
            return tokens;
        }
        StringBuilder current = new StringBuilder();
        for (char c : text.toLowerCase(Locale.ROOT).toCharArray()) {
            if (Character.isLetterOrDigit(c) || c == '\'') {
                current.append(c);
            } else if (current.length() > 0) {
                tokens.add(current.toString());
                current.setLength(0);
            }
        }
        if (current.length() > 0) {
            tokens.add(current.toString());
        }
        return tokens;
    }

    /** Tokenises, drops stop words and applies the stemmer. */
    public static List<String> normalise(String text) {
        List<String> result = new ArrayList<>();
        for (String token : tokenize(text)) {
            if (token.length() < 2 && !PROTECTED.contains(token)) {
                continue;
            }
            if (STOP_WORDS.contains(token) && !PROTECTED.contains(token)) {
                continue;
            }
            result.add(stem(token));
        }
        return result;
    }

    /**
     * A conservative suffix stripper in the spirit of the Porter stemmer.
     * Deliberately shallow — over-stemming would collapse distinct wellness
     * vocabulary ("stress"/"stressed" is helpful, "sleeping"/"sleep" is
     * helpful, but "sleeper" should not become "sleep").
     */
    public static String stem(String word) {
        String value = word;
        if (value.length() > 4 && value.endsWith("ing")) {
            value = value.substring(0, value.length() - 3);
        } else if (value.length() > 4 && value.endsWith("ed")) {
            value = value.substring(0, value.length() - 2);
        } else if (value.length() > 4 && value.endsWith("ly")) {
            value = value.substring(0, value.length() - 2);
        } else if (value.length() > 3 && value.endsWith("s") && !value.endsWith("ss")) {
            value = value.substring(0, value.length() - 1);
        }
        return value;
    }

    /** @return bigrams of the normalised tokens, which sharpen intent detection. */
    public static List<String> bigrams(List<String> tokens) {
        List<String> bigrams = new ArrayList<>();
        for (int i = 0; i + 1 < tokens.size(); i++) {
            bigrams.add(tokens.get(i) + "_" + tokens.get(i + 1));
        }
        return bigrams;
    }
}
