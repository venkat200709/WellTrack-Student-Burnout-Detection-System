package com.welltrack.ai.engine;

import com.welltrack.core.json.JsonArray;
import com.welltrack.core.json.JsonObject;
import com.welltrack.core.json.JsonSerializable;
import com.welltrack.core.util.Log;
import com.welltrack.core.util.Numbers;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Random;

/**
 * A regularised logistic-regression classifier trained by mini-batch gradient
 * descent — written from first principles, with no machine-learning library.
 *
 * <p><b>The model.</b> For a feature vector <i>x</i> the model computes the
 * log-odds {@code z = b + Σ wᵢ·xᵢ} and squashes it through the logistic
 * function {@code σ(z) = 1 / (1 + e^-z)} to obtain the probability that the
 * student is heading toward burnout.</p>
 *
 * <p><b>Training.</b> Weights are learned by minimising the binary
 * cross-entropy loss with L2 regularisation. The implementation uses:</p>
 * <ul>
 *   <li><b>mini-batches</b> with reshuffling each epoch, which converges far
 *       faster than full-batch descent and escapes shallow plateaus;</li>
 *   <li><b>momentum</b> (0.9) to damp oscillation across narrow valleys;</li>
 *   <li><b>class weighting</b>, so a minority of at-risk examples still shapes
 *       the decision boundary — critical because missing an at-risk student is
 *       the expensive error;</li>
 *   <li><b>early stopping</b> against a held-out validation split, keeping the
 *       best weights seen rather than the last.</li>
 * </ul>
 *
 * <p><b>Why logistic regression?</b> It is the right tool for a wellness
 * system: the learned weights <em>are</em> the explanation. Each coefficient
 * states how much one behaviour shifts the odds of burnout, which lets
 * WellTrack tell a student exactly why they were flagged instead of handing
 * them an opaque number.</p>
 */
public final class LogisticRegressionModel implements JsonSerializable {

    private final String[] featureNames;
    private double[] weights;
    private double bias;
    private boolean trained;
    private ModelMetrics metrics;
    private double decisionThreshold = 0.5;

    public LogisticRegressionModel(String[] featureNames) {
        this.featureNames = featureNames.clone();
        this.weights = new double[featureNames.length];
    }

    // ------------------------------------------------------------------
    // Training
    // ------------------------------------------------------------------

    /**
     * Fits the model.
     *
     * @param samples        standardised design matrix
     * @param labels         binary outcomes (1 = burnout risk materialised)
     * @param epochs         maximum passes over the data
     * @param learningRate   step size for gradient descent
     * @param l2             L2 regularisation strength
     * @param batchSize      mini-batch size
     * @param seed           random seed, so training is fully reproducible
     */
    public ModelMetrics train(double[][] samples, int[] labels, int epochs,
                              double learningRate, double l2, int batchSize, long seed) {
        if (samples.length != labels.length || samples.length == 0) {
            throw new IllegalArgumentException("Training data and labels must be non-empty and aligned");
        }
        int featureCount = samples[0].length;
        if (featureCount != featureNames.length) {
            throw new IllegalArgumentException(
                    "Expected " + featureNames.length + " features but received " + featureCount);
        }

        Random random = new Random(seed);
        weights = new double[featureCount];
        for (int i = 0; i < featureCount; i++) {
            // Small symmetric initialisation keeps the first gradients well-conditioned.
            weights[i] = (random.nextDouble() - 0.5) * 0.02;
        }
        bias = 0;

        // ---- Stratified train/validation split (80/20) -------------------
        List<Integer> order = new ArrayList<>(samples.length);
        for (int i = 0; i < samples.length; i++) {
            order.add(i);
        }
        Collections.shuffle(order, random);
        int validationSize = Math.max(1, samples.length / 5);
        List<Integer> validationIndices = order.subList(0, validationSize);
        List<Integer> trainingIndices = new ArrayList<>(order.subList(validationSize, order.size()));

        // ---- Class weights to counter imbalance --------------------------
        int positives = 0;
        for (int index : trainingIndices) {
            positives += labels[index];
        }
        int negatives = trainingIndices.size() - positives;
        double positiveWeight = positives == 0 ? 1 : trainingIndices.size() / (2.0 * positives);
        double negativeWeight = negatives == 0 ? 1 : trainingIndices.size() / (2.0 * negatives);

        double[] velocity = new double[featureCount];
        double biasVelocity = 0;
        final double momentum = 0.9;

        double bestValidationLoss = Double.MAX_VALUE;
        double[] bestWeights = weights.clone();
        double bestBias = bias;
        int epochsWithoutImprovement = 0;
        int executedEpochs = 0;

        for (int epoch = 1; epoch <= epochs; epoch++) {
            executedEpochs = epoch;
            Collections.shuffle(trainingIndices, random);

            for (int start = 0; start < trainingIndices.size(); start += batchSize) {
                int end = Math.min(start + batchSize, trainingIndices.size());
                double[] gradient = new double[featureCount];
                double biasGradient = 0;
                double weightSum = 0;

                for (int b = start; b < end; b++) {
                    int index = trainingIndices.get(b);
                    double[] x = samples[index];
                    int y = labels[index];
                    double weight = y == 1 ? positiveWeight : negativeWeight;
                    double error = (predictRaw(x) - y) * weight;
                    for (int f = 0; f < featureCount; f++) {
                        gradient[f] += error * x[f];
                    }
                    biasGradient += error;
                    weightSum += weight;
                }

                double scale = weightSum == 0 ? 1 : weightSum;
                for (int f = 0; f < featureCount; f++) {
                    double step = gradient[f] / scale + l2 * weights[f];
                    velocity[f] = momentum * velocity[f] - learningRate * step;
                    weights[f] += velocity[f];
                }
                biasVelocity = momentum * biasVelocity - learningRate * (biasGradient / scale);
                bias += biasVelocity;
            }

            double validationLoss = crossEntropy(samples, labels, validationIndices);
            if (validationLoss < bestValidationLoss - 1e-6) {
                bestValidationLoss = validationLoss;
                bestWeights = weights.clone();
                bestBias = bias;
                epochsWithoutImprovement = 0;
            } else if (++epochsWithoutImprovement >= 25) {
                Log.info("LogisticRegression", "Early stop at epoch " + epoch
                        + " (validation loss " + Numbers.round(bestValidationLoss, 5) + ")");
                break;
            }
        }

        weights = bestWeights;
        bias = bestBias;
        trained = true;
        this.decisionThreshold = chooseThreshold(samples, labels, validationIndices);
        this.metrics = evaluate(samples, labels, validationIndices,
                bestValidationLoss, trainingIndices.size(), executedEpochs);
        return metrics;
    }

    /**
     * Picks the probability cut-off that maximises the F1 score on the
     * validation split, rather than blindly using 0.5. In an imbalanced
     * wellness dataset this materially improves recall.
     */
    private double chooseThreshold(double[][] samples, int[] labels, List<Integer> indices) {
        double best = 0.5;
        double bestF1 = -1;
        for (double candidate = 0.20; candidate <= 0.80; candidate += 0.01) {
            int tp = 0;
            int fp = 0;
            int fn = 0;
            for (int index : indices) {
                boolean predicted = predictRaw(samples[index]) >= candidate;
                boolean actual = labels[index] == 1;
                if (predicted && actual) {
                    tp++;
                } else if (predicted) {
                    fp++;
                } else if (actual) {
                    fn++;
                }
            }
            double precision = (tp + fp) == 0 ? 0 : tp / (double) (tp + fp);
            double recall = (tp + fn) == 0 ? 0 : tp / (double) (tp + fn);
            double f1 = (precision + recall) == 0 ? 0 : 2 * precision * recall / (precision + recall);
            if (f1 > bestF1) {
                bestF1 = f1;
                best = candidate;
            }
        }
        return best;
    }

    private ModelMetrics evaluate(double[][] samples, int[] labels, List<Integer> indices,
                                  double logLoss, int trainingSamples, int iterations) {
        int tp = 0;
        int fp = 0;
        int tn = 0;
        int fn = 0;
        List<double[]> scored = new ArrayList<>(indices.size());
        for (int index : indices) {
            double probability = predictRaw(samples[index]);
            boolean predicted = probability >= decisionThreshold;
            boolean actual = labels[index] == 1;
            scored.add(new double[]{probability, actual ? 1 : 0});
            if (predicted && actual) {
                tp++;
            } else if (predicted) {
                fp++;
            } else if (actual) {
                fn++;
            } else {
                tn++;
            }
        }
        return new ModelMetrics(tp, fp, tn, fn, logLoss, rocAuc(scored), trainingSamples, iterations);
    }

    /**
     * Area under the ROC curve, computed with the rank-based (Mann-Whitney)
     * formulation, which avoids materialising the curve itself.
     */
    private static double rocAuc(List<double[]> scored) {
        List<double[]> sorted = new ArrayList<>(scored);
        sorted.sort((a, b) -> Double.compare(a[0], b[0]));
        double rankSumPositive = 0;
        int positives = 0;
        int negatives = 0;
        for (int i = 0; i < sorted.size(); i++) {
            if (sorted.get(i)[1] == 1) {
                rankSumPositive += i + 1;
                positives++;
            } else {
                negatives++;
            }
        }
        if (positives == 0 || negatives == 0) {
            return 0.5;
        }
        return (rankSumPositive - positives * (positives + 1) / 2.0) / ((double) positives * negatives);
    }

    private double crossEntropy(double[][] samples, int[] labels, List<Integer> indices) {
        double loss = 0;
        for (int index : indices) {
            double probability = Numbers.clamp(predictRaw(samples[index]), 1e-9, 1 - 1e-9);
            loss += labels[index] == 1 ? -Math.log(probability) : -Math.log(1 - probability);
        }
        return indices.isEmpty() ? 0 : loss / indices.size();
    }

    // ------------------------------------------------------------------
    // Inference
    // ------------------------------------------------------------------

    /** @return P(burnout | features) for a standardised observation. */
    public double predict(double[] standardisedFeatures) {
        if (!trained) {
            throw new IllegalStateException("The model has not been trained yet");
        }
        return predictRaw(standardisedFeatures);
    }

    private double predictRaw(double[] x) {
        double z = bias;
        for (int i = 0; i < weights.length; i++) {
            z += weights[i] * x[i];
        }
        return sigmoid(z);
    }

    /** The numerically stable logistic function. */
    public static double sigmoid(double z) {
        if (z >= 0) {
            return 1.0 / (1.0 + Math.exp(-z));
        }
        double exp = Math.exp(z);
        return exp / (1.0 + exp);
    }

    /**
     * Per-feature contribution to the log-odds for one observation.
     *
     * <p>Because the model is linear in its inputs, {@code wᵢ·xᵢ} on the
     * standardised scale <em>is</em> the exact additive contribution of feature
     * {@code i} — the same quantity SHAP approximates for non-linear models,
     * available here in closed form.</p>
     */
    public double[] contributions(double[] standardisedFeatures) {
        double[] contributions = new double[weights.length];
        for (int i = 0; i < weights.length; i++) {
            contributions[i] = weights[i] * standardisedFeatures[i];
        }
        return contributions;
    }

    public double decisionThreshold() {
        return decisionThreshold;
    }

    public boolean isTrained() {
        return trained;
    }

    public ModelMetrics metrics() {
        return metrics;
    }

    public double[] weights() {
        return weights.clone();
    }

    public double bias() {
        return bias;
    }

    public String[] featureNames() {
        return featureNames.clone();
    }

    /** @return features ordered by absolute learned influence. */
    public List<String> rankedFeatures() {
        Integer[] order = new Integer[weights.length];
        for (int i = 0; i < order.length; i++) {
            order[i] = i;
        }
        Arrays.sort(order, (a, b) -> Double.compare(Math.abs(weights[b]), Math.abs(weights[a])));
        List<String> ranked = new ArrayList<>(order.length);
        for (int index : order) {
            ranked.add(featureNames[index]);
        }
        return ranked;
    }

    @Override
    public JsonObject toJson() {
        JsonArray coefficients = new JsonArray();
        for (int i = 0; i < weights.length; i++) {
            coefficients.add(JsonObject.of()
                    .set("feature", featureNames[i])
                    .set("weight", Numbers.round(weights[i], 5))
                    .set("influence", Numbers.round(Math.abs(weights[i]), 5))
                    .set("direction", weights[i] >= 0 ? "increases risk" : "reduces risk"));
        }
        return JsonObject.of()
                .set("algorithm", "Logistic Regression (mini-batch gradient descent, L2 + momentum)")
                .set("trained", trained)
                .set("bias", Numbers.round(bias, 5))
                .set("decisionThreshold", Numbers.round(decisionThreshold, 3))
                .set("featureCount", weights.length)
                .set("coefficients", coefficients)
                .setIfPresent("metrics", metrics == null ? null : metrics.toJson());
    }
}
