package com.welltrack.ai.engine;

import com.welltrack.core.json.JsonObject;
import com.welltrack.core.json.JsonSerializable;
import com.welltrack.core.util.Numbers;

/**
 * Hold-out evaluation metrics for a binary classifier.
 *
 * <p>Accuracy alone is misleading when classes are imbalanced, so WellTrack
 * reports the full confusion matrix, precision, recall, F1 and the area under
 * the ROC curve. Recall matters most here: failing to flag a student who is
 * heading for burnout is far costlier than a false alarm.</p>
 */
public record ModelMetrics(int truePositives,
                           int falsePositives,
                           int trueNegatives,
                           int falseNegatives,
                           double logLoss,
                           double rocAuc,
                           int trainingSamples,
                           int iterations) implements JsonSerializable {

    public int total() {
        return truePositives + falsePositives + trueNegatives + falseNegatives;
    }

    public double accuracy() {
        int total = total();
        return total == 0 ? 0 : (truePositives + trueNegatives) / (double) total;
    }

    public double precision() {
        int predictedPositive = truePositives + falsePositives;
        return predictedPositive == 0 ? 0 : truePositives / (double) predictedPositive;
    }

    public double recall() {
        int actualPositive = truePositives + falseNegatives;
        return actualPositive == 0 ? 0 : truePositives / (double) actualPositive;
    }

    public double f1() {
        double precision = precision();
        double recall = recall();
        return (precision + recall) == 0 ? 0 : 2 * precision * recall / (precision + recall);
    }

    /** Balanced accuracy — the mean of sensitivity and specificity. */
    public double balancedAccuracy() {
        double specificity = (trueNegatives + falsePositives) == 0
                ? 0 : trueNegatives / (double) (trueNegatives + falsePositives);
        return (recall() + specificity) / 2.0;
    }

    @Override
    public JsonObject toJson() {
        return JsonObject.of()
                .set("accuracy", Numbers.round(accuracy(), 4))
                .set("precision", Numbers.round(precision(), 4))
                .set("recall", Numbers.round(recall(), 4))
                .set("f1", Numbers.round(f1(), 4))
                .set("balancedAccuracy", Numbers.round(balancedAccuracy(), 4))
                .set("rocAuc", Numbers.round(rocAuc, 4))
                .set("logLoss", Numbers.round(logLoss, 4))
                .set("truePositives", truePositives)
                .set("falsePositives", falsePositives)
                .set("trueNegatives", trueNegatives)
                .set("falseNegatives", falseNegatives)
                .set("evaluationSamples", total())
                .set("trainingSamples", trainingSamples)
                .set("iterations", iterations);
    }
}
