package com.welltrack.ai.nlp;

import com.welltrack.core.json.JsonArray;
import com.welltrack.core.json.JsonObject;
import com.welltrack.core.util.Numbers;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * A lexicon-based sentiment and emotion analyser tuned for student wellness
 * journalling.
 *
 * <p>General-purpose sentiment models mis-read academic language: "I crashed
 * after the deadline" is exhaustion, not a car accident, and "I'm fine" from a
 * student logging four hours of sleep deserves scepticism. This analyser
 * therefore uses a domain lexicon and adds three linguistic refinements that
 * naive bag-of-words scoring gets wrong:</p>
 * <ul>
 *   <li><b>Negation scope</b> — "not happy" flips polarity for the following
 *       three tokens rather than counting "happy" as positive;</li>
 *   <li><b>Intensifiers and dampeners</b> — "extremely tired" outweighs
 *       "slightly tired";</li>
 *   <li><b>Emotion channels</b> — beyond a single polarity the analyser reports
 *       exhaustion, anxiety, isolation, hopelessness and motivation, which is
 *       what actually distinguishes burnout from ordinary stress.</li>
 * </ul>
 */
public final class SentimentAnalyzer {

    private final Map<String, Double> lexicon = new HashMap<>();
    private final Map<String, Double> intensifiers = new HashMap<>();
    private final Set<String> negators = Set.of("not", "no", "never", "cannot", "cant", "dont", "wont", "hardly");

    private final Map<String, Set<String>> emotionChannels = new HashMap<>();

    /** Phrases that signal acute distress and must always be surfaced. */
    private static final List<String> CRISIS_MARKERS = List.of(
            "give up", "giving up", "cant go on", "can't go on", "end it",
            "no point", "worthless", "hopeless", "hurt myself", "harm myself",
            "nobody cares", "want to disappear");

    public SentimentAnalyzer() {
        seedLexicon();
        seedIntensifiers();
        seedEmotions();
    }

    private void seedLexicon() {
        // Positive wellness vocabulary.
        addAll(1.0, "great", "amazing", "excellent", "wonderful", "fantastic", "thrive", "energised", "energized");
        addAll(0.8, "good", "happy", "confident", "calm", "relaxed", "rested", "productive", "proud", "grateful");
        addAll(0.6, "okay", "fine", "steady", "manageable", "improving", "better", "hopeful", "focused");
        addAll(0.5, "enjoy", "like", "progress", "achieve", "complete", "finish", "win", "support");

        // Negative wellness vocabulary.
        addAll(-1.0, "hopeless", "worthless", "unbearable", "breaking", "collapse", "burnout", "burnt", "crushed");
        addAll(-0.9, "exhausted", "drained", "depleted", "overwhelmed", "panic", "terrible", "awful", "miserable");
        addAll(-0.7, "stressed", "anxious", "worried", "afraid", "scared", "lonely", "isolated", "depressed");
        addAll(-0.6, "tired", "sleepless", "insomnia", "restless", "frustrated", "angry", "irritated", "pressure");
        addAll(-0.5, "behind", "struggling", "difficult", "hard", "confused", "lost", "stuck", "procrastinate");
        addAll(-0.4, "bad", "sad", "low", "down", "unmotivated", "bored", "distracted", "skipped", "missed");
    }

    private void seedIntensifiers() {
        intensifiers.put("very", 1.5);
        intensifiers.put("extremely", 1.9);
        intensifiers.put("really", 1.4);
        intensifiers.put("so", 1.35);
        intensifiers.put("totally", 1.6);
        intensifiers.put("completely", 1.7);
        intensifiers.put("absolutely", 1.7);
        intensifiers.put("incredibly", 1.8);
        intensifiers.put("slightly", 0.55);
        intensifiers.put("somewhat", 0.65);
        intensifiers.put("bit", 0.6);
        intensifiers.put("little", 0.6);
        intensifiers.put("kind", 0.7);
    }

    private void seedEmotions() {
        emotionChannels.put("exhaustion", Set.of("tired", "exhaust", "drain", "deplet", "sleep", "fatigue",
                "burnout", "burnt", "energy", "nap", "insomnia", "awake"));
        emotionChannels.put("anxiety", Set.of("anxious", "worri", "panic", "nervous", "afraid", "scared",
                "stress", "fear", "overwhelm", "dread", "tense"));
        emotionChannels.put("isolation", Set.of("lonely", "alone", "isolat", "nobody", "friend", "talk",
                "disconnect", "withdraw"));
        emotionChannels.put("hopelessness", Set.of("hopeless", "pointless", "worthless", "give", "quit",
                "fail", "useless", "stuck"));
        emotionChannels.put("motivation", Set.of("goal", "plan", "focus", "study", "achiev", "improv",
                "progress", "start", "finish", "complet"));
    }

    private void addAll(double weight, String... words) {
        for (String word : words) {
            lexicon.put(Tokenizer.stem(word), weight);
        }
    }

    /**
     * Scores a passage of text.
     *
     * @return a report containing polarity, intensity, emotion channel scores,
     *         the tokens that drove the verdict and any crisis markers
     */
    public SentimentReport analyse(String text) {
        List<String> rawTokens = Tokenizer.tokenize(text);
        if (rawTokens.isEmpty()) {
            return new SentimentReport(0, 0, Map.of(), List.of(), false);
        }

        double total = 0;
        int scoredTerms = 0;
        List<String> influential = new ArrayList<>();
        Map<String, Double> emotions = new HashMap<>();
        emotionChannels.keySet().forEach(channel -> emotions.put(channel, 0.0));

        int negationCountdown = 0;
        double pendingMultiplier = 1.0;

        for (String raw : rawTokens) {
            String token = Tokenizer.stem(raw);

            if (negators.contains(raw)) {
                negationCountdown = 3;
                continue;
            }
            if (intensifiers.containsKey(raw)) {
                pendingMultiplier = intensifiers.get(raw);
                continue;
            }

            Double weight = lexicon.get(token);
            if (weight != null) {
                double value = weight * pendingMultiplier;
                if (negationCountdown > 0) {
                    value = -value * 0.85;
                }
                total += value;
                scoredTerms++;
                if (Math.abs(value) >= 0.6) {
                    influential.add(raw);
                }
                pendingMultiplier = 1.0;
            }

            for (Map.Entry<String, Set<String>> entry : emotionChannels.entrySet()) {
                for (String marker : entry.getValue()) {
                    if (token.startsWith(marker)) {
                        emotions.merge(entry.getKey(), 1.0, Double::sum);
                        break;
                    }
                }
            }

            if (negationCountdown > 0) {
                negationCountdown--;
            }
        }

        double polarity = scoredTerms == 0 ? 0 : Numbers.clamp(total / Math.sqrt(scoredTerms), -1, 1);
        double intensity = Numbers.clamp(Math.abs(total) / Math.max(1, rawTokens.size() / 4.0), 0, 1);

        // Normalise emotion counts into 0-1 channel strengths.
        Map<String, Double> normalisedEmotions = new HashMap<>();
        double tokenCount = Math.max(1, rawTokens.size());
        emotions.forEach((channel, count) ->
                normalisedEmotions.put(channel, Numbers.clamp(count / (tokenCount / 6.0), 0, 1)));

        String lowercase = text == null ? "" : text.toLowerCase();
        boolean crisis = CRISIS_MARKERS.stream().anyMatch(lowercase::contains);

        return new SentimentReport(polarity, intensity, normalisedEmotions, influential, crisis);
    }

    /** Immutable result of a sentiment analysis. */
    public record SentimentReport(double polarity,
                                  double intensity,
                                  Map<String, Double> emotions,
                                  List<String> influentialTerms,
                                  boolean crisisMarkerDetected) {

        public String label() {
            if (polarity <= -0.55) {
                return "Very negative";
            }
            if (polarity <= -0.15) {
                return "Negative";
            }
            if (polarity < 0.15) {
                return "Neutral";
            }
            if (polarity < 0.55) {
                return "Positive";
            }
            return "Very positive";
        }

        /** @return the emotion channel with the highest activation. */
        public String dominantEmotion() {
            return emotions.entrySet().stream()
                    .filter(entry -> entry.getValue() > 0.05)
                    .max(Map.Entry.comparingByValue())
                    .map(Map.Entry::getKey)
                    .orElse("neutral");
        }

        /** Maps polarity onto the 0-1 mood valence scale used by the model. */
        public double toValence() {
            return Numbers.clamp((polarity + 1) / 2.0, 0, 1);
        }

        public JsonObject toJson() {
            JsonObject emotionJson = new JsonObject();
            emotions.forEach((key, value) -> emotionJson.set(key, Numbers.round(value, 3)));
            JsonArray terms = new JsonArray();
            influentialTerms.forEach(terms::add);
            return JsonObject.of()
                    .set("polarity", Numbers.round(polarity, 3))
                    .set("intensity", Numbers.round(intensity, 3))
                    .set("label", label())
                    .set("dominantEmotion", dominantEmotion())
                    .set("emotions", emotionJson)
                    .set("influentialTerms", terms)
                    .set("crisisMarkerDetected", crisisMarkerDetected);
        }
    }
}
