package com.welltrack.ai;

import com.welltrack.ai.engine.LogisticRegressionModel;
import com.welltrack.ai.engine.ModelMetrics;
import com.welltrack.ai.engine.StandardScaler;
import com.welltrack.core.json.JsonObject;
import com.welltrack.core.util.AppConfig;
import com.welltrack.core.util.Log;
import com.welltrack.core.util.Numbers;
import com.welltrack.model.BehaviorLog;
import com.welltrack.model.RiskDriver;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

/**
 * The supervised component of WellTrack's AI: a trained burnout classifier
 * with built-in explainability.
 *
 * <p>Responsibilities:</p>
 * <ol>
 *   <li>train a {@link LogisticRegressionModel} at start-up on a dataset from
 *       {@link TrainingDataFactory}, standardised by a {@link StandardScaler};</li>
 *   <li>aggregate a student's recent {@link BehaviorLog} entries into one
 *       feature vector, weighting recent days more heavily;</li>
 *   <li>convert the resulting probability into a 0-100 score;</li>
 *   <li>decompose that score into ranked, plain-English {@link RiskDriver}s.</li>
 * </ol>
 *
 * <p>Training happens once, on a background thread, and takes well under a
 * second — the application is usable immediately and transparently upgrades
 * from the heuristic to the learned model the moment training completes.</p>
 */
public final class BurnoutPredictor {

    private final LogisticRegressionModel model =
            new LogisticRegressionModel(BehaviorLog.FEATURE_NAMES);
    private final StandardScaler scaler = new StandardScaler();

    private volatile boolean ready;
    private ModelMetrics metrics;
    private long trainingMillis;
    private int trainingSamples;
    private double positiveRate;

    /** Trains the model. Safe to call once during application start-up. */
    public synchronized void train() {
        AppConfig config = AppConfig.get();
        int samples = config.integer("ai.training-samples", 6000);
        int epochs = config.integer("ai.epochs", 320);
        double learningRate = config.number("ai.learning-rate", 0.08);
        double l2 = config.number("ai.l2", 0.004);
        int batchSize = config.integer("ai.batch-size", 48);
        long seed = config.integer("ai.seed", 20260811);

        long started = System.currentTimeMillis();
        TrainingDataFactory.Dataset dataset = TrainingDataFactory.generate(samples, seed);
        double[][] standardised = scaler.fitTransform(dataset.features());
        metrics = model.train(standardised, dataset.labels(), epochs, learningRate, l2, batchSize, seed);

        trainingMillis = System.currentTimeMillis() - started;
        trainingSamples = dataset.size();
        positiveRate = dataset.positiveRate();
        ready = true;

        Log.success("BurnoutPredictor",
                "Model trained on %,d samples in %d ms — accuracy %.1f%%, recall %.1f%%, ROC-AUC %.3f"
                        .formatted(trainingSamples, trainingMillis,
                                metrics.accuracy() * 100, metrics.recall() * 100, metrics.rocAuc()));
    }

    public boolean isReady() {
        return ready;
    }

    /**
     * Collapses a window of daily logs into one feature vector.
     *
     * <p>Recent days matter more than distant ones, so an exponential recency
     * weight (half-life of five days) is applied. This is what allows the
     * system to react to a bad week without being dominated by a good month.</p>
     */
    public double[] aggregate(List<BehaviorLog> window) {
        int featureCount = BehaviorLog.FEATURE_NAMES.length;
        double[] aggregated = new double[featureCount];
        if (window == null || window.isEmpty()) {
            return aggregated;
        }
        double weightSum = 0;
        int size = window.size();
        for (int i = 0; i < size; i++) {
            // i = 0 is the oldest entry in the window.
            int daysAgo = size - 1 - i;
            double weight = Math.pow(0.5, daysAgo / 5.0);
            double[] vector = window.get(i).toFeatureVector();
            for (int f = 0; f < featureCount; f++) {
                aggregated[f] += vector[f] * weight;
            }
            weightSum += weight;
        }
        if (weightSum > 0) {
            for (int f = 0; f < featureCount; f++) {
                aggregated[f] /= weightSum;
            }
        }
        return aggregated;
    }

    /** @return P(burnout) for an aggregated feature vector. */
    public double probability(double[] rawFeatures) {
        if (!ready) {
            throw new IllegalStateException("The burnout model is still training");
        }
        return model.predict(scaler.transform(rawFeatures));
    }

    /**
     * Explains a prediction.
     *
     * <p>Because the classifier is linear on the standardised scale, the term
     * {@code wᵢ·zᵢ} is the exact additive contribution of feature {@code i} to
     * the log-odds. Contributions are ranked by absolute magnitude and rendered
     * through {@link FeatureCatalog} so each one reads as a sentence.</p>
     */
    public List<RiskDriver> explain(double[] rawFeatures, int limit) {
        List<RiskDriver> drivers = new ArrayList<>();
        if (!ready) {
            return drivers;
        }
        double[] standardised = scaler.transform(rawFeatures);
        double[] contributions = model.contributions(standardised);

        for (int i = 0; i < contributions.length; i++) {
            FeatureCatalog.FeatureInfo info = FeatureCatalog.byIndex(i);
            boolean aggravating = contributions[i] > 0;
            double displayValue = displayValue(i, rawFeatures[i]);
            drivers.add(new RiskDriver(
                    info.key(),
                    info.label(),
                    Numbers.round(displayValue, 2),
                    Numbers.round(contributions[i], 4),
                    info.describe(displayValue, aggravating)));
        }
        drivers.sort(Comparator.comparingDouble(RiskDriver::magnitude).reversed());
        return drivers.size() <= limit ? drivers : new ArrayList<>(drivers.subList(0, limit));
    }

    /** Attendance is stored as a ratio but reads better as a percentage. */
    private double displayValue(int featureIndex, double rawValue) {
        return "attendanceRatio".equals(BehaviorLog.FEATURE_NAMES[featureIndex])
                ? rawValue * 100
                : rawValue;
    }

    /**
     * Maps the model probability onto the 0-100 score presented to users.
     *
     * <p>A mild sigmoid re-shaping around the learned decision threshold
     * expands the middle of the range, so that the difference between a
     * genuinely borderline student and a clearly struggling one is visible on
     * the dial rather than compressed into a couple of points.</p>
     */
    public double toScore(double probability) {
        double centred = (probability - model.decisionThreshold()) * 6.0;
        double shaped = LogisticRegressionModel.sigmoid(centred);
        return Numbers.clamp(shaped * 100, 0, 100);
    }

    public ModelMetrics metrics() {
        return metrics;
    }

    public LogisticRegressionModel model() {
        return model;
    }

    /** A full description of the trained model for the AI transparency panel. */
    public JsonObject describe() {
        return JsonObject.of()
                .set("ready", ready)
                .set("trainingSamples", trainingSamples)
                .set("trainingMillis", trainingMillis)
                .set("positiveClassRate", Numbers.round(positiveRate, 3))
                .set("featureNames", BehaviorLog.FEATURE_NAMES)
                .set("model", model.toJson())
                .set("scaler", scaler.toJson());
    }
}
