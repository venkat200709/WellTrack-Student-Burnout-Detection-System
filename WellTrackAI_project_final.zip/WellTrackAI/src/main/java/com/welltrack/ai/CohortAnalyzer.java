package com.welltrack.ai;

import com.welltrack.ai.engine.KMeansClusterer;
import com.welltrack.ai.engine.StandardScaler;
import com.welltrack.core.json.JsonArray;
import com.welltrack.core.json.JsonObject;
import com.welltrack.core.util.Log;
import com.welltrack.core.util.Numbers;
import com.welltrack.model.BehaviorLog;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Unsupervised discovery of <em>wellness cohorts</em>.
 *
 * <p>Clustering students by behavioural signature answers questions a
 * per-student score cannot. It tells a mentor that eleven students share a
 * "sleep-deprived high achiever" pattern rather than presenting eleven
 * unrelated numbers, and it tells a student where they stand relative to peers
 * facing the same pressures — which is far more motivating than an absolute
 * score.</p>
 *
 * <p>Cohort names are generated from the centroid itself: the analyser inspects
 * which standardised features are extreme and composes a description, so the
 * labels stay truthful even as the student body changes.</p>
 */
public final class CohortAnalyzer {

    /** One discovered cohort. */
    public record Cohort(int id,
                         String name,
                         String description,
                         int size,
                         double averageRisk,
                         double[] centroid,
                         List<Long> memberIds) {
    }

    private final Map<Long, Integer> assignmentsByStudent = new HashMap<>();
    private final List<Cohort> cohorts = new ArrayList<>();
    private double silhouette;
    private int clusterCount;

    /**
     * Clusters the given students.
     *
     * @param featuresByStudent aggregated feature vector for each student id
     * @param riskByStudent     the student's latest risk score
     */
    public synchronized void analyse(Map<Long, double[]> featuresByStudent,
                                     Map<Long, Double> riskByStudent) {
        assignmentsByStudent.clear();
        cohorts.clear();

        if (featuresByStudent.size() < 4) {
            Log.info("CohortAnalyzer", "Too few students to form meaningful cohorts");
            return;
        }

        List<Long> ids = new ArrayList<>(featuresByStudent.keySet());
        double[][] matrix = new double[ids.size()][];
        for (int i = 0; i < ids.size(); i++) {
            matrix[i] = featuresByStudent.get(ids.get(i));
        }

        StandardScaler scaler = new StandardScaler();
        double[][] standardised = scaler.fitTransform(matrix);

        KMeansClusterer clusterer = new KMeansClusterer(120, 20260811L);
        int k = clusterer.fitBest(standardised, 2, Math.min(5, ids.size() - 1));
        int[] assignments = clusterer.assignments();
        double[][] centroids = clusterer.centroids();

        this.silhouette = clusterer.silhouette();
        this.clusterCount = k;

        Map<Integer, List<Long>> membersByCluster = new LinkedHashMap<>();
        for (int i = 0; i < ids.size(); i++) {
            assignmentsByStudent.put(ids.get(i), assignments[i]);
            membersByCluster.computeIfAbsent(assignments[i], key -> new ArrayList<>()).add(ids.get(i));
        }

        for (int cluster = 0; cluster < k; cluster++) {
            List<Long> members = membersByCluster.getOrDefault(cluster, List.of());
            double averageRisk = members.stream()
                    .mapToDouble(id -> riskByStudent.getOrDefault(id, 0.0))
                    .average().orElse(0);
            String name = nameFor(centroids[cluster], averageRisk);
            cohorts.add(new Cohort(cluster, name, describe(centroids[cluster]),
                    members.size(), averageRisk, centroids[cluster], members));
        }

        Log.success("CohortAnalyzer",
                "Discovered %d wellness cohorts (silhouette %.3f) across %d students"
                        .formatted(k, silhouette, ids.size()));
    }

    /**
     * Names a cohort from the shape of its centroid. The centroid lives on the
     * standardised scale, so a value beyond ±0.6 means "clearly above/below the
     * student body average" for that behaviour.
     */
    private String nameFor(double[] centroid, double averageRisk) {
        double sleep = at(centroid, "sleepHours");
        double study = at(centroid, "studyHours");
        double stress = at(centroid, "stressLevel");
        double social = at(centroid, "socialMinutes");
        double attendance = at(centroid, "attendanceRatio");
        double screen = at(centroid, "screenTimeHours");

        if (sleep < -0.5 && study > 0.4) {
            return "Sleep-Deprived High Achievers";
        }
        if (stress > 0.6 && social < -0.4) {
            return "Isolated & Overloaded";
        }
        if (attendance < -0.6) {
            return "Disengagement Risk";
        }
        if (screen > 0.6 && study < -0.2) {
            return "Digitally Distracted";
        }
        if (averageRisk < 30 && sleep > 0.2) {
            return "Balanced & Resilient";
        }
        if (stress > 0.3) {
            return "Pressure Sensitive";
        }
        return "Steady Middle";
    }

    private String describe(double[] centroid) {
        List<String> traits = new ArrayList<>();
        appendTrait(traits, centroid, "sleepHours", "sleeps more than most", "sleeps noticeably less");
        appendTrait(traits, centroid, "studyHours", "studies long hours", "studies moderately");
        appendTrait(traits, centroid, "stressLevel", "reports high stress", "reports low stress");
        appendTrait(traits, centroid, "socialMinutes", "socialises frequently", "socialises rarely");
        appendTrait(traits, centroid, "exerciseMinutes", "exercises regularly", "rarely exercises");
        if (traits.isEmpty()) {
            return "Close to the student-body average across every tracked behaviour.";
        }
        return "This group " + String.join(", ", traits) + ".";
    }

    private void appendTrait(List<String> traits, double[] centroid, String feature,
                             String highPhrase, String lowPhrase) {
        double value = at(centroid, feature);
        if (value > 0.6) {
            traits.add(highPhrase);
        } else if (value < -0.6) {
            traits.add(lowPhrase);
        }
    }

    private double at(double[] centroid, String feature) {
        String[] names = BehaviorLog.FEATURE_NAMES;
        for (int i = 0; i < names.length && i < centroid.length; i++) {
            if (names[i].equals(feature)) {
                return centroid[i];
            }
        }
        return 0;
    }

    public Cohort cohortOf(long studentId) {
        Integer cluster = assignmentsByStudent.get(studentId);
        if (cluster == null) {
            return null;
        }
        return cohorts.stream().filter(cohort -> cohort.id() == cluster).findFirst().orElse(null);
    }

    public List<Cohort> cohorts() {
        return List.copyOf(cohorts);
    }

    public double silhouette() {
        return silhouette;
    }

    public JsonObject toJson() {
        JsonArray array = new JsonArray();
        for (Cohort cohort : cohorts) {
            array.add(JsonObject.of()
                    .set("id", cohort.id())
                    .set("name", cohort.name())
                    .set("description", cohort.description())
                    .set("size", cohort.size())
                    .set("averageRisk", Numbers.round(cohort.averageRisk(), 1)));
        }
        return JsonObject.of()
                .set("algorithm", "K-Means (k-means++ seeding, silhouette model selection)")
                .set("clusters", clusterCount)
                .set("silhouette", Numbers.round(silhouette, 4))
                .set("cohorts", array);
    }
}
