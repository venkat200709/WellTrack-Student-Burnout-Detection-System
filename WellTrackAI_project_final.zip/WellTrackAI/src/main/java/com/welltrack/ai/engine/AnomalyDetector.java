package com.welltrack.ai.engine;

import com.welltrack.core.json.JsonObject;
import com.welltrack.core.json.JsonSerializable;
import com.welltrack.core.util.Numbers;

import java.util.ArrayList;
import java.util.List;

/**
 * Robust statistical anomaly detection over a behavioural time series.
 *
 * <p>Two complementary tests run together:</p>
 * <ol>
 *   <li><b>Modified z-score</b> built on the median and the median absolute
 *       deviation. Unlike the classical z-score, the median is not dragged
 *       around by the very outliers we are hunting, so a single catastrophic
 *       night of two hours' sleep cannot hide itself by inflating the mean.
 *       The 0.6745 constant rescales MAD to be consistent with the standard
 *       deviation of a normal distribution.</li>
 *   <li><b>EWMA drift</b> — an exponentially weighted moving average compared
 *       against the long-run baseline, which catches the slow, creeping decline
 *       that never produces a single dramatic day but is exactly how burnout
 *       actually develops.</li>
 * </ol>
 */
public final class AnomalyDetector implements JsonSerializable {

    private static final double MAD_SCALE = 0.6745;

    private final double threshold;
    private final double smoothing;

    private double median;
    private double madScore;
    private double ewma;
    private double drift;
    private final List<Integer> anomalousIndices = new ArrayList<>();

    public AnomalyDetector(double threshold, double smoothing) {
        this.threshold = threshold;
        this.smoothing = smoothing;
    }

    public AnomalyDetector() {
        this(3.0, 0.3);
    }

    /** Analyses a series and records which points are anomalous. */
    public void analyse(double[] series) {
        anomalousIndices.clear();
        if (series == null || series.length < 4) {
            median = series == null || series.length == 0 ? 0 : Numbers.median(series);
            madScore = 0;
            ewma = median;
            drift = 0;
            return;
        }

        median = Numbers.median(series);
        double[] absoluteDeviations = new double[series.length];
        for (int i = 0; i < series.length; i++) {
            absoluteDeviations[i] = Math.abs(series[i] - median);
        }
        madScore = Numbers.median(absoluteDeviations);

        for (int i = 0; i < series.length; i++) {
            if (Math.abs(modifiedZScore(series[i])) > threshold) {
                anomalousIndices.add(i);
            }
        }

        ewma = series[0];
        for (int i = 1; i < series.length; i++) {
            ewma = smoothing * series[i] + (1 - smoothing) * ewma;
        }
        drift = ewma - median;
    }

    /** @return the modified z-score of a single value against the fitted series. */
    public double modifiedZScore(double value) {
        if (madScore < 1e-9) {
            return 0;
        }
        return MAD_SCALE * (value - median) / madScore;
    }

    /**
     * Converts the analysis into a 0-100 contribution for the risk ensemble.
     * Both the count of outliers and the direction of drift are considered.
     */
    public double anomalyScore(double[] series) {
        if (series == null || series.length < 4) {
            return 0;
        }
        analyse(series);
        double outlierRatio = anomalousIndices.size() / (double) series.length;
        double outlierComponent = Numbers.clamp(outlierRatio * 180, 0, 60);
        double driftComponent = Numbers.clamp(drift * 4.0, -20, 40);
        double volatility = Numbers.standardDeviation(series);
        double volatilityComponent = Numbers.clamp(volatility * 1.5, 0, 25);
        return Numbers.clamp(outlierComponent + driftComponent + volatilityComponent, 0, 100);
    }

    public List<Integer> anomalousIndices() {
        return List.copyOf(anomalousIndices);
    }

    public double drift() {
        return drift;
    }

    public double medianValue() {
        return median;
    }

    public double ewma() {
        return ewma;
    }

    public boolean hasAnomalies() {
        return !anomalousIndices.isEmpty();
    }

    @Override
    public JsonObject toJson() {
        return JsonObject.of()
                .set("algorithm", "Modified z-score (median absolute deviation) + EWMA drift")
                .set("threshold", threshold)
                .set("median", Numbers.round(median, 2))
                .set("medianAbsoluteDeviation", Numbers.round(madScore, 3))
                .set("ewma", Numbers.round(ewma, 2))
                .set("drift", Numbers.round(drift, 3))
                .set("anomalies", anomalousIndices.size());
    }
}
