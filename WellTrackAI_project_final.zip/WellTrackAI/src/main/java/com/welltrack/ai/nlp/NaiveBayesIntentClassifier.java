package com.welltrack.ai.nlp;

import com.welltrack.core.json.JsonObject;
import com.welltrack.core.json.JsonSerializable;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * A multinomial Naive Bayes text classifier with Laplace smoothing, used to
 * detect what a student is actually asking the wellness coach.
 *
 * <p>Classification is performed in log space:</p>
 * <pre>
 *   argmax_c [ log P(c) + Σ_t count(t) · log P(t | c) ]
 * </pre>
 * <p>Working with logarithms turns a product of many small probabilities into a
 * sum, which avoids floating-point underflow entirely. Add-one (Laplace)
 * smoothing guarantees that an unseen word never drives a class probability to
 * zero and wipes out all the evidence from the other words.</p>
 *
 * <p>Naive Bayes is a strong fit here: intents are short, the training set is
 * small and hand-curated, and the model trains in microseconds at start-up with
 * no external data or downloads.</p>
 */
public final class NaiveBayesIntentClassifier implements JsonSerializable {

    private final Map<String, Map<String, Integer>> termCountsByClass = new HashMap<>();
    private final Map<String, Integer> totalTermsByClass = new HashMap<>();
    private final Map<String, Integer> documentsByClass = new HashMap<>();
    private final Set<String> vocabulary = new HashSet<>();
    private int totalDocuments;

    /** Adds one labelled training example. */
    public void train(String intent, String example) {
        List<String> tokens = features(example);
        if (tokens.isEmpty()) {
            return;
        }
        totalDocuments++;
        documentsByClass.merge(intent, 1, Integer::sum);
        Map<String, Integer> counts = termCountsByClass.computeIfAbsent(intent, key -> new HashMap<>());
        for (String token : tokens) {
            counts.merge(token, 1, Integer::sum);
            totalTermsByClass.merge(intent, 1, Integer::sum);
            vocabulary.add(token);
        }
    }

    /** Trains from many examples of the same intent. */
    public void trainAll(String intent, String... examples) {
        for (String example : examples) {
            train(intent, example);
        }
    }

    /** @return the most probable intent together with its confidence. */
    public Prediction classify(String text) {
        List<String> tokens = features(text);
        if (tokens.isEmpty() || totalDocuments == 0) {
            return new Prediction("unknown", 0, Map.of());
        }

        Map<String, Double> logScores = new HashMap<>();
        for (String intent : documentsByClass.keySet()) {
            double logProbability = Math.log(documentsByClass.get(intent) / (double) totalDocuments);
            int denominator = totalTermsByClass.getOrDefault(intent, 0) + vocabulary.size();
            Map<String, Integer> counts = termCountsByClass.getOrDefault(intent, Map.of());
            for (String token : tokens) {
                int numerator = counts.getOrDefault(token, 0) + 1; // Laplace smoothing
                logProbability += Math.log(numerator / (double) denominator);
            }
            logScores.put(intent, logProbability);
        }

        // Convert log scores to a normalised distribution using the log-sum-exp trick.
        double max = logScores.values().stream().mapToDouble(Double::doubleValue).max().orElse(0);
        double sum = 0;
        Map<String, Double> distribution = new HashMap<>();
        for (Map.Entry<String, Double> entry : logScores.entrySet()) {
            double value = Math.exp(entry.getValue() - max);
            distribution.put(entry.getKey(), value);
            sum += value;
        }
        final double normaliser = sum == 0 ? 1 : sum;
        distribution.replaceAll((intent, value) -> value / normaliser);

        String best = distribution.entrySet().stream()
                .max(Map.Entry.comparingByValue())
                .map(Map.Entry::getKey)
                .orElse("unknown");
        return new Prediction(best, distribution.getOrDefault(best, 0.0), distribution);
    }

    private static List<String> features(String text) {
        List<String> tokens = new ArrayList<>(Tokenizer.normalise(text));
        tokens.addAll(Tokenizer.bigrams(tokens));
        return tokens;
    }

    public int vocabularySize() {
        return vocabulary.size();
    }

    public int trainedIntents() {
        return documentsByClass.size();
    }

    public int trainingExamples() {
        return totalDocuments;
    }

    /** The classifier's verdict. */
    public record Prediction(String intent, double confidence, Map<String, Double> distribution) {

        public boolean isConfident() {
            return confidence >= 0.35;
        }
    }

    @Override
    public JsonObject toJson() {
        return JsonObject.of()
                .set("algorithm", "Multinomial Naive Bayes (Laplace smoothing, log-space inference)")
                .set("intents", trainedIntents())
                .set("trainingExamples", trainingExamples())
                .set("vocabulary", vocabularySize());
    }
}
