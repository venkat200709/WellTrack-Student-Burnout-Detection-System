package com.welltrack.ai;

import com.welltrack.core.util.Numbers;
import com.welltrack.model.BehaviorLog;
import com.welltrack.model.Recommendation;
import com.welltrack.model.RiskDriver;
import com.welltrack.model.enums.RecommendationCategory;
import com.welltrack.model.enums.RiskLevel;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * A hybrid recommender that turns an explanation into an action plan.
 *
 * <p>Two signals are combined:</p>
 * <ol>
 *   <li><b>Content-based matching.</b> Every intervention in the knowledge base
 *       is indexed against the model feature it addresses, so the student's own
 *       top {@link RiskDriver}s select the interventions directly. The advice a
 *       student receives is therefore a mechanical consequence of the same
 *       coefficients that produced their score — the explanation and the
 *       prescription can never disagree.</li>
 *   <li><b>Collaborative evidence.</b> Cosine similarity over aggregated
 *       feature vectors finds the students whose behavioural signature most
 *       resembles this one; interventions that preceded genuine improvement in
 *       those peers are boosted.</li>
 * </ol>
 *
 * <p>Each recommendation carries an estimated risk reduction, derived from the
 * driver's own contribution magnitude, so the student can see which single
 * change buys the most relief.</p>
 */
public final class RecommendationEngine {

    /** A template in the intervention knowledge base. */
    private record Intervention(String featureKey,
                                RecommendationCategory category,
                                String title,
                                String detail,
                                String actionStep,
                                double baseImpact,
                                double evidence) {
    }

    private final Map<String, List<Intervention>> byFeature = new LinkedHashMap<>();

    public RecommendationEngine() {
        seedKnowledgeBase();
    }

    private void seedKnowledgeBase() {
        add("sleepHours", RecommendationCategory.SLEEP,
                "Rebuild a protected sleep window",
                "Sleep is the strongest single predictor in your model, and it is also the fastest lever to move. "
                        + "Recovery does not require a perfect eight hours immediately — it requires the same window every night.",
                "Pick a fixed lights-out time and hold it for the next five nights, even on the weekend.",
                14, 0.92);
        add("sleepDebt", RecommendationCategory.SLEEP,
                "Repay your sleep debt gradually",
                "Accumulated sleep debt cannot be cleared in one long weekend; adding 30-45 minutes per night for a week "
                        + "restores cognitive performance far more reliably than a single twelve-hour catch-up.",
                "Move tonight's bedtime 30 minutes earlier and repeat for seven nights.",
                11, 0.86);
        add("studyOverload", RecommendationCategory.STUDY,
                "Switch from hours to focused blocks",
                "Beyond roughly six hours a day, extra study time produces diminishing returns while continuing to consume "
                        + "recovery capacity. Structured blocks recover the lost efficiency without the extra hours.",
                "Run four 50-minute focus blocks with 10-minute breaks, then stop for the day.",
                10, 0.81);
        add("studyHours", RecommendationCategory.STUDY,
                "Protect one genuinely free evening",
                "A single reliably protected evening restores more capacity than several fragmented breaks, because the "
                        + "anticipation of it reduces sustained cognitive load during the week.",
                "Block one evening this week in your calendar with no academic work at all.",
                8, 0.74);
        add("stressLevel", RecommendationCategory.STRESS,
                "Down-regulate before you study, not after",
                "Physiological arousal decays slowly. Three minutes of paced breathing before a study block lowers baseline "
                        + "stress far more effectively than the same exercise afterwards.",
                "Try 4-second inhale, 6-second exhale for three minutes before your next study session.",
                9, 0.79);
        add("deadlinePressure", RecommendationCategory.ACADEMIC,
                "Convert the deadline wall into a sequence",
                "Deadline pressure is largely a function of ambiguity. Explicit sequencing converts one overwhelming wall "
                        + "into a set of individually achievable steps.",
                "List every pending deadline with its date, then commit to only the nearest two this week.",
                9, 0.83);
        add("assignmentsPending", RecommendationCategory.ACADEMIC,
                "Clear the smallest backlog item first",
                "A visible backlog imposes a constant background cognitive tax. Completing the smallest item breaks the "
                        + "avoidance loop and measurably reduces perceived load.",
                "Finish the single shortest pending assignment today, whatever its weighting.",
                7, 0.71);
        add("exerciseMinutes", RecommendationCategory.MOVEMENT,
                "Reintroduce daily movement",
                "Twenty minutes of moderate activity measurably buffers the stress response and improves sleep onset the "
                        + "same night — the two things your profile most needs.",
                "Walk briskly for 20 minutes after your last class today.",
                8, 0.88);
        add("socialMinutes", RecommendationCategory.SOCIAL,
                "Restore one real conversation a day",
                "Social withdrawal both signals burnout and accelerates it. One unhurried conversation a day is enough to "
                        + "interrupt that feedback loop.",
                "Message one friend today and arrange to meet in person this week.",
                7, 0.77);
        add("screenTimeHours", RecommendationCategory.DIGITAL,
                "Create a screen-free hour before bed",
                "Late-evening screen exposure delays melatonin release and fragments the first sleep cycle, which is where "
                        + "most physical recovery happens.",
                "Leave your phone charging outside the room for one hour before sleep.",
                7, 0.8);
        add("caffeineCups", RecommendationCategory.NUTRITION,
                "Set a caffeine cut-off time",
                "Caffeine has a half-life of five to six hours, so an afternoon coffee is still measurably active at "
                        + "bedtime and quietly sustains the sleep debt that is driving your score.",
                "Take no caffeine after 2 pm for the next week.",
                6, 0.85);
        add("mealsSkipped", RecommendationCategory.NUTRITION,
                "Anchor one non-negotiable meal",
                "Skipped meals destabilise blood glucose and amplify the perception of stress. One protected meal restores "
                        + "the metabolic baseline recovery depends on.",
                "Schedule breakfast as a calendar event for the next five days.",
                6, 0.7);
        add("attendanceRatio", RecommendationCategory.ACADEMIC,
                "Re-anchor with attendance",
                "Attendance is usually the last visible signal to fall and the hardest to recover. Rebuilding it restores "
                        + "both academic footing and daily structure.",
                "Commit to attending every scheduled class for the next three days.",
                9, 0.76);
        add("moodValence", RecommendationCategory.STRESS,
                "Track the mood dip precisely",
                "Persistently low mood carries real weight in your model. Locating exactly when the dip occurs turns a vague "
                        + "feeling into something you can act on.",
                "Log your mood three times tomorrow — morning, afternoon and night.",
                6, 0.68);
    }

    private void add(String feature, RecommendationCategory category, String title,
                     String detail, String action, double impact, double evidence) {
        byFeature.computeIfAbsent(feature, key -> new ArrayList<>())
                .add(new Intervention(feature, category, title, detail, action, impact, evidence));
    }

    /**
     * Generates a personalised plan.
     *
     * @param studentId    owner of the plan
     * @param drivers      ranked explanation of the current score
     * @param level        the student's current risk band
     * @param peerBoosts   feature keys that helped similar students, from
     *                     {@link #collaborativeBoosts}
     */
    public List<Recommendation> generate(long studentId,
                                         List<RiskDriver> drivers,
                                         RiskLevel level,
                                         Map<String, Double> peerBoosts,
                                         int limit) {
        List<Recommendation> plan = new ArrayList<>();
        int priority = 1;

        for (RiskDriver driver : drivers) {
            if (!driver.isAggravating() || plan.size() >= limit) {
                continue;
            }
            List<Intervention> candidates = byFeature.get(driver.feature());
            if (candidates == null || candidates.isEmpty()) {
                continue;
            }
            Intervention intervention = candidates.get(0);

            double severityScale = switch (level) {
                case CRITICAL -> 1.35;
                case HIGH -> 1.2;
                case ELEVATED -> 1.0;
                default -> 0.8;
            };
            double peerBoost = 1.0 + peerBoosts.getOrDefault(driver.feature(), 0.0);
            double impact = Numbers.round(
                    Numbers.clamp(intervention.baseImpact() * severityScale * peerBoost
                            * (0.6 + driver.magnitude()), 2, 22), 1);

            Recommendation recommendation = new Recommendation(
                    studentId,
                    intervention.category(),
                    intervention.title(),
                    intervention.detail(),
                    intervention.actionStep(),
                    priority++,
                    impact);
            recommendation.setEvidenceStrength(Numbers.round(
                    Numbers.clamp(intervention.evidence() * peerBoost, 0, 1), 2));
            plan.add(recommendation);
        }

        if (plan.isEmpty()) {
            Recommendation maintain = new Recommendation(studentId, RecommendationCategory.STRESS,
                    "Keep your current rhythm",
                    "No behaviour is currently pushing your risk upward. The most valuable thing you can do is protect "
                            + "the routine that produced this result.",
                    "Keep logging daily — consistency is what makes early detection possible.",
                    1, 0);
            maintain.setEvidenceStrength(0.9);
            plan.add(maintain);
        }
        return plan;
    }

    /**
     * Collaborative filtering step.
     *
     * <p>Finds the students whose aggregated behaviour is most similar to this
     * one (cosine similarity) and returns a small boost for each feature on
     * which those peers are doing measurably better. In effect: "students who
     * looked like you got the most out of fixing this."</p>
     */
    public Map<String, Double> collaborativeBoosts(double[] target,
                                                   Map<Long, double[]> peers,
                                                   Map<Long, Double> peerRisk,
                                                   int neighbours) {
        Map<String, Double> boosts = new LinkedHashMap<>();
        if (peers.size() < 3) {
            return boosts;
        }

        List<Map.Entry<Long, Double>> ranked = new ArrayList<>();
        for (Map.Entry<Long, double[]> entry : peers.entrySet()) {
            ranked.add(Map.entry(entry.getKey(), cosineSimilarity(target, entry.getValue())));
        }
        ranked.sort(Comparator.comparingDouble((Map.Entry<Long, Double> e) -> e.getValue()).reversed());

        List<Long> nearest = ranked.stream()
                .limit(Math.min(neighbours, ranked.size()))
                .map(Map.Entry::getKey)
                .toList();

        List<Long> healthierNeighbours = nearest.stream()
                .filter(id -> peerRisk.getOrDefault(id, 100.0) < 40)
                .toList();
        if (healthierNeighbours.isEmpty()) {
            return boosts;
        }

        String[] names = BehaviorLog.FEATURE_NAMES;
        for (int f = 0; f < names.length; f++) {
            double peerAverage = 0;
            for (long id : healthierNeighbours) {
                peerAverage += peers.get(id)[f];
            }
            peerAverage /= healthierNeighbours.size();

            double difference = Math.abs(peerAverage - target[f]);
            double scale = Math.max(1e-6, Math.abs(peerAverage) + Math.abs(target[f]));
            double relative = difference / scale;
            if (relative > 0.18) {
                boosts.put(names[f], Numbers.round(Numbers.clamp(relative * 0.5, 0, 0.35), 3));
            }
        }
        return boosts;
    }

    private static double cosineSimilarity(double[] left, double[] right) {
        double dot = 0;
        double leftNorm = 0;
        double rightNorm = 0;
        for (int i = 0; i < left.length && i < right.length; i++) {
            dot += left[i] * right[i];
            leftNorm += left[i] * left[i];
            rightNorm += right[i] * right[i];
        }
        double denominator = Math.sqrt(leftNorm) * Math.sqrt(rightNorm);
        return denominator == 0 ? 0 : dot / denominator;
    }

    public int knowledgeBaseSize() {
        return byFeature.values().stream().mapToInt(List::size).sum();
    }
}
