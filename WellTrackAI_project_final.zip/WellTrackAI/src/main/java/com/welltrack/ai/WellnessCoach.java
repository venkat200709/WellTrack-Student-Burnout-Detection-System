package com.welltrack.ai;

import com.welltrack.ai.nlp.NaiveBayesIntentClassifier;
import com.welltrack.ai.nlp.SentimentAnalyzer;
import com.welltrack.ai.nlp.TfIdfIndex;
import com.welltrack.core.json.JsonArray;
import com.welltrack.core.json.JsonObject;
import com.welltrack.core.util.Log;
import com.welltrack.core.util.Numbers;
import com.welltrack.model.BehaviorLog;
import com.welltrack.model.RiskDriver;
import com.welltrack.model.RiskScore;
import com.welltrack.model.Student;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

/**
 * The conversational AI wellness coach.
 *
 * <p>This is a full retrieval-augmented generation pipeline built entirely in
 * Java, with no external model or API required:</p>
 * <ol>
 *   <li><b>Understand</b> — a {@link NaiveBayesIntentClassifier} trained on a
 *       curated intent corpus determines what the student is asking.</li>
 *   <li><b>Feel</b> — a {@link SentimentAnalyzer} measures polarity, intensity
 *       and the dominant emotion, and screens for crisis language.</li>
 *   <li><b>Retrieve</b> — a {@link TfIdfIndex} over the wellness
 *       {@link KnowledgeBase} finds the most relevant evidence-based
 *       material.</li>
 *   <li><b>Ground</b> — the student's <em>own</em> live data (risk score, top
 *       drivers, latest check-in) is injected, which is what separates this
 *       from a generic chatbot: the answer cites their actual sleep, their
 *       actual trend, their actual cohort.</li>
 *   <li><b>Compose</b> — a response is assembled from the intent template, the
 *       retrieved passage and the personal context.</li>
 * </ol>
 *
 * <p>When an external language model is configured, {@link LlmClient} is used
 * for the final composition step with exactly the same grounded context; if it
 * is unavailable the local composer answers instead, so the coach never fails.</p>
 */
public final class WellnessCoach {

    private final NaiveBayesIntentClassifier intents = new NaiveBayesIntentClassifier();
    private final SentimentAnalyzer sentiment = new SentimentAnalyzer();
    private final TfIdfIndex knowledge = KnowledgeBase.build();
    private final LlmClient llmClient;

    /** The coach's answer plus everything that produced it. */
    public record CoachReply(String message,
                             String intent,
                             double intentConfidence,
                             SentimentAnalyzer.SentimentReport sentiment,
                             List<String> sources,
                             List<String> suggestedReplies,
                             boolean escalate,
                             String generator) {

        public JsonObject toJson() {
            JsonArray sourceArray = new JsonArray();
            sources.forEach(sourceArray::add);
            JsonArray suggestionArray = new JsonArray();
            suggestedReplies.forEach(suggestionArray::add);
            return JsonObject.of()
                    .set("message", message)
                    .set("intent", intent)
                    .set("intentConfidence", Numbers.round(intentConfidence, 3))
                    .set("sentiment", sentiment.toJson())
                    .set("sources", sourceArray)
                    .set("suggestedReplies", suggestionArray)
                    .set("escalate", escalate)
                    .set("generator", generator);
        }
    }

    public WellnessCoach(LlmClient llmClient) {
        this.llmClient = llmClient;
        trainIntents();
        Log.success("WellnessCoach", "Coach ready — %d intents, %d knowledge articles, %d vocabulary terms"
                .formatted(intents.trainedIntents(), knowledge.size(), intents.vocabularySize()));
    }

    private void trainIntents() {
        intents.trainAll("sleep",
                "i cannot sleep at night", "my sleep schedule is broken", "i keep waking up tired",
                "how many hours should i sleep", "i only slept four hours", "insomnia is killing me",
                "i sleep late every day", "how do i fix my sleep");

        intents.trainAll("stress",
                "i feel so stressed", "everything is overwhelming me", "i am panicking about everything",
                "how do i calm down", "my anxiety is very high", "i feel tense all the time",
                "i cannot relax at all");

        intents.trainAll("study",
                "i cannot focus while studying", "how should i study better", "i keep procrastinating",
                "i study for hours with no result", "how do i concentrate", "my productivity is terrible",
                "i waste time before studying");

        intents.trainAll("exam",
                "exams are next week", "i am scared about my exam", "how do i prepare for exams",
                "semester exams are close", "i have not started revision", "internal assessment stress");

        intents.trainAll("score",
                "why is my score high", "what does my burnout score mean", "explain my risk",
                "how is this calculated", "why am i flagged", "what is driving my score",
                "show my risk factors");

        intents.trainAll("motivation",
                "i have no motivation", "i do not want to do anything", "nothing feels worth it",
                "i lost interest in my subjects", "i feel like giving up on studying",
                "why should i even try");

        intents.trainAll("social",
                "i feel lonely", "i have no friends here", "i stopped talking to people",
                "i feel isolated in my hostel", "nobody understands me", "i spend all day alone");

        intents.trainAll("health",
                "i keep skipping meals", "i drink too much coffee", "i have headaches every day",
                "i stopped exercising", "i feel physically drained", "my body feels heavy");

        intents.trainAll("progress",
                "am i improving", "how was my week", "what is my trend", "did i get better",
                "show my progress", "how am i doing overall");

        intents.trainAll("greeting",
                "hi", "hello", "hey there", "good morning", "good evening", "hi coach", "hello welltrack");

        intents.trainAll("help",
                "what can you do", "how do you help me", "what is welltrack", "who are you",
                "how does this app work", "what features do you have");
    }

    /**
     * Produces a reply grounded in the student's live data.
     *
     * @param student   the person asking
     * @param message   their message
     * @param riskScore their latest computed score, if any
     * @param latestLog their most recent check-in, if any
     */
    public CoachReply respond(Student student, String message,
                              Optional<RiskScore> riskScore, Optional<BehaviorLog> latestLog) {

        NaiveBayesIntentClassifier.Prediction prediction = intents.classify(message);
        SentimentAnalyzer.SentimentReport mood = sentiment.analyse(message);
        List<TfIdfIndex.Hit> hits = knowledge.search(message, 2);

        boolean escalate = mood.crisisMarkerDetected()
                || (mood.polarity() < -0.7 && "hopelessness".equals(mood.dominantEmotion()));

        String context = buildGroundingContext(student, riskScore, latestLog);
        String localAnswer = compose(student, prediction, mood, hits, riskScore, latestLog, escalate);

        String finalMessage = localAnswer;
        String generator = "welltrack-local-nlp";
        if (llmClient != null && llmClient.isEnabled() && !escalate) {
            Optional<String> enhanced = llmClient.enhance(message, context, localAnswer);
            if (enhanced.isPresent()) {
                finalMessage = enhanced.get();
                generator = llmClient.modelName();
            }
        }

        List<String> sources = new ArrayList<>();
        for (TfIdfIndex.Hit hit : hits) {
            sources.add(hit.document().title());
        }

        return new CoachReply(finalMessage, prediction.intent(), prediction.confidence(),
                mood, sources, suggestions(prediction.intent()), escalate, generator);
    }

    private String buildGroundingContext(Student student, Optional<RiskScore> riskScore,
                                         Optional<BehaviorLog> latestLog) {
        StringBuilder context = new StringBuilder();
        context.append("Student: ").append(student.getFullName())
                .append(" (").append(student.getDepartment()).append(", year ")
                .append(student.getYearOfStudy()).append("). ");
        riskScore.ifPresent(score -> {
            context.append("Current burnout score ").append(Math.round(score.getScore()))
                    .append("/100 (").append(score.getLevel().label()).append("), trend ")
                    .append(score.getTrend().label()).append(". ");
            List<RiskDriver> top = score.topAggravators(3);
            if (!top.isEmpty()) {
                context.append("Main drivers: ");
                for (RiskDriver driver : top) {
                    context.append(driver.label()).append("; ");
                }
            }
        });
        latestLog.ifPresent(log -> context.append("Last check-in: ")
                .append(String.format("%.1f h sleep, %.1f h study, stress %d/10, mood %s.",
                        log.getSleepHours(), log.getStudyHours(), log.getStressLevel(),
                        log.getMood().label())));
        return context.toString();
    }

    private String compose(Student student,
                           NaiveBayesIntentClassifier.Prediction prediction,
                           SentimentAnalyzer.SentimentReport mood,
                           List<TfIdfIndex.Hit> hits,
                           Optional<RiskScore> riskScore,
                           Optional<BehaviorLog> latestLog,
                           boolean escalate) {

        if (escalate) {
            return "I want to pause on everything else for a moment. What you have written sounds genuinely heavy, "
                    + "and it is not something you should be carrying by yourself.\n\n"
                    + "Please reach out today to someone who can be with you — your faculty mentor "
                    + "Dr. Vignesh, the student welfare office, or a family member you trust. "
                    + "If you feel unsafe at any point, contact your local emergency number or a crisis helpline "
                    + "immediately.\n\n"
                    + "I will keep tracking your wellness data, but a person is what matters right now. "
                    + "Would you like me to flag this to your mentor so they can check in with you?";
        }

        String firstName = student.getFullName() == null
                ? "there" : student.getFullName().split("\\s+")[0];
        StringBuilder reply = new StringBuilder();

        // 1. Acknowledge, calibrated to what they actually expressed.
        reply.append(openingFor(prediction.intent(), firstName, mood));

        // 2. Ground the answer in their own data.
        String personal = personalise(prediction.intent(), riskScore, latestLog);
        if (!personal.isBlank()) {
            reply.append("\n\n").append(personal);
        }

        // 3. Bring in the retrieved evidence.
        if (!hits.isEmpty() && hits.get(0).score() > 0.06) {
            reply.append("\n\n").append(condense(hits.get(0).document().body()));
        }

        // 4. Close with one concrete next step.
        reply.append("\n\n").append(nextStepFor(prediction.intent(), riskScore));
        return reply.toString();
    }

    private String openingFor(String intent, String firstName,
                              SentimentAnalyzer.SentimentReport mood) {
        boolean negative = mood.polarity() < -0.2;
        return switch (intent) {
            case "greeting" -> "Hello " + firstName + " — good to see you. How has your week been treating you?";
            case "help" -> "I am your WellTrack coach, " + firstName
                    + ". I read your daily check-ins, explain what is driving your burnout score, "
                    + "and suggest small changes that actually move it.";
            case "sleep" -> negative
                    ? "Sleep being disrupted is genuinely exhausting, and it is also the lever with the most leverage in your data."
                    : "Sleep is the single strongest signal in your profile, so this is a good thing to be thinking about.";
            case "stress" -> "That sounds like a lot to hold at once. Let us take it apart rather than face it as one block.";
            case "study" -> "Difficulty focusing is usually a capacity problem rather than a discipline problem.";
            case "exam" -> "Exam pressure peaks in anticipation — which is precisely where it can be reduced.";
            case "score" -> "Good question. Your score is never a black box, so let me show you exactly what is behind it.";
            case "motivation" -> "Losing motivation is one of the clearest early markers of burnout, and it is not a character flaw.";
            case "social" -> "Feeling isolated is hard, and withdrawal tends to reinforce itself, so naming it is a real step.";
            case "health" -> "The physical side matters more than most students expect — it sets the floor for everything else.";
            case "progress" -> "Let me pull up how your week actually looks.";
            default -> negative
                    ? "Thank you for telling me. Let me look at your data alongside what you have described."
                    : "Let me look at that together with what your check-ins are showing.";
        };
    }

    private String personalise(String intent, Optional<RiskScore> riskScore,
                               Optional<BehaviorLog> latestLog) {
        StringBuilder personal = new StringBuilder();

        if (riskScore.isPresent()) {
            RiskScore score = riskScore.get();
            if ("score".equals(intent) || "progress".equals(intent)) {
                personal.append("Your current score is ").append(Math.round(score.getScore()))
                        .append("/100 — ").append(score.getLevel().label().toLowerCase())
                        .append(", trending ").append(score.getTrend().label().toLowerCase()).append(". ");
                List<RiskDriver> drivers = score.topAggravators(2);
                for (RiskDriver driver : drivers) {
                    personal.append(driver.explanation()).append(" ");
                }
            } else {
                List<RiskDriver> drivers = score.topAggravators(1);
                if (!drivers.isEmpty()) {
                    personal.append("From your recent check-ins: ")
                            .append(drivers.get(0).explanation()).append(" ");
                }
            }
        }

        latestLog.ifPresent(log -> {
            if ("sleep".equals(intent)) {
                personal.append(String.format(
                        "Your last logged night was %.1f hours, and your stress that day was %d out of 10.",
                        log.getSleepHours(), log.getStressLevel()));
            } else if ("study".equals(intent)) {
                personal.append(String.format(
                        "You logged %.1f hours of study against %.1f hours of screen time on your last check-in.",
                        log.getStudyHours(), log.getScreenTimeHours()));
            } else if ("health".equals(intent)) {
                personal.append(String.format(
                        "Your last check-in recorded %d minutes of movement and %d cup(s) of caffeine.",
                        log.getExerciseMinutes(), log.getCaffeineCups()));
            }
        });

        return personal.toString().trim();
    }

    private String condense(String body) {
        String[] sentences = body.split("(?<=\\.)\\s+");
        StringBuilder condensed = new StringBuilder();
        for (int i = 0; i < Math.min(2, sentences.length); i++) {
            condensed.append(sentences[i]).append(i == 0 ? " " : "");
        }
        return condensed.toString().trim();
    }

    private String nextStepFor(String intent, Optional<RiskScore> riskScore) {
        boolean urgent = riskScore.map(score -> score.getLevel().requiresIntervention()).orElse(false);
        String base = switch (intent) {
            case "sleep" -> "One step for tonight: set a fixed lights-out time and hold it for five nights.";
            case "stress" -> "One step for right now: four seconds in, six seconds out, for three minutes.";
            case "study" -> "One step for today: a single 50-minute focus block, phone in another room.";
            case "exam" -> "One step for today: write every deadline down with its date, then pick only the nearest two.";
            case "score" -> "One step: open the Insights panel — every driver there is ranked by how much it moves your score.";
            case "motivation" -> "One step: do a two-minute version of the task you are avoiding. Motivation usually follows.";
            case "social" -> "One step: message one person today and arrange to meet this week.";
            case "health" -> "One step: a 20-minute walk today, and no caffeine after 2 pm.";
            case "progress" -> "One step: keep your check-in streak alive — consistency is what makes the forecast accurate.";
            case "greeting", "help" -> "Try asking me \"why is my score high?\" or \"how do I fix my sleep?\"";
            default -> "One step: log today's check-in so I can give you a sharper answer tomorrow.";
        };
        if (urgent) {
            base += "\n\nYour score is currently in the intervention band, so it is also worth speaking to your "
                    + "faculty mentor this week — that is what they are there for.";
        }
        return base;
    }

    private List<String> suggestions(String intent) {
        return switch (intent) {
            case "sleep" -> List.of("Why does sleep affect my score so much?", "How do I fix a broken schedule?",
                    "Show my sleep trend");
            case "stress", "exam" -> List.of("Give me a 3-minute exercise", "How do I plan my revision?",
                    "What is driving my stress?");
            case "score", "progress" -> List.of("What is my forecast?", "Which habit should I fix first?",
                    "How is my cohort doing?");
            case "motivation", "social" -> List.of("How do I start again?", "Should I talk to my mentor?",
                    "What helped students like me?");
            default -> List.of("Why is my score high?", "How do I sleep better?", "What is my forecast?");
        };
    }

    public JsonObject describe() {
        return JsonObject.of()
                .set("intentClassifier", intents.toJson())
                .set("knowledgeArticles", knowledge.size())
                .set("llmEnabled", llmClient != null && llmClient.isEnabled())
                .set("llmModel", llmClient == null ? "disabled" : llmClient.modelName());
    }
}
