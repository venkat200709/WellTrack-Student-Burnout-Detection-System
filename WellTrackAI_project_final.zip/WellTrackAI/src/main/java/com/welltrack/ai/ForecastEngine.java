package com.welltrack.ai;

import com.welltrack.ai.engine.HoltLinearForecaster;
import com.welltrack.core.json.JsonArray;
import com.welltrack.core.json.JsonObject;
import com.welltrack.core.json.JsonSerializable;
import com.welltrack.core.util.Numbers;
import com.welltrack.model.enums.RiskLevel;
import com.welltrack.model.enums.TrendDirection;

/**
 * Turns a student's score history into a forward-looking projection.
 *
 * <p>This is the feature that makes WellTrack <em>preventive</em> rather than
 * merely descriptive. A dashboard that says "your risk is 58 today" is a
 * report; one that says "on your current trajectory you cross the high-risk
 * line in four days" is an intervention.</p>
 *
 * <p>The projection comes from {@link HoltLinearForecaster}. On top of the raw
 * numbers this engine derives the three things a human actually acts on: the
 * direction of travel, the size of the expected change, and the number of days
 * until a threshold is breached.</p>
 */
public final class ForecastEngine {

    private static final int HORIZON = 7;

    /** The complete forecast for one student. */
    public record Forecast(double[] projection,
                           double[] lowerBound,
                           double[] upperBound,
                           TrendDirection direction,
                           double projectedChange,
                           double confidence,
                           int daysUntilHighRisk,
                           String narrative) implements JsonSerializable {

        public double endPoint() {
            return projection.length == 0 ? 0 : projection[projection.length - 1];
        }

        @Override
        public JsonObject toJson() {
            JsonArray central = new JsonArray();
            JsonArray lower = new JsonArray();
            JsonArray upper = new JsonArray();
            for (int i = 0; i < projection.length; i++) {
                central.add(Numbers.round(projection[i], 1));
                lower.add(Numbers.round(lowerBound[i], 1));
                upper.add(Numbers.round(upperBound[i], 1));
            }
            return JsonObject.of()
                    .set("horizonDays", projection.length)
                    .set("projection", central)
                    .set("lowerBound", lower)
                    .set("upperBound", upper)
                    .set("direction", direction.name())
                    .set("directionLabel", direction.label())
                    .set("projectedChange", Numbers.round(projectedChange, 1))
                    .set("confidence", Numbers.round(confidence, 3))
                    .set("daysUntilHighRisk", daysUntilHighRisk)
                    .set("endPoint", Numbers.round(endPoint(), 1))
                    .set("narrative", narrative);
        }
    }

    /**
     * Projects the next week of burnout risk.
     *
     * @param history chronological risk scores, oldest first
     */
    public Forecast project(double[] history) {
        if (history == null || history.length == 0) {
            return new Forecast(new double[HORIZON], new double[HORIZON], new double[HORIZON],
                    TrendDirection.STABLE, 0, 0, -1,
                    "Log a few more days of check-ins and WellTrack will start projecting your week ahead.");
        }

        HoltLinearForecaster forecaster = new HoltLinearForecaster();
        forecaster.fit(history);

        double[] projection = forecaster.forecast(HORIZON, 0, 100);
        double[][] interval = forecaster.predictionInterval(HORIZON, 0, 100);
        double current = history[history.length - 1];
        double change = projection[HORIZON - 1] - current;

        // A rising risk score is a deterioration, so the sign is inverted
        // relative to the usual "up is good" reading of a trend.
        TrendDirection direction = TrendDirection.fromSlope(forecaster.trend(), 0.35);

        // Only meaningful while the student is still below the threshold.
        int daysUntilHighRisk = -1;
        if (current < RiskLevel.HIGH.lowerBound()) {
            for (int day = 0; day < projection.length; day++) {
                if (projection[day] >= RiskLevel.HIGH.lowerBound()) {
                    daysUntilHighRisk = day + 1;
                    break;
                }
            }
        }

        return new Forecast(projection, interval[0], interval[1], direction,
                change, forecaster.confidence(), daysUntilHighRisk,
                narrate(current, projection[HORIZON - 1], change, direction, daysUntilHighRisk));
    }

    private String narrate(double current, double projected, double change,
                           TrendDirection direction, int daysUntilHighRisk) {
        String magnitude = "%.0f point%s".formatted(Math.abs(change), Math.abs(change) < 1.5 ? "" : "s");

        if (daysUntilHighRisk > 0 && current < RiskLevel.HIGH.lowerBound()) {
            return "On your current trajectory you would cross into the high-risk band in about "
                    + daysUntilHighRisk + " day" + (daysUntilHighRisk == 1 ? "" : "s")
                    + ". Acting this week is far easier than recovering later.";
        }
        return switch (direction) {
            case WORSENING -> "Your risk is drifting upward by roughly " + magnitude
                    + " over the coming week. Small corrections now will change that curve.";
            case IMPROVING -> "Your risk is projected to fall by about " + magnitude
                    + " over the next week — whatever you changed recently is working, so keep it.";
            case STABLE -> "Your risk is projected to hold steady near "
                    + Math.round(projected) + " over the next week.";
        };
    }
}
