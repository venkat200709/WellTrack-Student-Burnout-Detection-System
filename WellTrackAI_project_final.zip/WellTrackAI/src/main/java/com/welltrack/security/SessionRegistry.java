package com.welltrack.security;

import com.welltrack.core.json.JsonArray;
import com.welltrack.core.json.JsonObject;

import java.time.Duration;
import java.time.LocalDateTime;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Tracks live sessions so that administrators can see who is signed in and so
 * that a token can be revoked before it naturally expires.
 *
 * <p>Stateless JWTs alone cannot be revoked; pairing them with this small
 * server-side registry gives the best of both worlds — cheap verification with
 * the ability to sign a user out immediately.</p>
 */
public final class SessionRegistry {

    private final Map<String, SessionInfo> sessions = new ConcurrentHashMap<>();

    public void register(String tokenId, long userId, String username, String role, String ip) {
        sessions.put(tokenId, new SessionInfo(userId, username, role, ip, LocalDateTime.now()));
    }

    public boolean isRevoked(String tokenId) {
        return tokenId != null && !sessions.containsKey(tokenId);
    }

    public void revoke(String tokenId) {
        sessions.remove(tokenId);
    }

    public int revokeAllForUser(long userId) {
        int removed = 0;
        for (Map.Entry<String, SessionInfo> entry : sessions.entrySet()) {
            if (entry.getValue().userId() == userId) {
                sessions.remove(entry.getKey());
                removed++;
            }
        }
        return removed;
    }

    public void touch(String tokenId) {
        SessionInfo info = sessions.get(tokenId);
        if (info != null) {
            info.touch();
        }
    }

    /** Removes sessions that have been idle beyond the given window. */
    public int purgeIdle(Duration maxIdle) {
        int removed = 0;
        LocalDateTime cutoff = LocalDateTime.now().minus(maxIdle);
        for (Map.Entry<String, SessionInfo> entry : sessions.entrySet()) {
            if (entry.getValue().lastSeen().isBefore(cutoff)) {
                sessions.remove(entry.getKey());
                removed++;
            }
        }
        return removed;
    }

    public int activeCount() {
        return sessions.size();
    }

    public JsonArray describeAll() {
        JsonArray array = new JsonArray();
        sessions.forEach((id, info) -> array.add(JsonObject.of()
                .set("sessionId", id)
                .set("userId", info.userId())
                .set("username", info.username())
                .set("role", info.role())
                .set("ipAddress", info.ip())
                .set("startedAt", info.startedAt().toString())
                .set("lastSeen", info.lastSeen().toString())));
        return array;
    }

    /** Mutable session record; {@code lastSeen} is refreshed on every request. */
    private static final class SessionInfo {

        private final long userId;
        private final String username;
        private final String role;
        private final String ip;
        private final LocalDateTime startedAt;
        private volatile LocalDateTime lastSeen;

        private SessionInfo(long userId, String username, String role, String ip, LocalDateTime startedAt) {
            this.userId = userId;
            this.username = username;
            this.role = role;
            this.ip = ip;
            this.startedAt = startedAt;
            this.lastSeen = startedAt;
        }

        private long userId() {
            return userId;
        }

        private String username() {
            return username;
        }

        private String role() {
            return role;
        }

        private String ip() {
            return ip;
        }

        private LocalDateTime startedAt() {
            return startedAt;
        }

        private LocalDateTime lastSeen() {
            return lastSeen;
        }

        private void touch() {
            this.lastSeen = LocalDateTime.now();
        }
    }
}
