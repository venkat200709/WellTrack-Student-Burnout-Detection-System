package com.welltrack.security;

import java.time.Duration;
import java.time.Instant;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * A thread-safe token-bucket rate limiter.
 *
 * <p>Guards the authentication endpoints against credential-stuffing and
 * brute-force attempts: every caller (identified by IP address) receives a
 * bucket that refills continuously at a fixed rate. Because refilling is
 * computed lazily from elapsed time there is no background timer, and because
 * the buckets live in a {@link ConcurrentHashMap} the limiter scales with the
 * request thread pool.</p>
 */
public final class RateLimiter {

    private final int capacity;
    private final double refillPerSecond;
    private final Map<String, Bucket> buckets = new ConcurrentHashMap<>();

    public RateLimiter(int capacity, Duration refillWindow) {
        this.capacity = capacity;
        this.refillPerSecond = capacity / (double) Math.max(1, refillWindow.toSeconds());
    }

    /** @return true when the caller may proceed; false when the quota is exhausted. */
    public boolean tryAcquire(String key) {
        Bucket bucket = buckets.computeIfAbsent(key, ignored -> new Bucket(capacity));
        return bucket.tryConsume(refillPerSecond, capacity);
    }

    /** @return whole seconds the caller should wait before retrying. */
    public long retryAfterSeconds(String key) {
        Bucket bucket = buckets.get(key);
        if (bucket == null) {
            return 0;
        }
        return bucket.retryAfterSeconds(refillPerSecond);
    }

    public void reset(String key) {
        buckets.remove(key);
    }

    public int trackedClients() {
        return buckets.size();
    }

    /** One caller's bucket. All mutation happens under the instance monitor. */
    private static final class Bucket {

        private double tokens;
        private Instant lastRefill = Instant.now();

        private Bucket(int capacity) {
            this.tokens = capacity;
        }

        private synchronized boolean tryConsume(double refillPerSecond, int capacity) {
            refill(refillPerSecond, capacity);
            if (tokens >= 1) {
                tokens -= 1;
                return true;
            }
            return false;
        }

        private synchronized long retryAfterSeconds(double refillPerSecond) {
            if (tokens >= 1 || refillPerSecond <= 0) {
                return 0;
            }
            return (long) Math.ceil((1 - tokens) / refillPerSecond);
        }

        private void refill(double refillPerSecond, int capacity) {
            Instant now = Instant.now();
            double elapsed = Duration.between(lastRefill, now).toMillis() / 1000.0;
            if (elapsed > 0) {
                tokens = Math.min(capacity, tokens + elapsed * refillPerSecond);
                lastRefill = now;
            }
        }
    }
}
