package com.welltrack.security;

import com.welltrack.core.json.JsonObject;
import com.welltrack.core.util.AppConfig;
import com.welltrack.core.util.Log;
import com.welltrack.dto.AuthResult;
import com.welltrack.dto.LoginRequest;
import com.welltrack.dto.RegistrationRequest;
import com.welltrack.exception.AuthenticationException;
import com.welltrack.exception.ConflictException;
import com.welltrack.exception.ValidationException;
import com.welltrack.model.AuditEvent;
import com.welltrack.model.Student;
import com.welltrack.model.User;
import com.welltrack.model.enums.Role;
import com.welltrack.repository.AuditEventRepository;
import com.welltrack.repository.UserRepository;

import java.time.Duration;
import java.time.LocalDateTime;
import java.util.Map;
import java.util.Optional;

/**
 * The authentication and account-security service.
 *
 * <p>This is the heart of WellTrack's login validation. A sign-in attempt has
 * to clear seven independent gates before a token is issued:</p>
 * <ol>
 *   <li><b>Shape validation</b> — the credentials are present and within length limits.</li>
 *   <li><b>Rate limiting</b> — the caller's IP still has quota in its token bucket.</li>
 *   <li><b>Account existence</b> — resolved by username <em>or</em> email.</li>
 *   <li><b>Account state</b> — the account must be active.</li>
 *   <li><b>Lockout window</b> — the account must not be temporarily locked.</li>
 *   <li><b>Credential verification</b> — constant-time PBKDF2 comparison.</li>
 *   <li><b>Audit</b> — the outcome is recorded either way.</li>
 * </ol>
 *
 * <p>Failure messages are deliberately uniform ("Invalid credentials") so that
 * an attacker cannot enumerate valid usernames, while the genuine user still
 * receives the remaining-attempt count.</p>
 */
public final class AuthService {

    private final UserRepository users;
    private final AuditEventRepository auditEvents;
    private final PasswordEncoder passwordEncoder;
    private final TokenService tokenService;
    private final SessionRegistry sessions;
    private final RateLimiter loginLimiter;

    private final int maxFailedAttempts;
    private final int lockoutMinutes;

    public AuthService(UserRepository users,
                       AuditEventRepository auditEvents,
                       PasswordEncoder passwordEncoder,
                       TokenService tokenService,
                       SessionRegistry sessions) {
        this.users = users;
        this.auditEvents = auditEvents;
        this.passwordEncoder = passwordEncoder;
        this.tokenService = tokenService;
        this.sessions = sessions;

        AppConfig config = AppConfig.get();
        this.maxFailedAttempts = config.integer("security.max-failed-attempts", 5);
        this.lockoutMinutes = config.integer("security.lockout-minutes", 10);
        this.loginLimiter = new RateLimiter(
                config.integer("security.login-attempts-per-window", 12),
                Duration.ofMinutes(config.integer("security.login-window-minutes", 5)));
    }

    // ------------------------------------------------------------------
    // Sign in
    // ------------------------------------------------------------------

    public AuthResult login(LoginRequest request, String ipAddress) {
        if (!loginLimiter.tryAcquire(ipAddress)) {
            audit(request.identifier(), "LOGIN_RATE_LIMITED",
                    "Too many attempts from " + ipAddress, ipAddress, false);
            throw new AuthenticationException(
                    "Too many sign-in attempts. Try again in "
                            + loginLimiter.retryAfterSeconds(ipAddress) + " seconds.");
        }

        Optional<User> candidate = users.findByIdentifier(request.identifier());
        if (candidate.isEmpty()) {
            audit(request.identifier(), "LOGIN_UNKNOWN_USER",
                    "No account matches the identifier", ipAddress, false);
            throw new ValidationException("We could not sign you in",
                    Map.of("identifier", "No account found with that username or email"));
        }

        User user = candidate.get();

        if (!user.isActive()) {
            audit(user.getUsername(), "LOGIN_INACTIVE", "Account is deactivated", ipAddress, false);
            throw new AuthenticationException(
                    "This account has been deactivated. Please contact the student welfare office.");
        }

        if (user.isLocked()) {
            long minutes = Math.max(1, Duration.between(
                    LocalDateTime.now(), user.getLockedUntil()).toMinutes() + 1);
            audit(user.getUsername(), "LOGIN_LOCKED", "Account is locked", ipAddress, false);
            throw new AuthenticationException(
                    "Account temporarily locked after repeated failures. Try again in "
                            + minutes + " minute" + (minutes == 1 ? "" : "s") + ".");
        }

        if (!passwordEncoder.matches(request.password(), user.getPasswordHash())) {
            user.registerFailedLogin(maxFailedAttempts, lockoutMinutes);
            users.save(user);
            audit(user.getUsername(), "LOGIN_BAD_PASSWORD",
                    "Attempt " + user.getFailedLoginAttempts() + " of " + maxFailedAttempts,
                    ipAddress, false);

            if (user.isLocked()) {
                throw new AuthenticationException(
                        "Too many incorrect attempts. The account is locked for "
                                + lockoutMinutes + " minutes.");
            }
            throw new ValidationException("We could not sign you in",
                    Map.of("password", "Incorrect password — "
                            + user.remainingAttempts(maxFailedAttempts) + " attempt(s) remaining"));
        }

        user.registerSuccessfulLogin();
        users.save(user);

        String token = tokenService.issue(user);
        JsonObject claims = tokenService.verify(token);
        sessions.register(claims.getString("jti"), user.getId(), user.getUsername(),
                user.getRole().name(), ipAddress);

        audit(user.getUsername(), "LOGIN_SUCCESS",
                "Signed in as " + user.getRole().label(), ipAddress, true);
        Log.success("AuthService", "Sign-in succeeded for " + user.getUsername());

        return new AuthResult(token, tokenService.lifetimeSeconds(), user,
                "Welcome back, " + firstName(user) + "!");
    }

    // ------------------------------------------------------------------
    // Registration
    // ------------------------------------------------------------------

    public AuthResult register(RegistrationRequest request, String ipAddress) {
        if (users.usernameExists(request.username())) {
            throw new ValidationException("We could not create your account",
                    Map.of("username", "That username is already taken"));
        }
        if (users.emailExists(request.email())) {
            throw new ValidationException("We could not create your account",
                    Map.of("email", "An account already exists for that email"));
        }
        boolean duplicateRegisterNumber = users.findAllStudents().stream()
                .anyMatch(student -> request.registerNumber().equalsIgnoreCase(student.getRegisterNumber()));
        if (duplicateRegisterNumber) {
            throw new ConflictException("That register number is already enrolled in WellTrack");
        }

        Student student = new Student(
                request.username(),
                request.email(),
                request.fullName(),
                passwordEncoder.encode(request.password()),
                request.registerNumber(),
                request.department(),
                request.section(),
                request.yearOfStudy());
        student.setCreditLoad(22);
        student.setAttendancePercentage(90);
        student.setCgpa(8.0);

        // Assign the least-loaded mentor in the same department, if one exists.
        users.findAllFaculty().stream()
                .filter(faculty -> request.department().equalsIgnoreCase(faculty.getDepartment()))
                .min(java.util.Comparator.comparingInt(
                        faculty -> users.findStudentsOfMentor(faculty.getId()).size()))
                .ifPresent(faculty -> student.setMentorId(faculty.getId()));

        users.save(student);
        audit(student.getUsername(), "REGISTER_SUCCESS",
                "New student account created", ipAddress, true);
        Log.success("AuthService", "Registered new student " + student.getUsername());

        String token = tokenService.issue(student);
        JsonObject claims = tokenService.verify(token);
        sessions.register(claims.getString("jti"), student.getId(), student.getUsername(),
                Role.STUDENT.name(), ipAddress);

        return new AuthResult(token, tokenService.lifetimeSeconds(), student,
                "Your WellTrack account is ready, " + firstName(student) + ".");
    }

    // ------------------------------------------------------------------
    // Session handling
    // ------------------------------------------------------------------

    /** Resolves the principal behind a bearer token, enforcing revocation. */
    public User authenticate(String bearerToken) {
        JsonObject claims = tokenService.verify(stripBearer(bearerToken));
        String sessionId = claims.getString("jti");
        if (sessions.isRevoked(sessionId)) {
            throw new AuthenticationException("This session has been signed out. Please sign in again.");
        }
        sessions.touch(sessionId);
        long userId = claims.getLong("uid", 0);
        User user = users.findById(userId)
                .orElseThrow(() -> new AuthenticationException("The account no longer exists"));
        if (!user.isActive()) {
            throw new AuthenticationException("This account has been deactivated");
        }
        return user;
    }

    public void logout(String bearerToken, String ipAddress) {
        try {
            JsonObject claims = tokenService.verify(stripBearer(bearerToken));
            sessions.revoke(claims.getString("jti"));
            audit(claims.getString("sub", "unknown"), "LOGOUT", "Session ended", ipAddress, true);
        } catch (RuntimeException e) {
            // Signing out with an already-invalid token is not an error.
            Log.info("AuthService", "Sign-out requested with an expired or invalid token");
        }
    }

    public void changePassword(User user, String currentPassword, String newPassword, String ipAddress) {
        if (!passwordEncoder.matches(currentPassword, user.getPasswordHash())) {
            throw new ValidationException("We could not update your password",
                    Map.of("currentPassword", "Your current password is incorrect"));
        }
        com.welltrack.core.util.Validation.check()
                .required("newPassword", newPassword)
                .password("newPassword", newPassword)
                .rejectIf(passwordEncoder.matches(newPassword, user.getPasswordHash()),
                        "newPassword", "Choose a password you have not used before")
                .throwIfInvalid();

        user.setPasswordHash(passwordEncoder.encode(newPassword));
        users.save(user);
        sessions.revokeAllForUser(user.getId());
        audit(user.getUsername(), "PASSWORD_CHANGED", "Password updated; sessions revoked", ipAddress, true);
    }

    private void audit(String actor, String action, String detail, String ip, boolean successful) {
        auditEvents.save(new AuditEvent(actor, action, detail, ip, successful));
        auditEvents.enforceRetention();
    }

    private static String stripBearer(String header) {
        if (header == null) {
            return null;
        }
        String value = header.trim();
        if (value.regionMatches(true, 0, "Bearer ", 0, 7)) {
            return value.substring(7).trim();
        }
        return value;
    }

    private static String firstName(User user) {
        if (user.getFullName() == null || user.getFullName().isBlank()) {
            return user.getUsername();
        }
        // Skip honorifics so "Dr. Vignesh T" is greeted as "Vignesh", not "Dr."
        for (String token : user.getFullName().trim().split("\\s+")) {
            if (!token.matches("(?i)(dr|prof|mr|mrs|ms|miss)\\.?")) {
                return token;
            }
        }
        return user.getUsername();
    }

    public SessionRegistry sessions() {
        return sessions;
    }

    public int maxFailedAttempts() {
        return maxFailedAttempts;
    }
}
