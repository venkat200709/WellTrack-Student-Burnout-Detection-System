package com.welltrack.security;

import com.welltrack.core.json.Json;
import com.welltrack.core.json.JsonObject;
import com.welltrack.core.util.Log;
import com.welltrack.exception.AuthenticationException;
import com.welltrack.model.User;

import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;
import java.nio.charset.StandardCharsets;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.time.Instant;
import java.util.Base64;

/**
 * Issues and verifies stateless JSON Web Tokens, implemented from the
 * specification using only {@code javax.crypto}.
 *
 * <p>Tokens follow the standard three-part structure
 * {@code header.payload.signature}, are signed with HMAC-SHA256 and carry the
 * registered claims {@code sub}, {@code iat}, {@code exp} and {@code jti} plus
 * the WellTrack claims {@code uid}, {@code role} and {@code name}.</p>
 *
 * <p>Verification recomputes the signature, compares it in constant time, and
 * rejects expired or structurally invalid tokens. The signing secret is read
 * from configuration; when none is supplied a strong random secret is generated
 * for the session, which means a default installation is still secure — it just
 * invalidates tokens on restart.</p>
 */
public final class TokenService {

    private static final String HMAC = "HmacSHA256";
    private static final String HEADER = "{\"alg\":\"HS256\",\"typ\":\"JWT\"}";
    private static final Base64.Encoder ENCODER = Base64.getUrlEncoder().withoutPadding();
    private static final Base64.Decoder DECODER = Base64.getUrlDecoder();

    private final byte[] secret;
    private final long lifetimeSeconds;

    public TokenService(String configuredSecret, long lifetimeSeconds) {
        this.lifetimeSeconds = lifetimeSeconds;
        if (configuredSecret == null || configuredSecret.isBlank() || configuredSecret.length() < 32) {
            byte[] generated = new byte[48];
            new SecureRandom().nextBytes(generated);
            this.secret = generated;
            Log.warn("TokenService",
                    "No strong signing secret configured — generated an ephemeral one for this session");
        } else {
            this.secret = configuredSecret.getBytes(StandardCharsets.UTF_8);
        }
    }

    /** Mints a signed token for the given account. */
    public String issue(User user) {
        Instant now = Instant.now();
        JsonObject payload = JsonObject.of()
                .set("sub", user.getUsername())
                .set("uid", user.getId())
                .set("role", user.getRole().name())
                .set("name", user.getFullName())
                .set("iat", now.getEpochSecond())
                .set("exp", now.plusSeconds(lifetimeSeconds).getEpochSecond())
                .set("jti", com.welltrack.core.util.Ids.shortCode(12));

        String encodedHeader = ENCODER.encodeToString(HEADER.getBytes(StandardCharsets.UTF_8));
        String encodedPayload = ENCODER.encodeToString(Json.write(payload).getBytes(StandardCharsets.UTF_8));
        String signingInput = encodedHeader + "." + encodedPayload;
        return signingInput + "." + ENCODER.encodeToString(sign(signingInput));
    }

    /**
     * Verifies a token and returns its claims.
     *
     * @throws AuthenticationException when the token is malformed, tampered
     *                                 with, or expired
     */
    public JsonObject verify(String token) {
        if (token == null || token.isBlank()) {
            throw new AuthenticationException("Authentication token is missing");
        }
        String[] parts = token.split("\\.");
        if (parts.length != 3) {
            throw new AuthenticationException("Authentication token is malformed");
        }
        String signingInput = parts[0] + "." + parts[1];
        byte[] expected = sign(signingInput);
        byte[] provided;
        try {
            provided = DECODER.decode(parts[2]);
        } catch (IllegalArgumentException e) {
            throw new AuthenticationException("Authentication token signature is not valid Base64");
        }
        if (!constantTimeEquals(expected, provided)) {
            throw new AuthenticationException("Authentication token signature does not match");
        }
        JsonObject claims;
        try {
            claims = Json.parseObject(new String(DECODER.decode(parts[1]), StandardCharsets.UTF_8));
        } catch (RuntimeException e) {
            throw new AuthenticationException("Authentication token payload is unreadable");
        }
        long expiry = claims.getLong("exp", 0);
        if (expiry <= Instant.now().getEpochSecond()) {
            throw new AuthenticationException("Your session has expired — please sign in again");
        }
        return claims;
    }

    /** @return seconds until the token expires, or 0 when already expired. */
    public long remainingSeconds(JsonObject claims) {
        return Math.max(0, claims.getLong("exp", 0) - Instant.now().getEpochSecond());
    }

    public long lifetimeSeconds() {
        return lifetimeSeconds;
    }

    private byte[] sign(String data) {
        try {
            Mac mac = Mac.getInstance(HMAC);
            mac.init(new SecretKeySpec(secret, HMAC));
            return mac.doFinal(data.getBytes(StandardCharsets.UTF_8));
        } catch (NoSuchAlgorithmException | InvalidKeyException e) {
            throw new IllegalStateException("HMAC-SHA256 is unavailable on this JVM", e);
        }
    }

    private static boolean constantTimeEquals(byte[] left, byte[] right) {
        if (left.length != right.length) {
            return false;
        }
        int difference = 0;
        for (int i = 0; i < left.length; i++) {
            difference |= left[i] ^ right[i];
        }
        return difference == 0;
    }
}
