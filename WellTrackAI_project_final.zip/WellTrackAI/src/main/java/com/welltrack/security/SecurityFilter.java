package com.welltrack.security;

import com.welltrack.core.http.Filter;
import com.welltrack.core.http.FilterChain;
import com.welltrack.core.http.HttpRequest;
import com.welltrack.core.http.HttpResponse;
import com.welltrack.core.http.HttpStatus;
import com.welltrack.core.http.Route;
import com.welltrack.core.http.Router;
import com.welltrack.exception.AuthenticationException;
import com.welltrack.exception.AuthorizationException;
import com.welltrack.model.User;
import com.welltrack.model.enums.Role;

import java.util.Optional;
import java.util.Set;

/**
 * The server-side authorisation gate.
 *
 * <p>Runs before every routed handler: it looks up the matching {@link Route},
 * and when that route declares an authentication or role requirement it
 * resolves the bearer token, binds the principal onto the request, and checks
 * the role hierarchy. Controllers therefore never contain security code — they
 * simply call {@code request.requirePrincipal()} and trust it.</p>
 */
public final class SecurityFilter implements Filter {

    private final Router router;
    private final AuthService authService;

    public SecurityFilter(Router router, AuthService authService) {
        this.router = router;
        this.authService = authService;
    }

    @Override
    public HttpResponse apply(HttpRequest request, FilterChain chain) throws Exception {
        if (!request.path().startsWith("/api")) {
            return chain.proceed(request);
        }

        Optional<Route> match = router.resolve(request);
        if (match.isEmpty()) {
            return chain.proceed(request);
        }
        Route route = match.get();

        // Always attempt to resolve the principal so optional endpoints can
        // personalise their response, but only fail closed when required.
        // Browsers cannot attach an Authorization header to a plain download
        // link or an EventSource connection, so a token query parameter is
        // accepted as an equivalent credential on those requests.
        String authorisation = request.header("authorization");
        if (authorisation == null || authorisation.isBlank()) {
            authorisation = request.query("token", null);
        }
        User principal = null;
        AuthenticationException failure = null;
        if (authorisation != null && !authorisation.isBlank()) {
            try {
                principal = authService.authenticate(authorisation);
                request.bindPrincipal(principal);
            } catch (AuthenticationException e) {
                failure = e;
            }
        }

        if (route.authenticated()) {
            if (principal == null) {
                String message = failure != null
                        ? failure.getMessage()
                        : "Sign in to continue";
                return HttpResponse.error(HttpStatus.UNAUTHORIZED, message);
            }
            Set<String> allowed = route.allowedRoles();
            if (!allowed.isEmpty() && !isPermitted(principal.getRole(), allowed)) {
                return HttpResponse.error(HttpStatus.FORBIDDEN,
                        "Your role (" + principal.getRole().label()
                                + ") is not permitted to use this endpoint");
            }
        }
        return chain.proceed(request);
    }

    /**
     * Role check with hierarchy: an administrator satisfies any requirement,
     * a faculty mentor satisfies student-level requirements.
     */
    private boolean isPermitted(Role actual, Set<String> allowed) {
        for (String candidate : allowed) {
            Role required = Role.from(candidate);
            if (actual.satisfies(required)) {
                return true;
            }
        }
        return false;
    }

    /** Guard used inside services when a finer-grained check is needed. */
    public static void requireRole(User user, Role required) {
        if (user == null || !user.getRole().satisfies(required)) {
            throw new AuthorizationException("This action requires the " + required.label() + " role");
        }
    }

    /** Ensures a user may only read or modify their own records. */
    public static void requireSelfOrElevated(User user, long targetStudentId) {
        if (user == null) {
            throw new AuthorizationException("Authentication is required");
        }
        boolean elevated = user.getRole() == Role.FACULTY || user.getRole() == Role.ADMIN;
        if (!elevated && user.getId() != targetStudentId) {
            throw new AuthorizationException("You can only access your own wellness records");
        }
    }
}
