package com.welltrack.security;

/**
 * Strategy for one-way password hashing.
 *
 * <p>Declaring this as an interface keeps the authentication service unaware of
 * the algorithm in use, so the hashing scheme can be upgraded without touching
 * a single line of business logic.</p>
 */
public interface PasswordEncoder {

    /** @return an encoded hash, including any salt and parameters. */
    String encode(String rawPassword);

    /** @return true when the raw password matches the stored hash. */
    boolean matches(String rawPassword, String encodedPassword);

    /** @return a short identifier written into the hash string. */
    String algorithm();
}
