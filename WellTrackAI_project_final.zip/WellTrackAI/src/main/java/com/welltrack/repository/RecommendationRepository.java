package com.welltrack.repository;

import com.welltrack.core.json.JsonObject;
import com.welltrack.model.Recommendation;
import com.welltrack.model.enums.RecommendationCategory;
import com.welltrack.repository.datastore.Datastore;

import java.util.Comparator;
import java.util.List;

/** Persistence for personalised recovery recommendations. */
public class RecommendationRepository extends Repository<Recommendation> {

    public RecommendationRepository(Datastore datastore) {
        super(datastore, "recommendations");
    }

    @Override
    protected JsonObject serialise(Recommendation recommendation) {
        return JsonObject.of()
                .set("id", recommendation.getId())
                .set("studentId", recommendation.getStudentId())
                .set("category", recommendation.getCategory().name())
                .set("title", recommendation.getTitle())
                .set("detail", recommendation.getDetail())
                .set("actionStep", recommendation.getActionStep())
                .set("priority", recommendation.getPriority())
                .set("estimatedRiskReduction", recommendation.getEstimatedRiskReduction())
                .set("evidenceStrength", recommendation.getEvidenceStrength())
                .set("completed", recommendation.isCompleted())
                .setIfPresent("completedAt", text(recommendation.getCompletedAt()))
                .setIfPresent("createdAt", text(recommendation.getCreatedAt()));
    }

    @Override
    protected Recommendation deserialise(JsonObject row) {
        Recommendation recommendation = new Recommendation();
        recommendation.setId(row.getLong("id", 0));
        recommendation.setStudentId(row.getLong("studentId", 0));
        recommendation.setCategory(RecommendationCategory.valueOf(
                row.getString("category", RecommendationCategory.STRESS.name())));
        recommendation.setTitle(row.getString("title", ""));
        recommendation.setDetail(row.getString("detail", ""));
        recommendation.setActionStep(row.getString("actionStep", ""));
        recommendation.setPriority(row.getInt("priority", 3));
        recommendation.setEstimatedRiskReduction(row.getDouble("estimatedRiskReduction", 0));
        recommendation.setEvidenceStrength(row.getDouble("evidenceStrength", 0.5));
        recommendation.setCompleted(row.getBoolean("completed", false));
        recommendation.setCompletedAt(dateTime(row, "completedAt"));
        recommendation.setCreatedAt(dateTime(row, "createdAt"));
        return recommendation;
    }

    public List<Recommendation> findForStudent(long studentId) {
        return findSorted(item -> item.getStudentId() == studentId,
                Comparator.comparingInt(Recommendation::getPriority)
                        .thenComparing(Recommendation::getEstimatedRiskReduction,
                                Comparator.reverseOrder()));
    }

    public List<Recommendation> findActive(long studentId) {
        return findForStudent(studentId).stream().filter(item -> !item.isCompleted()).toList();
    }

    public int clearActive(long studentId) {
        return deleteBy(item -> item.getStudentId() == studentId && !item.isCompleted());
    }

    public long countCompleted(long studentId) {
        return findBy(item -> item.getStudentId() == studentId && item.isCompleted()).size();
    }
}
