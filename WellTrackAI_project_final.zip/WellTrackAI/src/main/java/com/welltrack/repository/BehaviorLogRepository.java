package com.welltrack.repository;

import com.welltrack.core.json.JsonObject;
import com.welltrack.model.BehaviorLog;
import com.welltrack.model.enums.Mood;
import com.welltrack.repository.datastore.Datastore;

import java.time.LocalDate;
import java.util.Comparator;
import java.util.List;
import java.util.Optional;

/** Persistence and time-series queries for daily behavioural entries. */
public class BehaviorLogRepository extends Repository<BehaviorLog> {

    public BehaviorLogRepository(Datastore datastore) {
        super(datastore, "behavior_logs");
    }

    @Override
    protected JsonObject serialise(BehaviorLog log) {
        return JsonObject.of()
                .set("id", log.getId())
                .set("studentId", log.getStudentId())
                .set("logDate", text(log.getLogDate()))
                .set("sleepHours", log.getSleepHours())
                .set("studyHours", log.getStudyHours())
                .set("screenTimeHours", log.getScreenTimeHours())
                .set("exerciseMinutes", log.getExerciseMinutes())
                .set("socialMinutes", log.getSocialMinutes())
                .set("stressLevel", log.getStressLevel())
                .set("mood", log.getMood() == null ? Mood.NEUTRAL.name() : log.getMood().name())
                .set("classesAttended", log.getClassesAttended())
                .set("classesScheduled", log.getClassesScheduled())
                .set("assignmentsPending", log.getAssignmentsPending())
                .set("caffeineCups", log.getCaffeineCups())
                .set("mealsSkipped", log.getMealsSkipped())
                .set("deadlinePressure", log.getDeadlinePressure())
                .set("journalNote", log.getJournalNote())
                .setIfPresent("createdAt", text(log.getCreatedAt()));
    }

    @Override
    protected BehaviorLog deserialise(JsonObject row) {
        BehaviorLog log = new BehaviorLog();
        log.setId(row.getLong("id", 0));
        log.setStudentId(row.getLong("studentId", 0));
        log.setLogDate(date(row, "logDate"));
        log.setSleepHours(row.getDouble("sleepHours", 7));
        log.setStudyHours(row.getDouble("studyHours", 4));
        log.setScreenTimeHours(row.getDouble("screenTimeHours", 4));
        log.setExerciseMinutes(row.getInt("exerciseMinutes", 0));
        log.setSocialMinutes(row.getInt("socialMinutes", 0));
        log.setStressLevel(row.getInt("stressLevel", 5));
        log.setMood(Mood.from(row.getString("mood")));
        log.setClassesAttended(row.getInt("classesAttended", 0));
        log.setClassesScheduled(row.getInt("classesScheduled", 0));
        log.setAssignmentsPending(row.getInt("assignmentsPending", 0));
        log.setCaffeineCups(row.getInt("caffeineCups", 0));
        log.setMealsSkipped(row.getInt("mealsSkipped", 0));
        log.setDeadlinePressure(row.getInt("deadlinePressure", 0));
        log.setJournalNote(row.getString("journalNote", ""));
        log.setCreatedAt(dateTime(row, "createdAt"));
        return log;
    }

    /** @return every entry for a student, oldest first. */
    public List<BehaviorLog> findByStudent(long studentId) {
        return findSorted(log -> log.getStudentId() == studentId,
                Comparator.comparing(BehaviorLog::getLogDate,
                        Comparator.nullsFirst(Comparator.naturalOrder())));
    }

    /** @return the most recent {@code days} entries for a student, oldest first. */
    public List<BehaviorLog> findRecent(long studentId, int days) {
        LocalDate cutoff = LocalDate.now().minusDays(days);
        return findSorted(log -> log.getStudentId() == studentId
                        && log.getLogDate() != null
                        && !log.getLogDate().isBefore(cutoff),
                Comparator.comparing(BehaviorLog::getLogDate));
    }

    public Optional<BehaviorLog> findByStudentAndDate(long studentId, LocalDate date) {
        return findFirst(log -> log.getStudentId() == studentId && date.equals(log.getLogDate()));
    }

    public Optional<BehaviorLog> findLatest(long studentId) {
        return findByStudent(studentId).stream().reduce((first, second) -> second);
    }

    public int deleteForStudent(long studentId) {
        return deleteBy(log -> log.getStudentId() == studentId);
    }
}
