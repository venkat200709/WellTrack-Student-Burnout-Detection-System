package com.welltrack.repository.datastore;

import com.welltrack.core.json.JsonObject;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * A volatile {@link Datastore} that keeps everything in memory.
 *
 * <p>Used by the test suite so repository behaviour can be verified without
 * touching the filesystem, and available as a {@code welltrack.datastore=memory}
 * mode for throw-away demonstrations where nothing should be persisted.</p>
 */
public final class InMemoryDatastore implements Datastore {

    private final Map<String, List<JsonObject>> tables = new ConcurrentHashMap<>();

    @Override
    public List<JsonObject> readAll(String table) {
        return new ArrayList<>(tables.getOrDefault(table, List.of()));
    }

    @Override
    public void writeAll(String table, List<JsonObject> rows) {
        tables.put(table, new ArrayList<>(rows));
    }

    @Override
    public void flush() {
        // Nothing to do — there is no durable medium.
    }

    @Override
    public String describe() {
        return "In-memory datastore (" + tables.size() + " tables, not persisted)";
    }

    @Override
    public void close() {
        tables.clear();
    }
}
