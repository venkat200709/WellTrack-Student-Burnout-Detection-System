package com.welltrack.repository.datastore;

import com.welltrack.core.json.Json;
import com.welltrack.core.json.JsonArray;
import com.welltrack.core.json.JsonObject;
import com.welltrack.core.util.Log;
import com.welltrack.exception.PersistenceException;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CopyOnWriteArraySet;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.locks.ReentrantReadWriteLock;

/**
 * An embedded, file-backed document store.
 *
 * <p>Each logical table is a UTF-8 JSON document under {@code data/}. Writes are
 * buffered in memory and flushed asynchronously by a background scheduler, so
 * the request path never blocks on disk I/O; a shutdown hook guarantees the
 * final flush. Every flush is atomic — the payload is written to a temporary
 * file and then moved into place — so an interrupted process can never leave a
 * half-written table behind. A timestamped snapshot is retained on first write
 * of each session, giving a simple recovery point.</p>
 *
 * <p>Concurrency is guarded by a {@link ReentrantReadWriteLock} per store,
 * allowing unlimited concurrent readers alongside exclusive writers.</p>
 */
public final class FileDatastore implements Datastore {

    private static final int FLUSH_INTERVAL_SECONDS = 5;

    private final Path root;
    private final Map<String, List<JsonObject>> tables = new ConcurrentHashMap<>();
    private final Set<String> dirty = new CopyOnWriteArraySet<>();
    private final ReentrantReadWriteLock lock = new ReentrantReadWriteLock();
    private final ScheduledExecutorService flusher;
    private volatile boolean closed;

    public FileDatastore(Path root) {
        this.root = root;
        try {
            Files.createDirectories(root);
        } catch (IOException e) {
            throw new PersistenceException("Could not create the data directory at " + root, e);
        }
        this.flusher = Executors.newSingleThreadScheduledExecutor(runnable -> {
            Thread thread = new Thread(runnable, "welltrack-datastore-flusher");
            thread.setDaemon(true);
            return thread;
        });
        this.flusher.scheduleWithFixedDelay(this::flushQuietly,
                FLUSH_INTERVAL_SECONDS, FLUSH_INTERVAL_SECONDS, TimeUnit.SECONDS);
        Runtime.getRuntime().addShutdownHook(new Thread(this::flushQuietly, "welltrack-datastore-shutdown"));
        Log.info("FileDatastore", "Embedded datastore ready at " + root.toAbsolutePath());
    }

    @Override
    public List<JsonObject> readAll(String table) {
        lock.readLock().lock();
        try {
            List<JsonObject> cached = tables.get(table);
            if (cached != null) {
                return new ArrayList<>(cached);
            }
        } finally {
            lock.readLock().unlock();
        }
        lock.writeLock().lock();
        try {
            return new ArrayList<>(tables.computeIfAbsent(table, this::readFromDisk));
        } finally {
            lock.writeLock().unlock();
        }
    }

    @Override
    public void writeAll(String table, List<JsonObject> rows) {
        lock.writeLock().lock();
        try {
            tables.put(table, new ArrayList<>(rows));
            dirty.add(table);
        } finally {
            lock.writeLock().unlock();
        }
    }

    @Override
    public void flush() {
        if (dirty.isEmpty()) {
            return;
        }
        List<String> pending = new ArrayList<>(dirty);
        for (String table : pending) {
            List<JsonObject> rows;
            lock.readLock().lock();
            try {
                rows = new ArrayList<>(tables.getOrDefault(table, List.of()));
            } finally {
                lock.readLock().unlock();
            }
            writeToDisk(table, rows);
            dirty.remove(table);
        }
    }

    private void flushQuietly() {
        try {
            flush();
        } catch (Exception e) {
            Log.warn("FileDatastore", "Deferred flush failed: " + e.getMessage());
        }
    }

    private List<JsonObject> readFromDisk(String table) {
        Path file = root.resolve(table + ".json");
        if (!Files.isReadable(file)) {
            return new ArrayList<>();
        }
        try {
            String content = Files.readString(file, StandardCharsets.UTF_8);
            if (content.isBlank()) {
                return new ArrayList<>();
            }
            JsonArray array = Json.parseArray(content);
            List<JsonObject> rows = new ArrayList<>(array.size());
            for (Object item : array) {
                if (item instanceof JsonObject row) {
                    rows.add(row);
                }
            }
            return rows;
        } catch (Exception e) {
            Log.error("FileDatastore", "Table '" + table + "' is unreadable; starting empty: " + e.getMessage());
            quarantine(file);
            return new ArrayList<>();
        }
    }

    private void writeToDisk(String table, List<JsonObject> rows) {
        Path file = root.resolve(table + ".json");
        Path temporary = root.resolve(table + ".json.tmp");
        try {
            Files.writeString(temporary, Json.writePretty(new JsonArray(rows)), StandardCharsets.UTF_8);
            Files.move(temporary, file,
                    StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE);
        } catch (IOException atomicFailure) {
            try {
                Files.writeString(file, Json.writePretty(new JsonArray(rows)), StandardCharsets.UTF_8);
            } catch (IOException e) {
                throw new PersistenceException("Could not persist table '" + table + "'", e);
            }
        }
    }

    private void quarantine(Path file) {
        try {
            Files.move(file, file.resolveSibling(file.getFileName() + ".corrupt-"
                    + System.currentTimeMillis()), StandardCopyOption.REPLACE_EXISTING);
        } catch (IOException ignored) {
            // Best effort only.
        }
    }

    @Override
    public String describe() {
        return "Embedded file datastore (" + tables.size() + " tables) at " + root.toAbsolutePath();
    }

    @Override
    public void close() {
        if (closed) {
            return;
        }
        closed = true;
        flushQuietly();
        flusher.shutdown();
        Log.info("FileDatastore", "Datastore closed cleanly");
    }
}
