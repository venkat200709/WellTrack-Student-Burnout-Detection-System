package com.welltrack.repository;

import com.welltrack.core.json.JsonObject;
import com.welltrack.model.ChatMessage;
import com.welltrack.model.enums.ChatRole;
import com.welltrack.repository.datastore.Datastore;

import java.util.Comparator;
import java.util.List;

/** Persistence for the AI wellness-coach transcript. */
public class ChatMessageRepository extends Repository<ChatMessage> {

    public ChatMessageRepository(Datastore datastore) {
        super(datastore, "chat_messages");
    }

    @Override
    protected JsonObject serialise(ChatMessage message) {
        return JsonObject.of()
                .set("id", message.getId())
                .set("studentId", message.getStudentId())
                .set("role", message.getRole().name())
                .set("content", message.getContent())
                .set("detectedIntent", message.getDetectedIntent())
                .set("sentiment", message.getSentiment())
                .set("confidence", message.getConfidence())
                .set("source", message.getSource())
                .setIfPresent("createdAt", text(message.getCreatedAt()));
    }

    @Override
    protected ChatMessage deserialise(JsonObject row) {
        ChatMessage message = new ChatMessage();
        message.setId(row.getLong("id", 0));
        message.setStudentId(row.getLong("studentId", 0));
        message.setRole(ChatRole.valueOf(row.getString("role", ChatRole.USER.name())));
        message.setContent(row.getString("content", ""));
        message.setDetectedIntent(row.getString("detectedIntent", ""));
        message.setSentiment(row.getDouble("sentiment", 0));
        message.setConfidence(row.getDouble("confidence", 0));
        message.setSource(row.getString("source", "local"));
        message.setCreatedAt(dateTime(row, "createdAt"));
        return message;
    }

    public List<ChatMessage> findConversation(long studentId, int limit) {
        List<ChatMessage> all = findSorted(message -> message.getStudentId() == studentId,
                Comparator.comparing(ChatMessage::getCreatedAt,
                        Comparator.nullsFirst(Comparator.naturalOrder())));
        if (all.size() <= limit) {
            return all;
        }
        return all.subList(all.size() - limit, all.size());
    }

    public int clearConversation(long studentId) {
        return deleteBy(message -> message.getStudentId() == studentId);
    }
}
