package com.welltrack.repository;

import com.welltrack.core.json.JsonObject;
import com.welltrack.model.AuditEvent;
import com.welltrack.repository.datastore.Datastore;

import java.util.Comparator;
import java.util.List;

/** Append-only persistence for the security audit trail. */
public class AuditEventRepository extends Repository<AuditEvent> {

    private static final int RETENTION = 2000;

    public AuditEventRepository(Datastore datastore) {
        super(datastore, "audit_events");
    }

    @Override
    protected JsonObject serialise(AuditEvent event) {
        return JsonObject.of()
                .set("id", event.getId())
                .set("actor", event.getActor())
                .set("action", event.getAction())
                .set("detail", event.getDetail())
                .set("ipAddress", event.getIpAddress())
                .set("successful", event.isSuccessful())
                .setIfPresent("occurredAt", text(event.getOccurredAt()));
    }

    @Override
    protected AuditEvent deserialise(JsonObject row) {
        AuditEvent event = new AuditEvent();
        event.setId(row.getLong("id", 0));
        event.setActor(row.getString("actor", "anonymous"));
        event.setAction(row.getString("action", ""));
        event.setDetail(row.getString("detail", ""));
        event.setIpAddress(row.getString("ipAddress", ""));
        event.setSuccessful(row.getBoolean("successful", true));
        event.setOccurredAt(dateTime(row, "occurredAt"));
        return event;
    }

    public List<AuditEvent> recent(int limit) {
        List<AuditEvent> events = findSorted(event -> true,
                Comparator.comparing(AuditEvent::getOccurredAt,
                        Comparator.nullsFirst(Comparator.naturalOrder())).reversed());
        return events.size() <= limit ? events : events.subList(0, limit);
    }

    /** Drops the oldest entries once the retention ceiling is crossed. */
    public void enforceRetention() {
        if (count() <= RETENTION) {
            return;
        }
        List<AuditEvent> oldestFirst = findSorted(event -> true,
                Comparator.comparing(AuditEvent::getOccurredAt,
                        Comparator.nullsFirst(Comparator.naturalOrder())));
        int excess = oldestFirst.size() - RETENTION;
        for (int i = 0; i < excess; i++) {
            deleteById(oldestFirst.get(i).getId());
        }
    }
}
