package com.welltrack.repository;

import com.welltrack.core.json.JsonObject;
import com.welltrack.core.util.Log;
import com.welltrack.model.Identifiable;
import com.welltrack.repository.datastore.Datastore;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicLong;
import java.util.function.Predicate;
import java.util.stream.Collectors;

/**
 * Generic, thread-safe repository base class.
 *
 * <p>Provides identity generation, an in-memory index for O(1) reads, and
 * write-through persistence to whichever {@link Datastore} is configured.
 * Concrete repositories only supply the table name and the two mapping methods
 * — a compact demonstration of generics, abstraction and template-method
 * design.</p>
 *
 * @param <T> the entity type managed by this repository
 */
public abstract class Repository<T extends Identifiable> {

    private final Datastore datastore;
    private final String table;
    private final Map<Long, T> index = new ConcurrentHashMap<>();
    private final AtomicLong sequence = new AtomicLong(0);

    protected Repository(Datastore datastore, String table) {
        this.datastore = datastore;
        this.table = table;
    }

    /** Converts an entity into its persistent form. */
    protected abstract JsonObject serialise(T entity);

    /** Rebuilds an entity from its persistent form. */
    protected abstract T deserialise(JsonObject row);

    /** Loads the table into memory. Called once during start-up. */
    public void load() {
        List<JsonObject> rows = datastore.readAll(table);
        long highest = 0;
        for (JsonObject row : rows) {
            try {
                T entity = deserialise(row);
                index.put(entity.getId(), entity);
                highest = Math.max(highest, entity.getId());
            } catch (Exception e) {
                Log.warn(getClass().getSimpleName(), "Skipping unreadable row: " + e.getMessage());
            }
        }
        sequence.set(highest);
        if (!rows.isEmpty()) {
            Log.info(getClass().getSimpleName(), "Loaded " + rows.size() + " rows from '" + table + "'");
        }
    }

    /** Inserts or updates an entity, assigning an id when it is new. */
    public T save(T entity) {
        if (entity.getId() <= 0) {
            entity.setId(sequence.incrementAndGet());
        } else {
            sequence.accumulateAndGet(entity.getId(), Math::max);
        }
        index.put(entity.getId(), entity);
        persist();
        return entity;
    }

    /** Saves many entities with a single persistence round trip. */
    public void saveAll(Collection<T> entities) {
        for (T entity : entities) {
            if (entity.getId() <= 0) {
                entity.setId(sequence.incrementAndGet());
            }
            index.put(entity.getId(), entity);
        }
        persist();
    }

    public Optional<T> findById(long id) {
        return Optional.ofNullable(index.get(id));
    }

    public T requireById(long id, String entityName) {
        return findById(id).orElseThrow(
                () -> new com.welltrack.exception.NotFoundException(entityName, id));
    }

    public List<T> findAll() {
        return new ArrayList<>(index.values());
    }

    public List<T> findBy(Predicate<T> predicate) {
        return index.values().stream().filter(predicate).collect(Collectors.toList());
    }

    public Optional<T> findFirst(Predicate<T> predicate) {
        return index.values().stream().filter(predicate).findFirst();
    }

    public List<T> findSorted(Predicate<T> predicate, Comparator<T> comparator) {
        return index.values().stream().filter(predicate).sorted(comparator).collect(Collectors.toList());
    }

    public boolean deleteById(long id) {
        boolean removed = index.remove(id) != null;
        if (removed) {
            persist();
        }
        return removed;
    }

    public int deleteBy(Predicate<T> predicate) {
        List<Long> victims = index.values().stream()
                .filter(predicate)
                .map(Identifiable::getId)
                .collect(Collectors.toList());
        victims.forEach(index::remove);
        if (!victims.isEmpty()) {
            persist();
        }
        return victims.size();
    }

    public long count() {
        return index.size();
    }

    public boolean isEmpty() {
        return index.isEmpty();
    }

    /** Writes the whole table back to the datastore. */
    protected void persist() {
        List<JsonObject> rows = index.values().stream()
                .sorted(Comparator.comparingLong(Identifiable::getId))
                .map(this::serialise)
                .collect(Collectors.toList());
        datastore.writeAll(table, rows);
    }

    protected String table() {
        return table;
    }

    // ------------------------------------------------------------------
    // Shared mapping helpers for the temporal types used across entities.
    // ------------------------------------------------------------------

    protected static String text(LocalDate value) {
        return value == null ? null : value.toString();
    }

    protected static String text(LocalDateTime value) {
        return value == null ? null : value.toString();
    }

    protected static LocalDate date(JsonObject row, String key) {
        String raw = row.getString(key);
        return raw == null || raw.isBlank() ? null : LocalDate.parse(raw);
    }

    protected static LocalDateTime dateTime(JsonObject row, String key) {
        String raw = row.getString(key);
        return raw == null || raw.isBlank() ? null : LocalDateTime.parse(raw);
    }
}
