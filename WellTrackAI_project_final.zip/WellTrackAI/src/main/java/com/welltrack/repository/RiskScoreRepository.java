package com.welltrack.repository;

import com.welltrack.core.json.JsonArray;
import com.welltrack.core.json.JsonObject;
import com.welltrack.model.RiskDriver;
import com.welltrack.model.RiskScore;
import com.welltrack.model.enums.RiskLevel;
import com.welltrack.model.enums.TrendDirection;
import com.welltrack.repository.datastore.Datastore;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Optional;

/** Persistence for computed burnout scores, including their full explanation. */
public class RiskScoreRepository extends Repository<RiskScore> {

    private static final int HISTORY_LIMIT_PER_STUDENT = 400;

    public RiskScoreRepository(Datastore datastore) {
        super(datastore, "risk_scores");
    }

    @Override
    protected JsonObject serialise(RiskScore score) {
        JsonArray drivers = new JsonArray();
        for (RiskDriver driver : score.getDrivers()) {
            drivers.add(JsonObject.of()
                    .set("feature", driver.feature())
                    .set("label", driver.label())
                    .set("value", driver.value())
                    .set("contribution", driver.contribution())
                    .set("explanation", driver.explanation()));
        }
        JsonArray forecast = new JsonArray();
        for (double value : score.getForecast()) {
            forecast.add(value);
        }
        return JsonObject.of()
                .set("id", score.getId())
                .set("studentId", score.getStudentId())
                .set("computedAt", text(score.getComputedAt()))
                .set("score", score.getScore())
                .set("modelProbability", score.getModelProbability())
                .set("heuristicScore", score.getHeuristicScore())
                .set("anomalyScore", score.getAnomalyScore())
                .set("trendScore", score.getTrendScore())
                .set("confidence", score.getConfidence())
                .set("level", score.getLevel().name())
                .set("trend", score.getTrend().name())
                .set("windowDays", score.getWindowDays())
                .set("summary", score.getSummary())
                .set("drivers", drivers)
                .set("forecast", forecast);
    }

    @Override
    protected RiskScore deserialise(JsonObject row) {
        RiskScore score = new RiskScore();
        score.setId(row.getLong("id", 0));
        score.setStudentId(row.getLong("studentId", 0));
        score.setComputedAt(dateTime(row, "computedAt"));
        score.setScore(row.getDouble("score", 0));
        score.setModelProbability(row.getDouble("modelProbability", 0));
        score.setHeuristicScore(row.getDouble("heuristicScore", 0));
        score.setAnomalyScore(row.getDouble("anomalyScore", 0));
        score.setTrendScore(row.getDouble("trendScore", 0));
        score.setConfidence(row.getDouble("confidence", 0));
        score.setLevel(RiskLevel.valueOf(row.getString("level", RiskLevel.STABLE.name())));
        score.setTrend(TrendDirection.valueOf(row.getString("trend", TrendDirection.STABLE.name())));
        score.setWindowDays(row.getInt("windowDays", 0));
        score.setSummary(row.getString("summary", ""));

        List<RiskDriver> drivers = new ArrayList<>();
        JsonArray driverRows = row.getArray("drivers");
        if (driverRows != null) {
            for (Object item : driverRows) {
                if (item instanceof JsonObject driverRow) {
                    drivers.add(new RiskDriver(
                            driverRow.getString("feature", ""),
                            driverRow.getString("label", ""),
                            driverRow.getDouble("value", 0),
                            driverRow.getDouble("contribution", 0),
                            driverRow.getString("explanation", "")));
                }
            }
        }
        score.setDrivers(drivers);

        JsonArray forecastRows = row.getArray("forecast");
        if (forecastRows != null) {
            double[] forecast = new double[forecastRows.size()];
            for (int i = 0; i < forecast.length; i++) {
                forecast[i] = forecastRows.doubleAt(i, 0);
            }
            score.setForecast(forecast);
        }
        return score;
    }

    /** @return the newest score for a student. */
    public Optional<RiskScore> findLatest(long studentId) {
        return findBy(score -> score.getStudentId() == studentId).stream()
                .max(Comparator.comparing(RiskScore::getComputedAt,
                        Comparator.nullsFirst(Comparator.naturalOrder())));
    }

    /** @return a student's score history, oldest first, capped for chart rendering. */
    public List<RiskScore> findHistory(long studentId, int limit) {
        List<RiskScore> history = findSorted(score -> score.getStudentId() == studentId,
                Comparator.comparing(RiskScore::getComputedAt,
                        Comparator.nullsFirst(Comparator.naturalOrder())));
        if (history.size() <= limit) {
            return history;
        }
        return history.subList(history.size() - limit, history.size());
    }

    /** Trims stored history so a long-running deployment stays compact. */
    public void pruneHistory(long studentId) {
        List<RiskScore> history = findHistory(studentId, Integer.MAX_VALUE);
        int excess = history.size() - HISTORY_LIMIT_PER_STUDENT;
        for (int i = 0; i < excess; i++) {
            deleteById(history.get(i).getId());
        }
    }
}
