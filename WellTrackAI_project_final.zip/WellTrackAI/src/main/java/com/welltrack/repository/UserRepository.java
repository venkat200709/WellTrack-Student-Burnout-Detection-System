package com.welltrack.repository;

import com.welltrack.core.json.JsonObject;
import com.welltrack.model.Administrator;
import com.welltrack.model.Faculty;
import com.welltrack.model.Student;
import com.welltrack.model.User;
import com.welltrack.model.enums.Role;
import com.welltrack.repository.datastore.Datastore;

import java.util.Comparator;
import java.util.List;
import java.util.Optional;

/**
 * Persistence for every account type.
 *
 * <p>The mapper is polymorphic: a discriminator column records the concrete
 * subclass so {@link #deserialise(JsonObject)} can rebuild a {@link Student},
 * {@link Faculty} or {@link Administrator} from the same table — the classic
 * single-table inheritance strategy, implemented by hand.</p>
 */
public class UserRepository extends Repository<User> {

    public UserRepository(Datastore datastore) {
        super(datastore, "users");
    }

    @Override
    protected JsonObject serialise(User user) {
        JsonObject row = JsonObject.of()
                .set("id", user.getId())
                .set("type", user.getClass().getSimpleName())
                .set("username", user.getUsername())
                .set("email", user.getEmail())
                .set("fullName", user.getFullName())
                .set("passwordHash", user.getPasswordHash())
                .set("role", user.getRole() == null ? Role.STUDENT.name() : user.getRole().name())
                .set("active", user.isActive())
                .set("failedLoginAttempts", user.getFailedLoginAttempts())
                .set("avatarSeed", user.getAvatarSeed())
                .setIfPresent("lockedUntil", text(user.getLockedUntil()))
                .setIfPresent("createdAt", text(user.getCreatedAt()))
                .setIfPresent("lastLoginAt", text(user.getLastLoginAt()));

        if (user instanceof Student student) {
            row.set("registerNumber", student.getRegisterNumber())
                    .set("department", student.getDepartment())
                    .set("section", student.getSection())
                    .set("yearOfStudy", student.getYearOfStudy())
                    .set("cgpa", student.getCgpa())
                    .set("attendancePercentage", student.getAttendancePercentage())
                    .set("mentorId", student.getMentorId())
                    .set("streakDays", student.getStreakDays())
                    .set("wellnessPoints", student.getWellnessPoints())
                    .set("creditLoad", student.getCreditLoad())
                    .set("hostelStatus", student.getHostelStatus());
        } else if (user instanceof Faculty faculty) {
            row.set("employeeCode", faculty.getEmployeeCode())
                    .set("department", faculty.getDepartment())
                    .set("designation", faculty.getDesignation())
                    .set("menteeCapacity", faculty.getMenteeCapacity());
        } else if (user instanceof Administrator administrator) {
            row.set("office", administrator.getOffice());
        }
        return row;
    }

    @Override
    protected User deserialise(JsonObject row) {
        String type = row.getString("type", "Student");
        User user = switch (type) {
            case "Faculty" -> readFaculty(row);
            case "Administrator" -> readAdministrator(row);
            default -> readStudent(row);
        };
        user.setId(row.getLong("id", 0));
        user.setUsername(row.getString("username"));
        user.setEmail(row.getString("email"));
        user.setFullName(row.getString("fullName"));
        user.setPasswordHash(row.getString("passwordHash"));
        user.setRole(Role.from(row.getString("role")));
        user.setActive(row.getBoolean("active", true));
        user.setFailedLoginAttempts(row.getInt("failedLoginAttempts", 0));
        user.setAvatarSeed(row.getString("avatarSeed", user.getUsername()));
        user.setLockedUntil(dateTime(row, "lockedUntil"));
        user.setCreatedAt(dateTime(row, "createdAt"));
        user.setLastLoginAt(dateTime(row, "lastLoginAt"));
        return user;
    }

    private Student readStudent(JsonObject row) {
        Student student = new Student();
        student.setRegisterNumber(row.getString("registerNumber"));
        student.setDepartment(row.getString("department"));
        student.setSection(row.getString("section"));
        student.setYearOfStudy(row.getInt("yearOfStudy", 1));
        student.setCgpa(row.getDouble("cgpa", 0));
        student.setAttendancePercentage(row.getDouble("attendancePercentage", 0));
        student.setMentorId(row.getLong("mentorId", 0));
        student.setStreakDays(row.getInt("streakDays", 0));
        student.setWellnessPoints(row.getInt("wellnessPoints", 0));
        student.setCreditLoad(row.getInt("creditLoad", 0));
        student.setHostelStatus(row.getString("hostelStatus", "Day Scholar"));
        return student;
    }

    private Faculty readFaculty(JsonObject row) {
        Faculty faculty = new Faculty();
        faculty.setEmployeeCode(row.getString("employeeCode"));
        faculty.setDepartment(row.getString("department"));
        faculty.setDesignation(row.getString("designation"));
        faculty.setMenteeCapacity(row.getInt("menteeCapacity", 40));
        return faculty;
    }

    private Administrator readAdministrator(JsonObject row) {
        Administrator administrator = new Administrator();
        administrator.setOffice(row.getString("office", "Office of Student Welfare"));
        return administrator;
    }

    // ------------------------------------------------------------------
    // Query methods
    // ------------------------------------------------------------------

    /** Case-insensitive lookup by username or email — used by the login flow. */
    public Optional<User> findByIdentifier(String identifier) {
        if (identifier == null || identifier.isBlank()) {
            return Optional.empty();
        }
        String needle = identifier.trim().toLowerCase();
        return findFirst(user ->
                needle.equalsIgnoreCase(user.getUsername()) || needle.equalsIgnoreCase(user.getEmail()));
    }

    public boolean usernameExists(String username) {
        return findFirst(user -> username != null && username.equalsIgnoreCase(user.getUsername())).isPresent();
    }

    public boolean emailExists(String email) {
        return findFirst(user -> email != null && email.equalsIgnoreCase(user.getEmail())).isPresent();
    }

    public List<Student> findAllStudents() {
        return findBy(user -> user instanceof Student).stream()
                .map(Student.class::cast)
                .sorted(Comparator.comparing(Student::getFullName,
                        Comparator.nullsLast(Comparator.naturalOrder())))
                .toList();
    }

    public List<Student> findStudentsOfMentor(long mentorId) {
        return findAllStudents().stream()
                .filter(student -> student.getMentorId() == mentorId)
                .toList();
    }

    public Optional<Student> findStudent(long id) {
        return findById(id).filter(Student.class::isInstance).map(Student.class::cast);
    }

    public List<Faculty> findAllFaculty() {
        return findBy(user -> user instanceof Faculty).stream().map(Faculty.class::cast).toList();
    }
}
