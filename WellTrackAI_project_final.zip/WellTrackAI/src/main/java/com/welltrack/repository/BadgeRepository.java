package com.welltrack.repository;

import com.welltrack.core.json.JsonObject;
import com.welltrack.model.Badge;
import com.welltrack.model.enums.BadgeTier;
import com.welltrack.repository.datastore.Datastore;

import java.util.Comparator;
import java.util.List;

/** Persistence for gamification badges. */
public class BadgeRepository extends Repository<Badge> {

    public BadgeRepository(Datastore datastore) {
        super(datastore, "badges");
    }

    @Override
    protected JsonObject serialise(Badge badge) {
        return JsonObject.of()
                .set("id", badge.getId())
                .set("studentId", badge.getStudentId())
                .set("code", badge.getCode())
                .set("name", badge.getName())
                .set("description", badge.getDescription())
                .set("glyph", badge.getGlyph())
                .set("tier", badge.getTier().name())
                .set("points", badge.getPoints())
                .setIfPresent("earnedAt", text(badge.getEarnedAt()));
    }

    @Override
    protected Badge deserialise(JsonObject row) {
        Badge badge = new Badge();
        badge.setId(row.getLong("id", 0));
        badge.setStudentId(row.getLong("studentId", 0));
        badge.setCode(row.getString("code", ""));
        badge.setName(row.getString("name", ""));
        badge.setDescription(row.getString("description", ""));
        badge.setGlyph(row.getString("glyph", "🏅"));
        badge.setTier(BadgeTier.valueOf(row.getString("tier", BadgeTier.BRONZE.name())));
        badge.setPoints(row.getInt("points", 0));
        badge.setEarnedAt(dateTime(row, "earnedAt"));
        return badge;
    }

    public List<Badge> findForStudent(long studentId) {
        return findSorted(badge -> badge.getStudentId() == studentId,
                Comparator.comparing(Badge::getEarnedAt,
                        Comparator.nullsFirst(Comparator.naturalOrder())).reversed());
    }

    public boolean hasBadge(long studentId, String code) {
        return findFirst(badge -> badge.getStudentId() == studentId
                && code.equals(badge.getCode())).isPresent();
    }
}
