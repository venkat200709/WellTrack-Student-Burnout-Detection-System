package com.welltrack.repository.datastore;

import com.welltrack.core.json.Json;
import com.welltrack.core.json.JsonObject;
import com.welltrack.core.util.Log;
import com.welltrack.exception.PersistenceException;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

/**
 * A relational implementation of {@link Datastore}, kept deliberately
 * driver-agnostic.
 *
 * <p>It speaks plain JDBC (part of the JDK), so this class compiles with no
 * external dependency at all. To run WellTrack on a real database you only
 * need to:</p>
 * <ol>
 *   <li>drop the driver jar on the classpath — {@code h2-*.jar} or
 *       {@code mysql-connector-j-*.jar};</li>
 *   <li>set {@code welltrack.datastore=jdbc} together with
 *       {@code welltrack.jdbc.url}, {@code welltrack.jdbc.user} and
 *       {@code welltrack.jdbc.password}.</li>
 * </ol>
 *
 * <p>The schema is intentionally simple and portable: one row per entity,
 * holding the table name, the primary key and a JSON payload. The DDL in
 * {@code sql/schema.sql} also creates the normalised reporting views used for
 * SQL-based analysis of the same data.</p>
 */
public final class JdbcDatastore implements Datastore {

    private static final String TABLE = "wt_document";

    private final String url;
    private final String user;
    private final String password;
    private Connection connection;

    public JdbcDatastore(String url, String user, String password) {
        this.url = url;
        this.user = user;
        this.password = password;
        connect();
        ensureSchema();
        Log.success("JdbcDatastore", "Connected to " + url);
    }

    private void connect() {
        try {
            this.connection = DriverManager.getConnection(url, user, password);
            this.connection.setAutoCommit(true);
        } catch (SQLException e) {
            throw new PersistenceException(
                    "Could not open a JDBC connection to " + url
                            + ". Is the driver jar on the classpath?", e);
        }
    }

    private void ensureSchema() {
        String ddl = """
                CREATE TABLE IF NOT EXISTS %s (
                    table_name VARCHAR(64)  NOT NULL,
                    entity_id  BIGINT       NOT NULL,
                    payload    TEXT         NOT NULL,
                    PRIMARY KEY (table_name, entity_id)
                )
                """.formatted(TABLE);
        try (Statement statement = connection.createStatement()) {
            statement.executeUpdate(ddl);
        } catch (SQLException e) {
            throw new PersistenceException("Could not create the WellTrack schema", e);
        }
    }

    @Override
    public synchronized List<JsonObject> readAll(String table) {
        List<JsonObject> rows = new ArrayList<>();
        String sql = "SELECT payload FROM " + TABLE + " WHERE table_name = ? ORDER BY entity_id";
        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setString(1, table);
            try (ResultSet results = statement.executeQuery()) {
                while (results.next()) {
                    rows.add(Json.parseObject(results.getString(1)));
                }
            }
        } catch (SQLException e) {
            throw new PersistenceException("Could not read table '" + table + "'", e);
        }
        return rows;
    }

    @Override
    public synchronized void writeAll(String table, List<JsonObject> rows) {
        try {
            connection.setAutoCommit(false);
            try (PreparedStatement delete =
                         connection.prepareStatement("DELETE FROM " + TABLE + " WHERE table_name = ?")) {
                delete.setString(1, table);
                delete.executeUpdate();
            }
            String insert = "INSERT INTO " + TABLE + " (table_name, entity_id, payload) VALUES (?, ?, ?)";
            try (PreparedStatement statement = connection.prepareStatement(insert)) {
                for (JsonObject row : rows) {
                    statement.setString(1, table);
                    statement.setLong(2, row.getLong("id", 0));
                    statement.setString(3, Json.write(row));
                    statement.addBatch();
                }
                statement.executeBatch();
            }
            connection.commit();
        } catch (SQLException e) {
            rollbackQuietly();
            throw new PersistenceException("Could not persist table '" + table + "'", e);
        } finally {
            try {
                connection.setAutoCommit(true);
            } catch (SQLException ignored) {
                // Nothing useful can be done here.
            }
        }
    }

    private void rollbackQuietly() {
        try {
            connection.rollback();
        } catch (SQLException ignored) {
            // Nothing useful can be done here.
        }
    }

    @Override
    public void flush() {
        // Writes are committed synchronously; nothing is buffered.
    }

    @Override
    public String describe() {
        return "JDBC datastore at " + url;
    }

    @Override
    public synchronized void close() {
        try {
            if (connection != null && !connection.isClosed()) {
                connection.close();
            }
        } catch (SQLException e) {
            Log.warn("JdbcDatastore", "Failed to close the connection: " + e.getMessage());
        }
    }
}
