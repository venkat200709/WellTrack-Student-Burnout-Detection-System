package com.welltrack.repository.datastore;

import com.welltrack.core.json.JsonObject;

import java.util.List;

/**
 * The persistence abstraction that sits underneath every repository.
 *
 * <p>WellTrack ships two interchangeable implementations:</p>
 * <ul>
 *   <li>{@link FileDatastore} — a zero-configuration, embedded, journalled
 *       document store that runs anywhere a JDK runs (the default);</li>
 *   <li>{@link JdbcDatastore} — the same contract backed by a relational
 *       database, so the identical application can run against H2 or MySQL
 *       simply by changing configuration and dropping the driver on the
 *       classpath.</li>
 * </ul>
 *
 * <p>Because the repositories depend only on this interface, swapping the
 * storage engine requires no change anywhere else in the code base — the
 * dependency-inversion principle applied concretely.</p>
 */
public interface Datastore extends AutoCloseable {

    /** Reads every row of a logical table. */
    List<JsonObject> readAll(String table);

    /** Replaces the contents of a logical table. */
    void writeAll(String table, List<JsonObject> rows);

    /** Forces any buffered writes to durable storage. */
    void flush();

    /** @return a short human-readable description for the health endpoint. */
    String describe();

    @Override
    void close();
}
