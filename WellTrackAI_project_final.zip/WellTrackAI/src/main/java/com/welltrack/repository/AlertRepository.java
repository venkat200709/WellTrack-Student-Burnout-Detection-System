package com.welltrack.repository;

import com.welltrack.core.json.JsonObject;
import com.welltrack.model.Alert;
import com.welltrack.model.enums.AlertSeverity;
import com.welltrack.repository.datastore.Datastore;

import java.util.Comparator;
import java.util.List;

/** Persistence and query helpers for early-warning alerts. */
public class AlertRepository extends Repository<Alert> {

    public AlertRepository(Datastore datastore) {
        super(datastore, "alerts");
    }

    @Override
    protected JsonObject serialise(Alert alert) {
        return JsonObject.of()
                .set("id", alert.getId())
                .set("studentId", alert.getStudentId())
                .set("studentName", alert.getStudentName())
                .set("severity", alert.getSeverity().name())
                .set("title", alert.getTitle())
                .set("message", alert.getMessage())
                .set("category", alert.getCategory())
                .set("triggeringScore", alert.getTriggeringScore())
                .set("acknowledged", alert.isAcknowledged())
                .setIfPresent("acknowledgedBy", alert.getAcknowledgedBy())
                .setIfPresent("acknowledgedAt", text(alert.getAcknowledgedAt()))
                .setIfPresent("createdAt", text(alert.getCreatedAt()));
    }

    @Override
    protected Alert deserialise(JsonObject row) {
        Alert alert = new Alert();
        alert.setId(row.getLong("id", 0));
        alert.setStudentId(row.getLong("studentId", 0));
        alert.setStudentName(row.getString("studentName", ""));
        alert.setSeverity(AlertSeverity.valueOf(row.getString("severity", AlertSeverity.INFO.name())));
        alert.setTitle(row.getString("title", ""));
        alert.setMessage(row.getString("message", ""));
        alert.setCategory(row.getString("category", "GENERAL"));
        alert.setTriggeringScore(row.getDouble("triggeringScore", 0));
        alert.setAcknowledged(row.getBoolean("acknowledged", false));
        alert.setAcknowledgedBy(row.getString("acknowledgedBy"));
        alert.setAcknowledgedAt(dateTime(row, "acknowledgedAt"));
        alert.setCreatedAt(dateTime(row, "createdAt"));
        return alert;
    }

    private static final Comparator<Alert> NEWEST_FIRST =
            Comparator.comparing(Alert::getCreatedAt,
                    Comparator.nullsFirst(Comparator.naturalOrder())).reversed();

    public List<Alert> findForStudent(long studentId) {
        return findSorted(alert -> alert.getStudentId() == studentId, NEWEST_FIRST);
    }

    public List<Alert> findUnacknowledged() {
        return findSorted(alert -> !alert.isAcknowledged(), NEWEST_FIRST);
    }

    public List<Alert> findForStudents(List<Long> studentIds) {
        return findSorted(alert -> studentIds.contains(alert.getStudentId()), NEWEST_FIRST);
    }

    public long countUnacknowledged(long studentId) {
        return findBy(alert -> alert.getStudentId() == studentId && !alert.isAcknowledged()).size();
    }

    /** Prevents alert storms: true when a similar alert already exists today. */
    public boolean existsSimilarToday(long studentId, String category) {
        java.time.LocalDate today = java.time.LocalDate.now();
        return findFirst(alert -> alert.getStudentId() == studentId
                && category.equals(alert.getCategory())
                && alert.getCreatedAt() != null
                && alert.getCreatedAt().toLocalDate().equals(today)).isPresent();
    }
}
