package com.welltrack.core.json;

/**
 * A single-pass recursive-descent JSON parser.
 *
 * <p>Written from scratch for WellTrack. It walks the character buffer once,
 * producing {@link JsonObject}, {@link JsonArray}, {@code String},
 * {@code Double}, {@code Boolean} and {@code null} nodes. Errors carry the
 * offending offset so malformed API payloads are easy to diagnose.</p>
 */
final class JsonParser {

    private static final int MAX_DEPTH = 64;

    private final String source;
    private int cursor;
    private int depth;

    JsonParser(String source) {
        if (source == null) {
            throw new JsonException("JSON source must not be null");
        }
        this.source = source;
        this.cursor = 0;
        this.depth = 0;
    }

    Object parseDocument() {
        skipWhitespace();
        if (cursor >= source.length()) {
            throw error("Empty JSON document");
        }
        Object value = parseValue();
        skipWhitespace();
        if (cursor < source.length()) {
            throw error("Unexpected trailing content");
        }
        return value;
    }

    private Object parseValue() {
        skipWhitespace();
        if (cursor >= source.length()) {
            throw error("Unexpected end of input");
        }
        char c = source.charAt(cursor);
        return switch (c) {
            case '{' -> parseObject();
            case '[' -> parseArray();
            case '"' -> parseString();
            case 't', 'f' -> parseBoolean();
            case 'n' -> parseNull();
            default -> parseNumber();
        };
    }

    private JsonObject parseObject() {
        enter();
        expect('{');
        JsonObject object = new JsonObject();
        skipWhitespace();
        if (peek() == '}') {
            cursor++;
            leave();
            return object;
        }
        while (true) {
            skipWhitespace();
            String key = parseString();
            skipWhitespace();
            expect(':');
            object.put(key, parseValue());
            skipWhitespace();
            char c = peek();
            if (c == ',') {
                cursor++;
                continue;
            }
            if (c == '}') {
                cursor++;
                leave();
                return object;
            }
            throw error("Expected ',' or '}' inside object");
        }
    }

    private JsonArray parseArray() {
        enter();
        expect('[');
        JsonArray array = new JsonArray();
        skipWhitespace();
        if (peek() == ']') {
            cursor++;
            leave();
            return array;
        }
        while (true) {
            array.add(parseValue());
            skipWhitespace();
            char c = peek();
            if (c == ',') {
                cursor++;
                continue;
            }
            if (c == ']') {
                cursor++;
                leave();
                return array;
            }
            throw error("Expected ',' or ']' inside array");
        }
    }

    private String parseString() {
        expect('"');
        StringBuilder builder = new StringBuilder();
        while (true) {
            if (cursor >= source.length()) {
                throw error("Unterminated string literal");
            }
            char c = source.charAt(cursor++);
            if (c == '"') {
                return builder.toString();
            }
            if (c != '\\') {
                builder.append(c);
                continue;
            }
            if (cursor >= source.length()) {
                throw error("Dangling escape sequence");
            }
            char escape = source.charAt(cursor++);
            switch (escape) {
                case '"' -> builder.append('"');
                case '\\' -> builder.append('\\');
                case '/' -> builder.append('/');
                case 'b' -> builder.append('\b');
                case 'f' -> builder.append('\f');
                case 'n' -> builder.append('\n');
                case 'r' -> builder.append('\r');
                case 't' -> builder.append('\t');
                case 'u' -> builder.append(parseUnicodeEscape());
                default -> throw error("Unsupported escape '\\" + escape + "'");
            }
        }
    }

    private char parseUnicodeEscape() {
        if (cursor + 4 > source.length()) {
            throw error("Truncated \\u escape");
        }
        String hex = source.substring(cursor, cursor + 4);
        cursor += 4;
        try {
            return (char) Integer.parseInt(hex, 16);
        } catch (NumberFormatException e) {
            throw error("Malformed \\u escape '" + hex + "'");
        }
    }

    private Boolean parseBoolean() {
        if (source.startsWith("true", cursor)) {
            cursor += 4;
            return Boolean.TRUE;
        }
        if (source.startsWith("false", cursor)) {
            cursor += 5;
            return Boolean.FALSE;
        }
        throw error("Invalid boolean literal");
    }

    private Object parseNull() {
        if (source.startsWith("null", cursor)) {
            cursor += 4;
            return null;
        }
        throw error("Invalid null literal");
    }

    private Double parseNumber() {
        int start = cursor;
        if (peek() == '-' || peek() == '+') {
            cursor++;
        }
        while (cursor < source.length()) {
            char c = source.charAt(cursor);
            if (Character.isDigit(c) || c == '.' || c == 'e' || c == 'E' || c == '-' || c == '+') {
                cursor++;
            } else {
                break;
            }
        }
        String literal = source.substring(start, cursor);
        try {
            return Double.valueOf(literal);
        } catch (NumberFormatException e) {
            throw error("Invalid number literal '" + literal + "'");
        }
    }

    private void expect(char expected) {
        if (cursor >= source.length() || source.charAt(cursor) != expected) {
            throw error("Expected '" + expected + "'");
        }
        cursor++;
    }

    private char peek() {
        return cursor < source.length() ? source.charAt(cursor) : '\0';
    }

    private void skipWhitespace() {
        while (cursor < source.length() && Character.isWhitespace(source.charAt(cursor))) {
            cursor++;
        }
    }

    private void enter() {
        if (++depth > MAX_DEPTH) {
            throw error("JSON nesting deeper than " + MAX_DEPTH + " levels is rejected");
        }
    }

    private void leave() {
        depth--;
    }

    private JsonException error(String message) {
        return new JsonException(message + " (at offset " + cursor + ")");
    }
}
