package com.welltrack.core.json;

/**
 * Implemented by domain objects that know how to describe themselves as JSON.
 * This is WellTrack's abstraction boundary between the model layer and the
 * transport layer: controllers never reach into entity internals, they simply
 * ask the entity to render itself.
 */
public interface JsonSerializable {

    /** @return a JSON representation of this object. */
    JsonObject toJson();
}
