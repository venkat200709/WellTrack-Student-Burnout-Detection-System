package com.welltrack.core.http;

import com.welltrack.core.json.Json;
import com.welltrack.core.json.JsonObject;
import com.welltrack.model.User;

import java.net.URLDecoder;
import java.nio.charset.StandardCharsets;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Optional;

/**
 * An immutable view of an inbound HTTP request, enriched by the router with
 * decoded path variables and by the security filter with the authenticated
 * principal.
 */
public final class HttpRequest {

    private final HttpMethod method;
    private final String path;
    private final Map<String, String> headers;
    private final Map<String, String> query;
    private final Map<String, String> pathVariables;
    private final String body;
    private final String remoteAddress;
    private User principal;

    public HttpRequest(HttpMethod method,
                       String path,
                       Map<String, String> headers,
                       Map<String, String> query,
                       String body,
                       String remoteAddress) {
        this.method = method;
        this.path = path;
        this.headers = Collections.unmodifiableMap(new LinkedHashMap<>(headers));
        this.query = Collections.unmodifiableMap(new LinkedHashMap<>(query));
        this.pathVariables = new LinkedHashMap<>();
        this.body = body == null ? "" : body;
        this.remoteAddress = remoteAddress;
    }

    public HttpMethod method() {
        return method;
    }

    public String path() {
        return path;
    }

    public String remoteAddress() {
        return remoteAddress;
    }

    public String header(String name) {
        return headers.get(name.toLowerCase());
    }

    public Map<String, String> headers() {
        return headers;
    }

    public String query(String name, String fallback) {
        String value = query.get(name);
        return value == null || value.isBlank() ? fallback : value;
    }

    public int queryInt(String name, int fallback) {
        try {
            return Integer.parseInt(query(name, String.valueOf(fallback)));
        } catch (NumberFormatException e) {
            return fallback;
        }
    }

    public String pathVariable(String name) {
        return pathVariables.get(name);
    }

    public long pathVariableLong(String name) {
        try {
            return Long.parseLong(String.valueOf(pathVariables.get(name)));
        } catch (NumberFormatException e) {
            throw new IllegalArgumentException("Path variable '" + name + "' is not numeric");
        }
    }

    void bindPathVariables(Map<String, String> variables) {
        pathVariables.clear();
        pathVariables.putAll(variables);
    }

    public String body() {
        return body;
    }

    /** @return the request body parsed as a JSON object (empty object when absent). */
    public JsonObject json() {
        if (body.isBlank()) {
            return new JsonObject();
        }
        Object parsed = Json.parse(body);
        return parsed instanceof JsonObject object ? object : new JsonObject();
    }

    public Optional<User> principal() {
        return Optional.ofNullable(principal);
    }

    /** @return the authenticated user, or throws when the route was left unguarded by mistake. */
    public User requirePrincipal() {
        if (principal == null) {
            throw new IllegalStateException("Route requires authentication but no principal was bound");
        }
        return principal;
    }

    public void bindPrincipal(User user) {
        this.principal = user;
    }

    /** Decodes an {@code application/x-www-form-urlencoded} query string. */
    public static Map<String, String> parseQuery(String rawQuery) {
        Map<String, String> result = new LinkedHashMap<>();
        if (rawQuery == null || rawQuery.isBlank()) {
            return result;
        }
        for (String pair : rawQuery.split("&")) {
            int equals = pair.indexOf('=');
            if (equals < 0) {
                result.put(decode(pair), "");
            } else {
                result.put(decode(pair.substring(0, equals)), decode(pair.substring(equals + 1)));
            }
        }
        return result;
    }

    private static String decode(String value) {
        return URLDecoder.decode(value, StandardCharsets.UTF_8);
    }
}
