package com.welltrack.core.http;

import com.welltrack.core.json.Json;
import com.welltrack.core.json.JsonObject;

import java.nio.charset.StandardCharsets;
import java.util.LinkedHashMap;
import java.util.Map;

/**
 * An outbound HTTP response. Controllers build these with the static factory
 * methods; the transport layer writes the bytes.
 */
public final class HttpResponse {

    private final HttpStatus status;
    private final byte[] payload;
    private final String contentType;
    private final Map<String, String> headers = new LinkedHashMap<>();

    private HttpResponse(HttpStatus status, byte[] payload, String contentType) {
        this.status = status;
        this.payload = payload;
        this.contentType = contentType;
    }

    public static HttpResponse json(HttpStatus status, Object body) {
        return new HttpResponse(status, Json.write(body).getBytes(StandardCharsets.UTF_8),
                "application/json; charset=utf-8");
    }

    public static HttpResponse ok(Object body) {
        return json(HttpStatus.OK, body);
    }

    public static HttpResponse created(Object body) {
        return json(HttpStatus.CREATED, body);
    }

    public static HttpResponse noContent() {
        return new HttpResponse(HttpStatus.NO_CONTENT, new byte[0], "application/json");
    }

    public static HttpResponse error(HttpStatus status, String message) {
        return json(status, JsonObject.of()
                .set("success", false)
                .set("status", status.code())
                .set("error", status.reason())
                .set("message", message));
    }

    public static HttpResponse text(HttpStatus status, String body, String contentType) {
        return new HttpResponse(status, body.getBytes(StandardCharsets.UTF_8), contentType);
    }

    public static HttpResponse bytes(HttpStatus status, byte[] body, String contentType) {
        return new HttpResponse(status, body, contentType);
    }

    public HttpResponse header(String name, String value) {
        headers.put(name, value);
        return this;
    }

    public HttpStatus status() {
        return status;
    }

    public byte[] payload() {
        return payload;
    }

    public String contentType() {
        return contentType;
    }

    public Map<String, String> headers() {
        return headers;
    }
}
