package com.welltrack.core.http;

import com.welltrack.core.util.Log;

import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;

/**
 * The WellTrack routing table.
 *
 * <p>Routes are declared with a fluent DSL and can be grouped under a common
 * prefix. Each route carries its own authorisation contract, so security is
 * expressed next to the endpoint instead of in a distant configuration file.</p>
 *
 * <pre>{@code
 * router.group("/api/students")
 *       .get("/{id}", handler).authenticated()
 *       .post("", handler).roles("FACULTY", "ADMIN");
 * }</pre>
 */
public final class Router {

    private final List<Route> routes = new ArrayList<>();
    private String prefix = "";
    private Route lastRegistered;

    public Router group(String prefix) {
        this.prefix = prefix == null ? "" : prefix;
        return this;
    }

    public Router get(String path, RouteHandler handler) {
        return register(HttpMethod.GET, path, handler);
    }

    public Router post(String path, RouteHandler handler) {
        return register(HttpMethod.POST, path, handler);
    }

    public Router put(String path, RouteHandler handler) {
        return register(HttpMethod.PUT, path, handler);
    }

    public Router patch(String path, RouteHandler handler) {
        return register(HttpMethod.PATCH, path, handler);
    }

    public Router delete(String path, RouteHandler handler) {
        return register(HttpMethod.DELETE, path, handler);
    }

    /** Marks the most recently declared route as requiring a valid session. */
    public Router authenticated() {
        return replaceLast(true, Collections.emptySet());
    }

    /** Marks the most recently declared route as requiring one of the given roles. */
    public Router roles(String... roles) {
        return replaceLast(true, new LinkedHashSet<>(List.of(roles)));
    }

    private Router register(HttpMethod method, String path, RouteHandler handler) {
        Route route = new Route(method, prefix + path, handler, false, Collections.emptySet());
        routes.add(route);
        lastRegistered = route;
        return this;
    }

    private Router replaceLast(boolean authenticated, Set<String> roles) {
        if (lastRegistered == null) {
            throw new IllegalStateException("No route has been declared yet");
        }
        int index = routes.lastIndexOf(lastRegistered);
        Route replacement = new Route(lastRegistered.method(), lastRegistered.template(),
                lastRegistered.handler(), authenticated, roles);
        routes.set(index, replacement);
        lastRegistered = replacement;
        return this;
    }

    /**
     * Finds the route that serves the request and binds its path variables.
     *
     * <p>When several templates match, the most <em>specific</em> one wins —
     * specificity being the number of literal segments. Without this rule
     * {@code /api/risk/{studentId}} would happily swallow
     * {@code /api/risk/distribution}, capturing the word "distribution" as an
     * id. Ranking by variable count makes declaration order irrelevant.</p>
     */
    public Optional<Route> resolve(HttpRequest request) {
        Route best = null;
        Map<String, String> bestVariables = null;
        int fewestVariables = Integer.MAX_VALUE;

        for (Route route : routes) {
            if (route.method() != request.method()) {
                continue;
            }
            Map<String, String> variables = route.match(request.path());
            if (variables == null) {
                continue;
            }
            if (variables.size() < fewestVariables) {
                fewestVariables = variables.size();
                best = route;
                bestVariables = variables;
                if (fewestVariables == 0) {
                    break;
                }
            }
        }
        if (best == null) {
            return Optional.empty();
        }
        request.bindPathVariables(bestVariables);
        return Optional.of(best);
    }

    /** @return true when the path exists under a different verb (drives 405 responses). */
    public boolean pathExists(String path) {
        return routes.stream().anyMatch(route -> route.match(path) != null);
    }

    public List<Route> routes() {
        return Collections.unmodifiableList(routes);
    }

    public void printRoutingTable() {
        Log.info("Router", "Registered " + routes.size() + " API routes");
    }
}
