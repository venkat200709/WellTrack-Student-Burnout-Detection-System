package com.welltrack.core.di;

import com.welltrack.core.util.Log;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.function.Supplier;

/**
 * A minimal, type-safe dependency-injection container.
 *
 * <p>Components are registered as lazily-initialised singletons keyed by their
 * type. Resolution is thread-safe and cycle-aware, and the registry doubles as
 * the application's lifecycle owner: anything implementing {@link AutoCloseable}
 * is shut down in reverse registration order.</p>
 *
 * <p>This replaces a framework container with roughly a hundred lines of plain
 * Java, keeping the whole application dependency-free while still giving the
 * service layer constructor injection and a single composition root.</p>
 */
public final class ServiceRegistry implements AutoCloseable {

    private final Map<Class<?>, Supplier<?>> factories = new LinkedHashMap<>();
    private final Map<Class<?>, Object> singletons = new LinkedHashMap<>();
    private final java.util.Set<Class<?>> resolving = new java.util.LinkedHashSet<>();
    private final Object lock = new Object();

    /** Registers a lazily constructed singleton. */
    public <T> ServiceRegistry register(Class<T> type, Supplier<T> factory) {
        synchronized (lock) {
            if (factories.containsKey(type)) {
                throw new IllegalStateException("Component already registered: " + type.getName());
            }
            factories.put(type, factory);
        }
        return this;
    }

    /** Registers an already-constructed instance. */
    public <T> ServiceRegistry registerInstance(Class<T> type, T instance) {
        synchronized (lock) {
            singletons.put(type, instance);
            factories.putIfAbsent(type, () -> instance);
        }
        return this;
    }

    /** Resolves a component, constructing it on first use. */
    @SuppressWarnings("unchecked")
    public <T> T get(Class<T> type) {
        synchronized (lock) {
            Object existing = singletons.get(type);
            if (existing != null) {
                return (T) existing;
            }
            Supplier<?> factory = factories.get(type);
            if (factory == null) {
                throw new IllegalStateException("No component registered for " + type.getName());
            }
            if (!resolving.add(type)) {
                throw new IllegalStateException("Circular dependency detected while resolving " + type.getName());
            }
            try {
                Object instance = factory.get();
                singletons.put(type, instance);
                return (T) instance;
            } finally {
                resolving.remove(type);
            }
        }
    }

    /** Eagerly instantiates everything so start-up failures surface immediately. */
    public void initialiseAll() {
        for (Class<?> type : new LinkedHashMap<>(factories).keySet()) {
            get(type);
        }
        Log.info("ServiceRegistry", "Initialised " + singletons.size() + " components");
    }

    public int size() {
        return singletons.size();
    }

    @Override
    public void close() {
        java.util.List<Object> instances = new java.util.ArrayList<>(singletons.values());
        java.util.Collections.reverse(instances);
        for (Object instance : instances) {
            if (instance instanceof AutoCloseable closeable) {
                try {
                    closeable.close();
                } catch (Exception e) {
                    Log.warn("ServiceRegistry", "Failed closing " + instance.getClass().getSimpleName());
                }
            }
        }
        singletons.clear();
        factories.clear();
    }
}
