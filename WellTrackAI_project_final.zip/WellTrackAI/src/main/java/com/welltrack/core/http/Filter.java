package com.welltrack.core.http;

/**
 * A server filter. Filters form an ordered chain around the routed handler and
 * are how WellTrack implements CORS, request logging, rate limiting and
 * authentication without polluting controller code.
 */
@FunctionalInterface
public interface Filter {

    HttpResponse apply(HttpRequest request, FilterChain chain) throws Exception;
}
