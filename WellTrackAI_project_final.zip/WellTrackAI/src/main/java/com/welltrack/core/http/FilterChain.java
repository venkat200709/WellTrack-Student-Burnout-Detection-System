package com.welltrack.core.http;

/** Continuation handed to a {@link Filter} so it can delegate to the next stage. */
@FunctionalInterface
public interface FilterChain {

    HttpResponse proceed(HttpRequest request) throws Exception;
}
