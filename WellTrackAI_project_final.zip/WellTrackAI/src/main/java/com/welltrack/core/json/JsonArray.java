package com.welltrack.core.json;

import java.util.ArrayList;
import java.util.Collection;

/**
 * An ordered JSON array with a fluent API. Backed by {@link ArrayList} so it
 * interoperates with the rest of the collections framework.
 */
public final class JsonArray extends ArrayList<Object> {

    private static final long serialVersionUID = 1L;

    public JsonArray() {
        super();
    }

    public JsonArray(Collection<?> source) {
        super();
        if (source != null) {
            addAll(source);
        }
    }

    public static JsonArray of(Object... values) {
        JsonArray array = new JsonArray();
        if (values != null) {
            for (Object value : values) {
                array.add(value);
            }
        }
        return array;
    }

    /** Fluent add. */
    public JsonArray append(Object value) {
        add(value);
        return this;
    }

    public JsonObject objectAt(int index) {
        Object v = get(index);
        return v instanceof JsonObject o ? o : null;
    }

    public double doubleAt(int index, double fallback) {
        Object v = get(index);
        return v instanceof Number n ? n.doubleValue() : fallback;
    }

    @Override
    public String toString() {
        return Json.write(this);
    }
}
