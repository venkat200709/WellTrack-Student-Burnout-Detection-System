package com.welltrack.core.http;

import com.welltrack.core.util.Log;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Serves the single-page application.
 *
 * <p>Resources are looked up on the classpath first (so a packaged jar is
 * self-contained) and then on the filesystem under {@code src/main/resources/web}
 * — which means edits to the UI are visible after a browser refresh while you
 * are developing inside IntelliJ IDEA.</p>
 *
 * <p>Responses are cached in memory when {@code welltrack.web.cache} is enabled
 * and any unknown path falls through to {@code index.html} so client-side
 * routing works.</p>
 */
public final class StaticResourceHandler {

    private static final String CLASSPATH_ROOT = "web";
    private static final Path[] DEVELOPMENT_ROOTS = {
            Path.of("src", "main", "resources", "web"),
            Path.of("resources", "web"),
            Path.of("web")
    };

    private final Map<String, byte[]> cache = new ConcurrentHashMap<>();
    private final boolean cachingEnabled;

    public StaticResourceHandler(boolean cachingEnabled) {
        this.cachingEnabled = cachingEnabled;
    }

    public HttpResponse serve(String requestPath) {
        String resource = sanitise(requestPath);
        byte[] content = load(resource);
        if (content == null) {
            // Single-page-application fallback.
            content = load("index.html");
            resource = "index.html";
        }
        if (content == null) {
            return HttpResponse.text(HttpStatus.NOT_FOUND,
                    "WellTrack UI assets were not found on the classpath.", "text/plain; charset=utf-8");
        }
        HttpResponse response = HttpResponse.bytes(HttpStatus.OK, content, MimeTypes.forPath(resource));
        if (cachingEnabled && !resource.endsWith(".html")) {
            response.header("Cache-Control", "public, max-age=3600");
        } else {
            response.header("Cache-Control", "no-cache");
        }
        return response;
    }

    private byte[] load(String resource) {
        if (cachingEnabled) {
            byte[] cached = cache.get(resource);
            if (cached != null) {
                return cached;
            }
        }
        byte[] content = readFromFilesystem(resource);
        if (content == null) {
            content = readFromClasspath(resource);
        }
        if (content != null && cachingEnabled) {
            cache.put(resource, content);
        }
        return content;
    }

    private byte[] readFromFilesystem(String resource) {
        for (Path root : DEVELOPMENT_ROOTS) {
            Path candidate = root.resolve(resource).normalize();
            if (!candidate.startsWith(root)) {
                return null;
            }
            if (Files.isReadable(candidate) && !Files.isDirectory(candidate)) {
                try {
                    return Files.readAllBytes(candidate);
                } catch (IOException e) {
                    Log.warn("StaticResources", "Failed reading " + candidate + ": " + e.getMessage());
                }
            }
        }
        return null;
    }

    private byte[] readFromClasspath(String resource) {
        String location = CLASSPATH_ROOT + "/" + resource;
        try (InputStream in = getClass().getClassLoader().getResourceAsStream(location)) {
            if (in == null) {
                return null;
            }
            ByteArrayOutputStream buffer = new ByteArrayOutputStream();
            byte[] chunk = new byte[8192];
            int read;
            while ((read = in.read(chunk)) != -1) {
                buffer.write(chunk, 0, read);
            }
            return buffer.toByteArray();
        } catch (IOException e) {
            Log.warn("StaticResources", "Failed reading classpath resource " + location);
            return null;
        }
    }

    /** Blocks path traversal and normalises the request path to a resource name. */
    private String sanitise(String requestPath) {
        String value = requestPath == null ? "/" : requestPath;
        int question = value.indexOf('?');
        if (question >= 0) {
            value = value.substring(0, question);
        }
        value = java.net.URLDecoder.decode(value, StandardCharsets.UTF_8);
        value = value.replace('\\', '/');
        while (value.startsWith("/")) {
            value = value.substring(1);
        }
        if (value.isEmpty()) {
            value = "index.html";
        }
        if (value.contains("..")) {
            return "index.html";
        }
        return value;
    }

    public void clearCache() {
        cache.clear();
    }
}
