package com.welltrack.core.http;

/** The HTTP verbs handled by the WellTrack router. */
public enum HttpMethod {
    GET, POST, PUT, PATCH, DELETE, OPTIONS, HEAD;

    public static HttpMethod from(String raw) {
        if (raw == null) {
            return GET;
        }
        try {
            return valueOf(raw.trim().toUpperCase());
        } catch (IllegalArgumentException e) {
            return GET;
        }
    }
}
