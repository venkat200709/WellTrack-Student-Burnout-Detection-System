package com.welltrack.core.http;

import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpHandler;
import com.welltrack.core.json.Json;
import com.welltrack.core.json.JsonObject;
import com.welltrack.core.util.Log;
import com.welltrack.model.User;
import com.welltrack.security.AuthService;
import com.welltrack.service.EventBus;

import java.io.IOException;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.Map;
import java.util.concurrent.TimeUnit;

/**
 * Server-sent events endpoint — WellTrack's real-time push channel.
 *
 * <p>SSE is a deliberate choice over WebSockets here. The traffic is entirely
 * one-directional (server to browser), SSE runs over ordinary HTTP with no
 * upgrade handshake or extra dependency, and the browser's {@code EventSource}
 * reconnects automatically after a dropped connection. That gives live alerts,
 * risk updates and badge notifications for a fraction of the complexity.</p>
 *
 * <p>Because {@code EventSource} cannot attach an {@code Authorization} header,
 * the token is passed as a query parameter and verified exactly as it would be
 * on any other endpoint — the connection is rejected outright if it fails.</p>
 *
 * <p>A comment heartbeat is emitted every fifteen seconds so that intermediate
 * proxies do not close an idle connection.</p>
 */
public final class EventStreamHandler implements HttpHandler {

    private static final long HEARTBEAT_SECONDS = 15;
    private static final long MAX_CONNECTION_MINUTES = 30;

    private final AuthService authService;
    private final EventBus eventBus;

    public EventStreamHandler(AuthService authService, EventBus eventBus) {
        this.authService = authService;
        this.eventBus = eventBus;
    }

    @Override
    public void handle(HttpExchange exchange) throws IOException {
        Map<String, String> query = HttpRequest.parseQuery(exchange.getRequestURI().getRawQuery());
        User principal;
        try {
            principal = authService.authenticate(query.get("token"));
        } catch (RuntimeException e) {
            byte[] body = Json.write(JsonObject.of()
                    .set("success", false)
                    .set("message", "A valid token is required for the live stream"))
                    .getBytes(StandardCharsets.UTF_8);
            exchange.getResponseHeaders().set("Content-Type", "application/json");
            exchange.sendResponseHeaders(HttpStatus.UNAUTHORIZED.code(), body.length);
            try (OutputStream out = exchange.getResponseBody()) {
                out.write(body);
            }
            exchange.close();
            return;
        }

        exchange.getResponseHeaders().set("Content-Type", "text/event-stream; charset=utf-8");
        exchange.getResponseHeaders().set("Cache-Control", "no-cache, no-transform");
        exchange.getResponseHeaders().set("Connection", "keep-alive");
        exchange.getResponseHeaders().set("X-Accel-Buffering", "no");
        exchange.sendResponseHeaders(HttpStatus.OK.code(), 0);

        EventBus.Subscription subscription =
                eventBus.subscribe(principal.getId(), principal.getRole().name());
        long deadline = System.currentTimeMillis() + TimeUnit.MINUTES.toMillis(MAX_CONNECTION_MINUTES);

        try (OutputStream out = exchange.getResponseBody()) {
            write(out, "event: connected\ndata: " + Json.write(JsonObject.of()
                    .set("subscriptionId", subscription.id())
                    .set("user", principal.getUsername())
                    .set("role", principal.getRole().name())) + "\n\n");

            while (System.currentTimeMillis() < deadline) {
                JsonObject event = subscription.queue().poll(HEARTBEAT_SECONDS, TimeUnit.SECONDS);
                if (event == null) {
                    write(out, ": heartbeat\n\n");
                } else {
                    write(out, "event: " + event.getString("type", "message")
                            + "\ndata: " + Json.write(event) + "\n\n");
                }
            }
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        } catch (IOException e) {
            // The browser navigated away or refreshed; this is entirely normal.
            Log.info("EventStream", "Client " + subscription.id() + " closed the connection");
        } finally {
            eventBus.unsubscribe(subscription.id());
            exchange.close();
        }
    }

    private void write(OutputStream out, String payload) throws IOException {
        out.write(payload.getBytes(StandardCharsets.UTF_8));
        out.flush();
    }
}
