package com.welltrack.core.json;

import java.lang.reflect.Array;
import java.util.Collection;
import java.util.Map;

/**
 * Facade for WellTrack's zero-dependency JSON engine.
 *
 * <p>The whole serialisation stack — lexer, recursive-descent parser and
 * writer — is implemented by hand inside this package. No third-party library
 * is used anywhere in WellTrack, which keeps the project runnable with nothing
 * but a JDK installation.</p>
 *
 * <pre>{@code
 * Object tree   = Json.parse("{\"risk\":72.4}");
 * String encoded = Json.write(JsonObject.of("risk", 72.4));
 * }</pre>
 */
public final class Json {

    private Json() {
        throw new AssertionError("Json is a static utility and must not be instantiated");
    }

    /** Parses JSON text into {@link JsonObject}, {@link JsonArray}, String, Double, Boolean or null. */
    public static Object parse(String text) {
        return new JsonParser(text).parseDocument();
    }

    /** Parses JSON text that is expected to describe an object. */
    public static JsonObject parseObject(String text) {
        Object parsed = parse(text);
        if (parsed instanceof JsonObject object) {
            return object;
        }
        throw new JsonException("Expected a JSON object but found: "
                + (parsed == null ? "null" : parsed.getClass().getSimpleName()));
    }

    /** Parses JSON text that is expected to describe an array. */
    public static JsonArray parseArray(String text) {
        Object parsed = parse(text);
        if (parsed instanceof JsonArray array) {
            return array;
        }
        throw new JsonException("Expected a JSON array");
    }

    /** Serialises any supported value to compact JSON text. */
    public static String write(Object value) {
        StringBuilder out = new StringBuilder(256);
        writeValue(value, out, false, 0);
        return out.toString();
    }

    /** Serialises with two-space indentation — used for config dumps and logs. */
    public static String writePretty(Object value) {
        StringBuilder out = new StringBuilder(512);
        writeValue(value, out, true, 0);
        return out.toString();
    }

    private static void writeValue(Object value, StringBuilder out, boolean pretty, int depth) {
        if (value == null) {
            out.append("null");
        } else if (value instanceof String s) {
            writeString(s, out);
        } else if (value instanceof Boolean b) {
            out.append(b.booleanValue());
        } else if (value instanceof Double || value instanceof Float) {
            double d = ((Number) value).doubleValue();
            if (Double.isNaN(d) || Double.isInfinite(d)) {
                out.append("null");
            } else if (d == Math.rint(d) && Math.abs(d) < 1e15) {
                out.append((long) d);
            } else {
                out.append(Math.round(d * 1_000_000d) / 1_000_000d);
            }
        } else if (value instanceof Number n) {
            out.append(n);
        } else if (value instanceof Map<?, ?> map) {
            writeMap(map, out, pretty, depth);
        } else if (value instanceof Collection<?> collection) {
            writeCollection(collection, out, pretty, depth);
        } else if (value.getClass().isArray()) {
            writeJavaArray(value, out, pretty, depth);
        } else if (value instanceof Enum<?> e) {
            writeString(e.name(), out);
        } else if (value instanceof JsonSerializable serializable) {
            writeValue(serializable.toJson(), out, pretty, depth);
        } else {
            writeString(String.valueOf(value), out);
        }
    }

    private static void writeMap(Map<?, ?> map, StringBuilder out, boolean pretty, int depth) {
        out.append('{');
        boolean first = true;
        for (Map.Entry<?, ?> entry : map.entrySet()) {
            if (!first) {
                out.append(',');
            }
            first = false;
            newline(out, pretty, depth + 1);
            writeString(String.valueOf(entry.getKey()), out);
            out.append(':');
            if (pretty) {
                out.append(' ');
            }
            writeValue(entry.getValue(), out, pretty, depth + 1);
        }
        if (!first) {
            newline(out, pretty, depth);
        }
        out.append('}');
    }

    private static void writeCollection(Collection<?> collection, StringBuilder out, boolean pretty, int depth) {
        out.append('[');
        boolean first = true;
        for (Object item : collection) {
            if (!first) {
                out.append(',');
            }
            first = false;
            newline(out, pretty, depth + 1);
            writeValue(item, out, pretty, depth + 1);
        }
        if (!first) {
            newline(out, pretty, depth);
        }
        out.append(']');
    }

    private static void writeJavaArray(Object array, StringBuilder out, boolean pretty, int depth) {
        int length = Array.getLength(array);
        out.append('[');
        for (int i = 0; i < length; i++) {
            if (i > 0) {
                out.append(',');
            }
            newline(out, pretty, depth + 1);
            writeValue(Array.get(array, i), out, pretty, depth + 1);
        }
        if (length > 0) {
            newline(out, pretty, depth);
        }
        out.append(']');
    }

    private static void newline(StringBuilder out, boolean pretty, int depth) {
        if (!pretty) {
            return;
        }
        out.append('\n');
        out.append("  ".repeat(Math.max(0, depth)));
    }

    /** Escapes and quotes a string according to RFC 8259. */
    static void writeString(String value, StringBuilder out) {
        out.append('"');
        for (int i = 0; i < value.length(); i++) {
            char c = value.charAt(i);
            switch (c) {
                case '"' -> out.append("\\\"");
                case '\\' -> out.append("\\\\");
                case '\n' -> out.append("\\n");
                case '\r' -> out.append("\\r");
                case '\t' -> out.append("\\t");
                case '\b' -> out.append("\\b");
                case '\f' -> out.append("\\f");
                default -> {
                    if (c < 0x20 || c == 0x7F) {
                        out.append(String.format("\\u%04x", (int) c));
                    } else {
                        out.append(c);
                    }
                }
            }
        }
        out.append('"');
    }
}
