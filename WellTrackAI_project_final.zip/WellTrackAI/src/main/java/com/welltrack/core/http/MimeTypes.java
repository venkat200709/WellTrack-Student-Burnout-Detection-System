package com.welltrack.core.http;

import java.util.Map;

/** Maps file extensions to content types for the static resource handler. */
public final class MimeTypes {

    private static final Map<String, String> TYPES = Map.ofEntries(
            Map.entry("html", "text/html; charset=utf-8"),
            Map.entry("css", "text/css; charset=utf-8"),
            Map.entry("js", "application/javascript; charset=utf-8"),
            Map.entry("json", "application/json; charset=utf-8"),
            Map.entry("svg", "image/svg+xml"),
            Map.entry("png", "image/png"),
            Map.entry("jpg", "image/jpeg"),
            Map.entry("jpeg", "image/jpeg"),
            Map.entry("gif", "image/gif"),
            Map.entry("ico", "image/x-icon"),
            Map.entry("woff", "font/woff"),
            Map.entry("woff2", "font/woff2"),
            Map.entry("ttf", "font/ttf"),
            Map.entry("csv", "text/csv; charset=utf-8"),
            Map.entry("txt", "text/plain; charset=utf-8"),
            Map.entry("pdf", "application/pdf"));

    private MimeTypes() {
    }

    public static String forPath(String path) {
        int dot = path.lastIndexOf('.');
        if (dot < 0 || dot == path.length() - 1) {
            return "application/octet-stream";
        }
        return TYPES.getOrDefault(path.substring(dot + 1).toLowerCase(), "application/octet-stream");
    }
}
