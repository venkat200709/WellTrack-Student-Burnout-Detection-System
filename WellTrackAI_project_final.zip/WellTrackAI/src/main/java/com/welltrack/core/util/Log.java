package com.welltrack.core.util;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * A tiny, dependency-free, ANSI-coloured logger.
 *
 * <p>WellTrack deliberately avoids SLF4J/Log4J so the project can be dropped
 * onto any machine with only a JDK. Output is thread-safe and includes the
 * emitting thread, which makes the concurrent analysis pipeline easy to trace
 * during a live demonstration.</p>
 */
public final class Log {

    private static final DateTimeFormatter TIME = DateTimeFormatter.ofPattern("HH:mm:ss.SSS");
    private static final AtomicBoolean COLOUR = new AtomicBoolean(!isWindowsLegacyConsole());
    private static final Object LOCK = new Object();

    private static final String RESET = "\033[0m";
    private static final String GREY = "\033[90m";
    private static final String CYAN = "\033[36m";
    private static final String GREEN = "\033[32m";
    private static final String YELLOW = "\033[33m";
    private static final String RED = "\033[31m";
    private static final String MAGENTA = "\033[35m";

    private Log() {
    }

    public static void setColourEnabled(boolean enabled) {
        COLOUR.set(enabled);
    }

    public static void banner(String text) {
        synchronized (LOCK) {
            System.out.println(paint(MAGENTA, text));
        }
    }

    public static void info(String source, String message) {
        write("INFO ", CYAN, source, message);
    }

    public static void success(String source, String message) {
        write("OK   ", GREEN, source, message);
    }

    public static void warn(String source, String message) {
        write("WARN ", YELLOW, source, message);
    }

    public static void error(String source, String message) {
        write("ERROR", RED, source, message);
    }

    public static void error(String source, String message, Throwable throwable) {
        write("ERROR", RED, source, message + " :: " + throwable);
        for (StackTraceElement element : throwable.getStackTrace()) {
            if (element.getClassName().startsWith("com.welltrack")) {
                write("     ", RED, source, "    at " + element);
            }
        }
    }

    private static void write(String level, String colour, String source, String message) {
        String line = "%s %s %s %s"
                .formatted(paint(GREY, LocalDateTime.now().format(TIME)),
                        paint(colour, level),
                        paint(GREY, "[" + trim(source, 22) + "]"),
                        message);
        synchronized (LOCK) {
            System.out.println(line);
        }
    }

    private static String trim(String value, int width) {
        if (value.length() >= width) {
            return value.substring(0, width);
        }
        return value + " ".repeat(width - value.length());
    }

    private static String paint(String colour, String text) {
        return COLOUR.get() ? colour + text + RESET : text;
    }

    private static boolean isWindowsLegacyConsole() {
        String os = System.getProperty("os.name", "").toLowerCase();
        return os.contains("win") && System.getenv("WT_SESSION") == null
                && System.getenv("TERM") == null;
    }
}
