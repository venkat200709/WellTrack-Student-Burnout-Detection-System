package com.welltrack.core.http;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * A compiled route: an HTTP verb, a path template that may contain
 * {@code {variable}} segments, the handler, and the roles allowed to invoke it.
 *
 * <p>Matching is performed segment by segment rather than with a regular
 * expression, which keeps it allocation-light and O(segments).</p>
 */
public final class Route {

    private final HttpMethod method;
    private final String template;
    private final String[] segments;
    private final RouteHandler handler;
    private final Set<String> allowedRoles;
    private final boolean authenticated;

    Route(HttpMethod method, String template, RouteHandler handler,
          boolean authenticated, Set<String> allowedRoles) {
        this.method = method;
        this.template = normalise(template);
        this.segments = split(this.template);
        this.handler = handler;
        this.authenticated = authenticated;
        this.allowedRoles = allowedRoles;
    }

    /**
     * Attempts to match a concrete request path.
     *
     * @return the extracted path variables, or {@code null} when this route
     *         does not describe the given path.
     */
    Map<String, String> match(String path) {
        String[] parts = split(normalise(path));
        if (parts.length != segments.length) {
            return null;
        }
        Map<String, String> variables = new LinkedHashMap<>();
        for (int i = 0; i < segments.length; i++) {
            String segment = segments[i];
            if (segment.startsWith("{") && segment.endsWith("}")) {
                variables.put(segment.substring(1, segment.length() - 1), parts[i]);
            } else if (!segment.equalsIgnoreCase(parts[i])) {
                return null;
            }
        }
        return variables;
    }

    private static String normalise(String path) {
        String value = path == null ? "/" : path.trim();
        if (!value.startsWith("/")) {
            value = "/" + value;
        }
        while (value.length() > 1 && value.endsWith("/")) {
            value = value.substring(0, value.length() - 1);
        }
        return value;
    }

    private static String[] split(String path) {
        List<String> parts = new ArrayList<>();
        for (String part : path.split("/")) {
            if (!part.isEmpty()) {
                parts.add(part);
            }
        }
        return parts.toArray(new String[0]);
    }

    public HttpMethod method() {
        return method;
    }

    public String template() {
        return template;
    }

    public RouteHandler handler() {
        return handler;
    }

    public boolean authenticated() {
        return authenticated;
    }

    public Set<String> allowedRoles() {
        return allowedRoles;
    }

    @Override
    public String toString() {
        return method + " " + template;
    }
}
