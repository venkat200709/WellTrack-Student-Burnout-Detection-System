package com.welltrack.core.http;

import com.welltrack.core.util.Log;

/**
 * Cross-cutting filters applied to every request.
 *
 * <p>Composing behaviour as filters rather than base-class inheritance keeps
 * each concern independent and independently testable — the open/closed
 * principle applied to the transport layer.</p>
 */
public final class CommonFilters {

    private CommonFilters() {
    }

    /**
     * Handles CORS pre-flight and attaches the permissive headers needed when
     * the UI is opened from a different origin during development.
     */
    public static Filter cors() {
        return (request, chain) -> {
            if (request.method() == HttpMethod.OPTIONS) {
                return HttpResponse.text(HttpStatus.NO_CONTENT, "", "text/plain")
                        .header("Access-Control-Allow-Origin", "*")
                        .header("Access-Control-Allow-Methods", "GET, POST, PUT, PATCH, DELETE, OPTIONS")
                        .header("Access-Control-Allow-Headers", "Content-Type, Authorization")
                        .header("Access-Control-Max-Age", "86400");
            }
            return chain.proceed(request)
                    .header("Access-Control-Allow-Origin", "*")
                    .header("Access-Control-Expose-Headers", "Content-Disposition");
        };
    }

    /** Rejects oversized bodies before any parsing work is attempted. */
    public static Filter payloadLimit(int maxBytes) {
        return (request, chain) -> {
            if (request.body().length() > maxBytes) {
                Log.warn("PayloadLimit", "Rejected a " + request.body().length() + " byte body");
                return HttpResponse.error(HttpStatus.BAD_REQUEST,
                        "Request body exceeds the " + (maxBytes / 1024) + " KB limit");
            }
            return chain.proceed(request);
        };
    }

    /** Adds a correlation id so a request can be traced through the logs. */
    public static Filter correlationId() {
        return (request, chain) -> {
            String id = com.welltrack.core.util.Ids.shortCode(8);
            return chain.proceed(request).header("X-Request-Id", id);
        };
    }
}
