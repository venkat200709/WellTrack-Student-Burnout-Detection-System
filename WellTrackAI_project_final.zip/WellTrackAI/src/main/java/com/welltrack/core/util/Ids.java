package com.welltrack.core.util;

import java.security.SecureRandom;
import java.util.concurrent.atomic.AtomicLong;

/**
 * Identifier generation utilities.
 *
 * <p>Provides monotonically increasing numeric ids for entities (readable in a
 * demo) and cryptographically strong opaque ids for security artefacts such as
 * refresh tokens and session handles.</p>
 */
public final class Ids {

    private static final SecureRandom RANDOM = new SecureRandom();
    private static final char[] ALPHABET = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789".toCharArray();
    private static final AtomicLong SEQUENCE = new AtomicLong(System.currentTimeMillis());

    private Ids() {
    }

    /** @return a short, human-friendly, collision-resistant code such as {@code K7QF2M9X}. */
    public static String shortCode(int length) {
        StringBuilder builder = new StringBuilder(length);
        for (int i = 0; i < length; i++) {
            builder.append(ALPHABET[RANDOM.nextInt(ALPHABET.length)]);
        }
        return builder.toString();
    }

    /** @return 256 bits of entropy encoded as lowercase hexadecimal. */
    public static String secureToken() {
        byte[] bytes = new byte[32];
        RANDOM.nextBytes(bytes);
        StringBuilder builder = new StringBuilder(bytes.length * 2);
        for (byte b : bytes) {
            builder.append(Character.forDigit((b >> 4) & 0xF, 16));
            builder.append(Character.forDigit(b & 0xF, 16));
        }
        return builder.toString();
    }

    /** @return a process-unique increasing number, useful for surrogate keys. */
    public static long nextSequence() {
        return SEQUENCE.incrementAndGet();
    }
}
