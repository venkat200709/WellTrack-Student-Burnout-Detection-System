package com.welltrack.core.util;

import java.util.Collection;

/** Small numeric helpers shared by the analytics and AI layers. */
public final class Numbers {

    private Numbers() {
    }

    public static double clamp(double value, double min, double max) {
        return Math.max(min, Math.min(max, value));
    }

    public static double round(double value, int decimals) {
        double factor = Math.pow(10, decimals);
        return Math.round(value * factor) / factor;
    }

    public static double mean(double[] values) {
        if (values == null || values.length == 0) {
            return 0;
        }
        double sum = 0;
        for (double v : values) {
            sum += v;
        }
        return sum / values.length;
    }

    public static double mean(Collection<Double> values) {
        if (values == null || values.isEmpty()) {
            return 0;
        }
        double sum = 0;
        for (double v : values) {
            sum += v;
        }
        return sum / values.size();
    }

    public static double standardDeviation(double[] values) {
        if (values == null || values.length < 2) {
            return 0;
        }
        double mean = mean(values);
        double sum = 0;
        for (double v : values) {
            sum += (v - mean) * (v - mean);
        }
        return Math.sqrt(sum / (values.length - 1));
    }

    public static double median(double[] values) {
        if (values == null || values.length == 0) {
            return 0;
        }
        double[] copy = values.clone();
        java.util.Arrays.sort(copy);
        int mid = copy.length / 2;
        return copy.length % 2 == 0 ? (copy[mid - 1] + copy[mid]) / 2.0 : copy[mid];
    }

    /** Percentage change from {@code previous} to {@code current}, guarded against divide-by-zero. */
    public static double percentageChange(double previous, double current) {
        if (Math.abs(previous) < 1e-9) {
            return current == 0 ? 0 : 100;
        }
        return ((current - previous) / Math.abs(previous)) * 100.0;
    }

    /** Least-squares slope of the series against its index — the trend direction. */
    public static double slope(double[] series) {
        int n = series.length;
        if (n < 2) {
            return 0;
        }
        double meanX = (n - 1) / 2.0;
        double meanY = mean(series);
        double numerator = 0;
        double denominator = 0;
        for (int i = 0; i < n; i++) {
            numerator += (i - meanX) * (series[i] - meanY);
            denominator += (i - meanX) * (i - meanX);
        }
        return denominator == 0 ? 0 : numerator / denominator;
    }
}
