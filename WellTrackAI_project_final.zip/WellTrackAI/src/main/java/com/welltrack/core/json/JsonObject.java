package com.welltrack.core.json;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * An ordered, fluent JSON object. Extends {@link LinkedHashMap} so it can be
 * consumed by any {@code Map}-aware code while still offering a chainable,
 * type-safe building API.
 *
 * <p>Part of WellTrack's hand-written, zero-dependency JSON engine.</p>
 */
public final class JsonObject extends LinkedHashMap<String, Object> {

    private static final long serialVersionUID = 1L;

    public JsonObject() {
        super();
    }

    public JsonObject(Map<String, ?> source) {
        super();
        if (source != null) {
            putAll(source);
        }
    }

    /** Static factory for fluent construction: {@code JsonObject.of().set("a", 1)}. */
    public static JsonObject of() {
        return new JsonObject();
    }

    /** Convenience single-entry factory. */
    public static JsonObject of(String key, Object value) {
        return new JsonObject().set(key, value);
    }

    /** Fluent put. Returns {@code this} so calls can be chained. */
    public JsonObject set(String key, Object value) {
        put(key, value);
        return this;
    }

    /** Puts the value only when it is non-null; keeps payloads compact. */
    public JsonObject setIfPresent(String key, Object value) {
        if (value != null) {
            put(key, value);
        }
        return this;
    }

    public String getString(String key, String fallback) {
        Object v = get(key);
        return v == null ? fallback : String.valueOf(v);
    }

    public String getString(String key) {
        return getString(key, null);
    }

    public double getDouble(String key, double fallback) {
        Object v = get(key);
        if (v instanceof Number n) {
            return n.doubleValue();
        }
        if (v instanceof String s && !s.isBlank()) {
            try {
                return Double.parseDouble(s.trim());
            } catch (NumberFormatException ignored) {
                return fallback;
            }
        }
        return fallback;
    }

    public int getInt(String key, int fallback) {
        return (int) Math.round(getDouble(key, fallback));
    }

    public long getLong(String key, long fallback) {
        return Math.round(getDouble(key, fallback));
    }

    public boolean getBoolean(String key, boolean fallback) {
        Object v = get(key);
        if (v instanceof Boolean b) {
            return b;
        }
        if (v instanceof String s) {
            return Boolean.parseBoolean(s);
        }
        return fallback;
    }

    @SuppressWarnings("unchecked")
    public JsonObject getObject(String key) {
        Object v = get(key);
        if (v instanceof JsonObject o) {
            return o;
        }
        if (v instanceof Map<?, ?> m) {
            return new JsonObject((Map<String, ?>) m);
        }
        return null;
    }

    public JsonArray getArray(String key) {
        Object v = get(key);
        if (v instanceof JsonArray a) {
            return a;
        }
        if (v instanceof List<?> l) {
            JsonArray array = new JsonArray();
            array.addAll(new ArrayList<>(l));
            return array;
        }
        return null;
    }

    public boolean has(String key) {
        return containsKey(key) && get(key) != null;
    }

    @Override
    public String toString() {
        return Json.write(this);
    }
}
