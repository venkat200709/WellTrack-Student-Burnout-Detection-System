package com.welltrack.core.util;

import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Locale;
import java.util.Properties;

/**
 * Immutable application configuration, resolved once at boot time.
 *
 * <p>Resolution order (highest priority first):</p>
 * <ol>
 *   <li>JVM system properties — {@code -Dwelltrack.port=9090}</li>
 *   <li>Environment variables — {@code WELLTRACK_PORT=9090}</li>
 *   <li>{@code config/application.properties} next to the working directory</li>
 *   <li>{@code application.properties} bundled on the classpath</li>
 *   <li>Hard-coded defaults</li>
 * </ol>
 *
 * <p>Because every layer is optional, WellTrack starts with zero configuration
 * on a clean machine, yet is fully tunable in a lab or server deployment.</p>
 */
public final class AppConfig {

    private static final String PREFIX = "welltrack.";
    private static final AppConfig INSTANCE = new AppConfig();

    private final Properties properties = new Properties();

    private AppConfig() {
        loadClasspath("application.properties");
        loadFile(Path.of("config", "application.properties"));
        loadFile(Path.of("application.properties"));
    }

    public static AppConfig get() {
        return INSTANCE;
    }

    private void loadClasspath(String resource) {
        try (InputStream in = AppConfig.class.getClassLoader().getResourceAsStream(resource)) {
            if (in != null) {
                properties.load(in);
            }
        } catch (IOException e) {
            Log.warn("AppConfig", "Could not read classpath config: " + e.getMessage());
        }
    }

    private void loadFile(Path path) {
        if (!Files.isReadable(path)) {
            return;
        }
        try (InputStream in = Files.newInputStream(path)) {
            properties.load(in);
            Log.info("AppConfig", "Loaded overrides from " + path.toAbsolutePath());
        } catch (IOException e) {
            Log.warn("AppConfig", "Could not read " + path + ": " + e.getMessage());
        }
    }

    /** @return the configured string value, or {@code fallback} when unset. */
    public String string(String key, String fallback) {
        String systemProperty = System.getProperty(PREFIX + key);
        if (isPresent(systemProperty)) {
            return systemProperty.trim();
        }
        String environment = System.getenv(envName(key));
        if (isPresent(environment)) {
            return environment.trim();
        }
        String fileValue = properties.getProperty(key);
        return isPresent(fileValue) ? fileValue.trim() : fallback;
    }

    public int integer(String key, int fallback) {
        try {
            return Integer.parseInt(string(key, String.valueOf(fallback)));
        } catch (NumberFormatException e) {
            Log.warn("AppConfig", "Value for '" + key + "' is not an integer; using " + fallback);
            return fallback;
        }
    }

    public double number(String key, double fallback) {
        try {
            return Double.parseDouble(string(key, String.valueOf(fallback)));
        } catch (NumberFormatException e) {
            return fallback;
        }
    }

    public boolean flag(String key, boolean fallback) {
        return Boolean.parseBoolean(string(key, String.valueOf(fallback)));
    }

    private static boolean isPresent(String value) {
        return value != null && !value.isBlank();
    }

    private static String envName(String key) {
        return (PREFIX + key).toUpperCase(Locale.ROOT).replace('.', '_');
    }
}
