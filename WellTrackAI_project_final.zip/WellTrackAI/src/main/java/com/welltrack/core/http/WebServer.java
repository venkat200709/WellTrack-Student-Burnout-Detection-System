package com.welltrack.core.http;

import com.sun.net.httpserver.Headers;
import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpServer;
import com.welltrack.core.json.JsonException;
import com.welltrack.core.json.JsonObject;
import com.welltrack.core.util.Log;
import com.welltrack.exception.ApiException;
import com.welltrack.exception.ValidationException;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.InetSocketAddress;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicLong;

/**
 * WellTrack's embedded HTTP server.
 *
 * <p>Built directly on the JDK's {@code com.sun.net.httpserver} stack, so the
 * whole application runs with nothing but a Java installation — no servlet
 * container, no external framework, no downloaded jars.</p>
 *
 * <p>Requests are dispatched on a bounded thread pool; a filter chain wraps
 * every request, and unhandled exceptions are translated into structured JSON
 * error payloads rather than stack traces.</p>
 */
public final class WebServer {

    private final int port;
    private final Router router;
    private final StaticResourceHandler staticResources;
    private final List<Filter> filters = new ArrayList<>();
    private final Map<String, com.sun.net.httpserver.HttpHandler> rawContexts = new LinkedHashMap<>();
    private final ExecutorService workers;
    private final AtomicLong requestCounter = new AtomicLong();
    private final AtomicLong errorCounter = new AtomicLong();
    private final long startedAt = System.currentTimeMillis();

    private HttpServer server;

    public WebServer(int port, int threads, Router router, StaticResourceHandler staticResources) {
        this.port = port;
        this.router = router;
        this.staticResources = staticResources;
        this.workers = Executors.newFixedThreadPool(threads, namedThreadFactory());
    }

    public WebServer addFilter(Filter filter) {
        filters.add(filter);
        return this;
    }

    /**
     * Registers a handler that bypasses the router and filter chain.
     *
     * <p>Used for protocols the request/response abstraction cannot express —
     * specifically the server-sent-events stream, which holds its connection
     * open and writes incrementally.</p>
     */
    public WebServer addRawContext(String path, com.sun.net.httpserver.HttpHandler handler) {
        rawContexts.put(path, handler);
        return this;
    }

    /** Binds the socket and begins accepting connections. */
    public void start() throws IOException {
        server = HttpServer.create(new InetSocketAddress(port), 0);
        rawContexts.forEach((path, handler) -> server.createContext(path, handler));
        server.createContext("/", this::dispatch);
        server.setExecutor(workers);
        server.start();
        Log.success("WebServer", "Listening on http://localhost:" + port);
    }

    /** Gracefully drains in-flight requests and releases the socket. */
    public void stop() {
        if (server != null) {
            server.stop(1);
        }
        workers.shutdown();
        try {
            if (!workers.awaitTermination(5, TimeUnit.SECONDS)) {
                workers.shutdownNow();
            }
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            workers.shutdownNow();
        }
        Log.info("WebServer", "Stopped after serving " + requestCounter.get() + " requests");
    }

    private void dispatch(HttpExchange exchange) {
        long started = System.nanoTime();
        HttpRequest request = null;
        HttpResponse response;
        try {
            request = readRequest(exchange);
            response = runFilters(request);
        } catch (Exception e) {
            errorCounter.incrementAndGet();
            Log.error("WebServer", "Unhandled failure while dispatching", e);
            response = HttpResponse.error(HttpStatus.SERVER_ERROR, "Unexpected server error");
        }
        try {
            write(exchange, response);
        } catch (IOException e) {
            Log.warn("WebServer", "Client disconnected before the response was written");
        } finally {
            exchange.close();
            requestCounter.incrementAndGet();
            if (request != null && request.path().startsWith("/api")) {
                long micros = (System.nanoTime() - started) / 1000;
                Log.info("WebServer", "%-6s %-42s -> %d  (%.2f ms)".formatted(
                        request.method(), request.path(), response.status().code(), micros / 1000.0));
            }
        }
    }

    private HttpResponse runFilters(HttpRequest request) throws Exception {
        FilterChain chain = this::route;
        for (int i = filters.size() - 1; i >= 0; i--) {
            Filter filter = filters.get(i);
            FilterChain next = chain;
            chain = req -> filter.apply(req, next);
        }
        return chain.proceed(request);
    }

    private HttpResponse route(HttpRequest request) {
        if (!request.path().startsWith("/api")) {
            return staticResources.serve(request.path());
        }
        Optional<Route> match = router.resolve(request);
        if (match.isEmpty()) {
            if (router.pathExists(request.path())) {
                return HttpResponse.error(HttpStatus.METHOD_NOT_ALLOWED,
                        request.method() + " is not supported for " + request.path());
            }
            return HttpResponse.error(HttpStatus.NOT_FOUND, "No API endpoint matches " + request.path());
        }
        try {
            return match.get().handler().handle(request);
        } catch (ValidationException e) {
            return HttpResponse.json(HttpStatus.UNPROCESSABLE, JsonObject.of()
                    .set("success", false)
                    .set("status", HttpStatus.UNPROCESSABLE.code())
                    .set("message", e.getMessage())
                    .set("fieldErrors", new JsonObject(e.fieldErrors())));
        } catch (ApiException e) {
            return HttpResponse.error(e.status(), e.getMessage());
        } catch (JsonException e) {
            return HttpResponse.error(HttpStatus.BAD_REQUEST, "Malformed JSON payload: " + e.getMessage());
        } catch (IllegalArgumentException e) {
            return HttpResponse.error(HttpStatus.BAD_REQUEST, e.getMessage());
        } catch (Exception e) {
            errorCounter.incrementAndGet();
            Log.error("WebServer", "Handler " + match.get() + " failed", e);
            return HttpResponse.error(HttpStatus.SERVER_ERROR, "The server could not complete the request");
        }
    }

    private HttpRequest readRequest(HttpExchange exchange) throws IOException {
        Map<String, String> headers = new LinkedHashMap<>();
        for (Map.Entry<String, List<String>> entry : exchange.getRequestHeaders().entrySet()) {
            if (!entry.getValue().isEmpty()) {
                headers.put(entry.getKey().toLowerCase(), entry.getValue().get(0));
            }
        }
        String body;
        try (InputStream in = exchange.getRequestBody()) {
            body = new String(in.readAllBytes(), StandardCharsets.UTF_8);
        }
        String remote = exchange.getRemoteAddress() == null
                ? "unknown"
                : exchange.getRemoteAddress().getAddress().getHostAddress();
        return new HttpRequest(
                HttpMethod.from(exchange.getRequestMethod()),
                exchange.getRequestURI().getPath(),
                headers,
                HttpRequest.parseQuery(exchange.getRequestURI().getRawQuery()),
                body,
                remote);
    }

    private void write(HttpExchange exchange, HttpResponse response) throws IOException {
        Headers headers = exchange.getResponseHeaders();
        headers.set("Content-Type", response.contentType());
        headers.set("X-Content-Type-Options", "nosniff");
        headers.set("X-Frame-Options", "SAMEORIGIN");
        headers.set("Referrer-Policy", "no-referrer");
        response.headers().forEach(headers::set);

        byte[] payload = response.payload();
        int code = response.status().code();
        if (code == HttpStatus.NO_CONTENT.code() || payload.length == 0) {
            exchange.sendResponseHeaders(code, -1);
            return;
        }
        exchange.sendResponseHeaders(code, payload.length);
        try (OutputStream out = exchange.getResponseBody()) {
            out.write(payload);
        }
    }

    private static ThreadFactory namedThreadFactory() {
        AtomicInteger counter = new AtomicInteger();
        return runnable -> {
            Thread thread = new Thread(runnable, "welltrack-http-" + counter.incrementAndGet());
            thread.setDaemon(false);
            return thread;
        };
    }

    public JsonObject metrics() {
        return JsonObject.of()
                .set("requests", requestCounter.get())
                .set("errors", errorCounter.get())
                .set("uptimeSeconds", (System.currentTimeMillis() - startedAt) / 1000)
                .set("port", port);
    }
}
