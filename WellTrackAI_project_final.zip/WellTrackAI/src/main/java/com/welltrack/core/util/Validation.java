package com.welltrack.core.util;

import com.welltrack.exception.ValidationException;

import java.time.LocalDate;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.regex.Pattern;

/**
 * Fluent, fail-slow input validator.
 *
 * <p>Unlike a fail-fast guard clause, this collector gathers <em>every</em>
 * violation before throwing, so the user interface can highlight all offending
 * fields in a single round trip. This is the backbone of WellTrack's login and
 * registration validation.</p>
 *
 * <pre>{@code
 * Validation.check()
 *     .required("email", email)
 *     .email("email", email)
 *     .minLength("password", password, 8)
 *     .throwIfInvalid();
 * }</pre>
 */
public final class Validation {

    private static final Pattern EMAIL =
            Pattern.compile("^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}$");
    private static final Pattern USERNAME = Pattern.compile("^[A-Za-z0-9._-]{4,24}$");
    private static final Pattern REGISTER_NUMBER = Pattern.compile("^[A-Za-z0-9]{6,20}$");
    private static final Pattern DIGIT = Pattern.compile(".*\\d.*");
    private static final Pattern UPPER = Pattern.compile(".*[A-Z].*");
    private static final Pattern LOWER = Pattern.compile(".*[a-z].*");
    private static final Pattern SPECIAL = Pattern.compile(".*[^A-Za-z0-9].*");

    private final Map<String, String> errors = new LinkedHashMap<>();

    private Validation() {
    }

    public static Validation check() {
        return new Validation();
    }

    public Validation required(String field, Object value) {
        if (value == null || String.valueOf(value).isBlank()) {
            reject(field, "%s is required".formatted(label(field)));
        }
        return this;
    }

    public Validation minLength(String field, String value, int min) {
        if (value != null && value.length() < min) {
            reject(field, "%s must be at least %d characters".formatted(label(field), min));
        }
        return this;
    }

    public Validation maxLength(String field, String value, int max) {
        if (value != null && value.length() > max) {
            reject(field, "%s must be at most %d characters".formatted(label(field), max));
        }
        return this;
    }

    public Validation email(String field, String value) {
        if (value != null && !value.isBlank() && !EMAIL.matcher(value).matches()) {
            reject(field, "Enter a valid email address");
        }
        return this;
    }

    public Validation username(String field, String value) {
        if (value != null && !value.isBlank() && !USERNAME.matcher(value).matches()) {
            reject(field, "Username must be 4-24 characters (letters, digits, dot, dash, underscore)");
        }
        return this;
    }

    public Validation registerNumber(String field, String value) {
        if (value != null && !value.isBlank() && !REGISTER_NUMBER.matcher(value).matches()) {
            reject(field, "Register number must be 6-20 alphanumeric characters");
        }
        return this;
    }

    /**
     * Enforces WellTrack's password policy: at least eight characters with an
     * uppercase letter, a lowercase letter and a digit. A special character
     * earns extra strength but is not mandatory.
     */
    public Validation password(String field, String value) {
        if (value == null || value.isBlank()) {
            return this;
        }
        if (value.length() < 8) {
            reject(field, "Password must be at least 8 characters long");
        } else if (!UPPER.matcher(value).matches()) {
            reject(field, "Password must contain an uppercase letter");
        } else if (!LOWER.matcher(value).matches()) {
            reject(field, "Password must contain a lowercase letter");
        } else if (!DIGIT.matcher(value).matches()) {
            reject(field, "Password must contain a digit");
        }
        return this;
    }

    public Validation matches(String field, String value, String other, String message) {
        if (value != null && !value.equals(other)) {
            reject(field, message);
        }
        return this;
    }

    public Validation range(String field, double value, double min, double max) {
        if (value < min || value > max) {
            reject(field, "%s must be between %s and %s".formatted(label(field), format(min), format(max)));
        }
        return this;
    }

    public Validation notFuture(String field, LocalDate date) {
        if (date != null && date.isAfter(LocalDate.now())) {
            reject(field, "%s cannot be in the future".formatted(label(field)));
        }
        return this;
    }

    public Validation rejectIf(boolean condition, String field, String message) {
        if (condition) {
            reject(field, message);
        }
        return this;
    }

    private void reject(String field, String message) {
        errors.putIfAbsent(field, message);
    }

    public boolean isValid() {
        return errors.isEmpty();
    }

    public Map<String, String> errors() {
        return Map.copyOf(errors);
    }

    /** Throws a {@link ValidationException} carrying every collected violation. */
    public void throwIfInvalid() {
        if (!errors.isEmpty()) {
            throw new ValidationException("Please correct the highlighted fields", errors);
        }
    }

    /** Scores password strength from 0 (weak) to 100 (excellent) for the UI meter. */
    public static int passwordStrength(String password) {
        if (password == null || password.isEmpty()) {
            return 0;
        }
        int score = Math.min(40, password.length() * 4);
        if (UPPER.matcher(password).matches()) {
            score += 15;
        }
        if (LOWER.matcher(password).matches()) {
            score += 10;
        }
        if (DIGIT.matcher(password).matches()) {
            score += 15;
        }
        if (SPECIAL.matcher(password).matches()) {
            score += 20;
        }
        if (password.toLowerCase().matches(".*(1234|password|qwerty|admin|welltrack).*")) {
            score -= 35;
        }
        return Math.max(0, Math.min(100, score));
    }

    private static String label(String field) {
        StringBuilder builder = new StringBuilder();
        for (int i = 0; i < field.length(); i++) {
            char c = field.charAt(i);
            if (i == 0) {
                builder.append(Character.toUpperCase(c));
            } else if (Character.isUpperCase(c)) {
                builder.append(' ').append(Character.toLowerCase(c));
            } else {
                builder.append(c);
            }
        }
        return builder.toString();
    }

    private static String format(double value) {
        return value == Math.rint(value) ? String.valueOf((long) value) : String.valueOf(value);
    }
}
