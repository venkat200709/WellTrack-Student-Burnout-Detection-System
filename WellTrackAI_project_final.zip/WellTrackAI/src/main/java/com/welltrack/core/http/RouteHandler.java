package com.welltrack.core.http;

/**
 * A functional endpoint. Implemented as a lambda or method reference by every
 * controller in WellTrack.
 */
@FunctionalInterface
public interface RouteHandler {

    HttpResponse handle(HttpRequest request) throws Exception;
}
