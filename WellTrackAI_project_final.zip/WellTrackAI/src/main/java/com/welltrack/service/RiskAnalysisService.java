package com.welltrack.service;

import com.welltrack.ai.BurnoutPredictor;
import com.welltrack.ai.CohortAnalyzer;
import com.welltrack.ai.ForecastEngine;
import com.welltrack.ai.engine.AnomalyDetector;
import com.welltrack.core.json.JsonObject;
import com.welltrack.core.util.AppConfig;
import com.welltrack.core.util.Log;
import com.welltrack.core.util.Numbers;
import com.welltrack.model.BehaviorLog;
import com.welltrack.model.RiskDriver;
import com.welltrack.model.RiskScore;
import com.welltrack.model.Student;
import com.welltrack.model.enums.RiskLevel;
import com.welltrack.model.enums.TrendDirection;
import com.welltrack.repository.BehaviorLogRepository;
import com.welltrack.repository.RiskScoreRepository;
import com.welltrack.repository.UserRepository;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

/**
 * The burnout analysis pipeline — where every AI component meets.
 *
 * <p>A single score is deliberately produced by an <b>ensemble of four
 * independent estimators</b>, because each one fails in a different way:</p>
 *
 * <table border="1">
 *   <caption>Ensemble members</caption>
 *   <tr><th>Member</th><th>Weight</th><th>What it contributes</th></tr>
 *   <tr><td>Logistic-regression model</td><td>50%</td>
 *       <td>Learns how the behaviours interact; the primary signal.</td></tr>
 *   <tr><td>Rule-based strain heuristic</td><td>25%</td>
 *       <td>Transparent domain knowledge; a safety net if the model drifts.</td></tr>
 *   <tr><td>Statistical anomaly detector</td><td>15%</td>
 *       <td>Catches sudden collapses the smoothed average would hide.</td></tr>
 *   <tr><td>Trend component</td><td>10%</td>
 *       <td>Rewards genuine improvement, penalises steady decline.</td></tr>
 * </table>
 *
 * <p>Blending them is not decoration: the model alone would be confidently
 * wrong on an unusual student, the heuristic alone could not learn, and neither
 * would notice a three-day cliff after a stable month. Together they degrade
 * gracefully — before the model finishes training the heuristic simply carries
 * the full weight, so the application is never unusable.</p>
 *
 * <p>Batch analysis of a whole cohort runs on a work-stealing thread pool, and
 * a scheduled daemon re-scores every student periodically so alerts appear
 * without anyone pressing a button.</p>
 */
public final class RiskAnalysisService implements AutoCloseable {

    private static final double MODEL_WEIGHT = 0.50;
    private static final double HEURISTIC_WEIGHT = 0.25;
    private static final double ANOMALY_WEIGHT = 0.15;
    private static final double TREND_WEIGHT = 0.10;

    private final UserRepository users;
    private final BehaviorLogRepository behaviorLogs;
    private final RiskScoreRepository riskScores;
    private final BurnoutPredictor predictor;
    private final ForecastEngine forecastEngine;
    private final CohortAnalyzer cohortAnalyzer;
    private final AlertService alertService;
    private final RecommendationService recommendationService;
    private final EventBus eventBus;

    private final ExecutorService analysisPool;
    private final java.util.concurrent.ScheduledExecutorService scheduler;
    private final int windowDays;

    public RiskAnalysisService(UserRepository users,
                               BehaviorLogRepository behaviorLogs,
                               RiskScoreRepository riskScores,
                               BurnoutPredictor predictor,
                               ForecastEngine forecastEngine,
                               CohortAnalyzer cohortAnalyzer,
                               AlertService alertService,
                               RecommendationService recommendationService,
                               EventBus eventBus) {
        this.users = users;
        this.behaviorLogs = behaviorLogs;
        this.riskScores = riskScores;
        this.predictor = predictor;
        this.forecastEngine = forecastEngine;
        this.cohortAnalyzer = cohortAnalyzer;
        this.alertService = alertService;
        this.recommendationService = recommendationService;
        this.eventBus = eventBus;

        this.windowDays = AppConfig.get().integer("ai.window-days", 14);
        this.analysisPool = Executors.newWorkStealingPool();
        this.scheduler = Executors.newSingleThreadScheduledExecutor(runnable -> {
            Thread thread = new Thread(runnable, "welltrack-analysis-daemon");
            thread.setDaemon(true);
            return thread;
        });
    }

    /** Starts the background re-analysis daemon. */
    public void startDaemon() {
        long intervalMinutes = AppConfig.get().integer("ai.reanalysis-minutes", 15);
        scheduler.scheduleWithFixedDelay(() -> {
            try {
                int analysed = analyseAll().size();
                Log.info("RiskAnalysis", "Scheduled sweep re-scored " + analysed + " students");
            } catch (Exception e) {
                Log.error("RiskAnalysis", "Scheduled sweep failed", e);
            }
        }, intervalMinutes, intervalMinutes, TimeUnit.MINUTES);
    }

    // ------------------------------------------------------------------
    // Single-student analysis
    // ------------------------------------------------------------------

    /**
     * Runs the full pipeline for one student and persists the result.
     *
     * @param raiseAlerts when true, threshold crossings generate alerts and
     *                    push live events to connected clients
     */
    public RiskScore analyse(Student student, boolean raiseAlerts) {
        List<BehaviorLog> window = behaviorLogs.findRecent(student.getId(), windowDays);
        if (window.isEmpty()) {
            window = behaviorLogs.findByStudent(student.getId());
        }

        if (window.isEmpty()) {
            RiskScore empty = new RiskScore();
            empty.setStudentId(student.getId());
            empty.setScore(0);
            empty.setConfidence(0);
            empty.setSummary("No check-ins recorded yet. Log your first day to activate the analysis.");
            riskScores.save(empty);
            return empty;
        }

        RiskScore score = compute(student, window, LocalDateTime.now());
        double[] history = historySeries(student.getId(), score.getScore());
        ForecastEngine.Forecast forecast = forecastEngine.project(history);
        score.setForecast(forecast.projection());
        score.setSummary(summarise(student, score, forecast));

        riskScores.save(score);
        riskScores.pruneHistory(student.getId());

        if (raiseAlerts) {
            alertService.evaluate(student, score, forecast);
            recommendationService.refresh(student, score, predictor.aggregate(window));
            eventBus.publishToUser(student.getId(), "risk.updated", score.toJson());
            if (score.getLevel().requiresIntervention()) {
                eventBus.publishToRoles("risk.intervention", JsonObject.of()
                                .set("studentId", student.getId())
                                .set("studentName", student.getFullName())
                                .set("score", Numbers.round(score.getScore(), 1))
                                .set("level", score.getLevel().label()),
                        List.of("FACULTY", "ADMIN"));
            }
        }
        return score;
    }

    /**
     * The ensemble itself: scores one window of behavioural data.
     *
     * <p>Extracted so that the same computation serves both live analysis and
     * the historical backfill, guaranteeing that a score shown on the trend
     * chart was produced by exactly the same code as today's score.</p>
     */
    private RiskScore compute(Student student, List<BehaviorLog> window, LocalDateTime asOf) {
        RiskScore score = new RiskScore();
        score.setStudentId(student.getId());
        score.setWindowDays(window.size());
        score.setComputedAt(asOf);

        // ---- 1. Learned model ------------------------------------------
        double[] aggregated = predictor.aggregate(window);
        double modelProbability = 0;
        double modelScore;
        List<RiskDriver> drivers = new ArrayList<>();
        if (predictor.isReady()) {
            modelProbability = predictor.probability(aggregated);
            modelScore = predictor.toScore(modelProbability);
            drivers = predictor.explain(aggregated, 8);
        } else {
            modelScore = window.get(window.size() - 1).heuristicStrainScore();
        }

        // ---- 2. Transparent heuristic ----------------------------------
        double heuristicScore = weightedHeuristic(window);

        // ---- 3. Anomaly detection --------------------------------------
        double[] strainSeries = new double[window.size()];
        for (int i = 0; i < window.size(); i++) {
            strainSeries[i] = window.get(i).heuristicStrainScore();
        }
        double anomalyScore = new AnomalyDetector().anomalyScore(strainSeries);

        // ---- 4. Trend --------------------------------------------------
        double slope = Numbers.slope(strainSeries);
        double trendScore = Numbers.clamp(50 + slope * 12, 0, 100);

        // ---- Ensemble --------------------------------------------------
        double blended = predictor.isReady()
                ? modelScore * MODEL_WEIGHT
                + heuristicScore * HEURISTIC_WEIGHT
                + anomalyScore * ANOMALY_WEIGHT
                + trendScore * TREND_WEIGHT
                : heuristicScore * 0.75 + anomalyScore * 0.15 + trendScore * 0.10;

        score.setScore(blended);
        score.setModelProbability(modelProbability);
        score.setHeuristicScore(heuristicScore);
        score.setAnomalyScore(anomalyScore);
        score.setTrendScore(trendScore);
        score.setTrend(TrendDirection.fromSlope(slope, 0.25));
        score.setDrivers(drivers);
        score.setConfidence(confidenceOf(window.size(), predictor.isReady(), modelProbability));
        return score;
    }

    /**
     * Reconstructs a student's risk history from their stored check-ins.
     *
     * <p>Called once after the model finishes training. For every day in the
     * period it rebuilds the window that <em>would</em> have been visible on
     * that date and scores it, producing the trend line and giving the
     * forecaster a real series to work with instead of a single point. Days
     * already present are skipped, so this is idempotent and safe to re-run.</p>
     *
     * @return the number of historical scores created
     */
    public int backfillHistory(Student student, int days) {
        List<BehaviorLog> all = behaviorLogs.findByStudent(student.getId());
        if (all.size() < 3) {
            return 0;
        }
        java.util.Set<LocalDate> existing = new java.util.HashSet<>();
        for (RiskScore score : riskScores.findHistory(student.getId(), Integer.MAX_VALUE)) {
            if (score.getComputedAt() != null) {
                existing.add(score.getComputedAt().toLocalDate());
            }
        }

        List<RiskScore> created = new ArrayList<>();
        LocalDate today = LocalDate.now();
        for (int offset = days; offset >= 1; offset--) {
            LocalDate asOf = today.minusDays(offset);
            if (existing.contains(asOf)) {
                continue;
            }
            LocalDate windowStart = asOf.minusDays(windowDays);
            List<BehaviorLog> window = new ArrayList<>();
            for (BehaviorLog log : all) {
                LocalDate date = log.getLogDate();
                if (date != null && !date.isAfter(asOf) && date.isAfter(windowStart)) {
                    window.add(log);
                }
            }
            if (window.size() < 3) {
                continue;
            }
            RiskScore score = compute(student, window, asOf.atTime(22, 0));
            // Historical points only feed the trend line and the forecaster, so
            // the per-driver explanations are dropped — keeping the datastore
            // roughly ten times smaller and start-up correspondingly faster.
            score.setDrivers(java.util.List.of());
            score.setSummary("Reconstructed from the check-ins available on " + asOf + ".");
            created.add(score);
        }
        created.forEach(riskScores::save);
        return created.size();
    }

    /**
     * Recency-weighted heuristic strain across the window. The most recent day
     * carries roughly four times the weight of a day a week earlier.
     */
    private double weightedHeuristic(List<BehaviorLog> window) {
        double total = 0;
        double weightSum = 0;
        int size = window.size();
        for (int i = 0; i < size; i++) {
            double weight = Math.pow(0.5, (size - 1 - i) / 5.0);
            total += window.get(i).heuristicStrainScore() * weight;
            weightSum += weight;
        }
        return weightSum == 0 ? 0 : total / weightSum;
    }

    /**
     * Confidence grows with the amount of history and is highest when the model
     * is decisive (a probability near 0 or 1) rather than sitting on the fence.
     */
    private double confidenceOf(int observations, boolean modelReady, double probability) {
        double dataConfidence = Numbers.clamp(observations / 14.0, 0.15, 1.0);
        if (!modelReady) {
            return dataConfidence * 0.6;
        }
        double decisiveness = Math.abs(probability - 0.5) * 2;
        return Numbers.clamp(0.45 * dataConfidence + 0.55 * (0.4 + 0.6 * decisiveness), 0, 1);
    }

    private double[] historySeries(long studentId, double currentScore) {
        List<RiskScore> history = riskScores.findHistory(studentId, 30);
        double[] series = new double[history.size() + 1];
        for (int i = 0; i < history.size(); i++) {
            series[i] = history.get(i).getScore();
        }
        series[series.length - 1] = currentScore;
        return series;
    }

    private String summarise(Student student, RiskScore score, ForecastEngine.Forecast forecast) {
        StringBuilder summary = new StringBuilder();
        summary.append(student.getFullName().split("\\s+")[0])
                .append(" is currently ").append(score.getLevel().label().toLowerCase())
                .append(" at ").append(Math.round(score.getScore())).append("/100. ");
        List<RiskDriver> aggravators = score.topAggravators(2);
        if (!aggravators.isEmpty()) {
            summary.append("The largest contributors are ")
                    .append(aggravators.get(0).label().toLowerCase());
            if (aggravators.size() > 1) {
                summary.append(" and ").append(aggravators.get(1).label().toLowerCase());
            }
            summary.append(". ");
        }
        summary.append(forecast.narrative());
        return summary.toString();
    }

    // ------------------------------------------------------------------
    // Batch analysis
    // ------------------------------------------------------------------

    /**
     * Re-scores every student in parallel.
     *
     * <p>Each student is an independent unit of work, so the batch is dispatched
     * across a work-stealing pool via {@link CompletableFuture}. On a cohort of
     * several hundred students this turns a serial sweep into one that finishes
     * in the time of the slowest individual analysis.</p>
     */
    @SuppressWarnings("rawtypes") // CompletableFuture.allOf takes a raw varargs array by design.
    public Map<Long, RiskScore> analyseAll() {
        List<Student> students = users.findAllStudents();
        Map<Long, RiskScore> results = new HashMap<>();

        List<CompletableFuture<Map.Entry<Long, RiskScore>>> futures = students.stream()
                .map(student -> CompletableFuture.supplyAsync(
                        () -> Map.entry(student.getId(), analyse(student, true)), analysisPool))
                .toList();

        CompletableFuture.allOf(futures.toArray(new CompletableFuture[0])).join();
        for (CompletableFuture<Map.Entry<Long, RiskScore>> future : futures) {
            Map.Entry<Long, RiskScore> entry = future.join();
            results.put(entry.getKey(), entry.getValue());
        }

        refreshCohorts(students, results);
        return results;
    }

    /** Recomputes the wellness cohorts from the freshly scored population. */
    public void refreshCohorts(List<Student> students, Map<Long, RiskScore> scores) {
        Map<Long, double[]> featuresByStudent = new HashMap<>();
        Map<Long, Double> riskByStudent = new HashMap<>();
        for (Student student : students) {
            List<BehaviorLog> window = behaviorLogs.findRecent(student.getId(), windowDays);
            if (window.isEmpty()) {
                continue;
            }
            featuresByStudent.put(student.getId(), predictor.aggregate(window));
            RiskScore score = scores.get(student.getId());
            riskByStudent.put(student.getId(), score == null ? 0 : score.getScore());
        }
        if (featuresByStudent.size() >= 4) {
            cohortAnalyzer.analyse(featuresByStudent, riskByStudent);
        }
    }

    /** @return the aggregated feature vector for a student, for peer comparison. */
    public double[] aggregatedFeatures(long studentId) {
        return predictor.aggregate(behaviorLogs.findRecent(studentId, windowDays));
    }

    public Optional<RiskScore> latest(long studentId) {
        return riskScores.findLatest(studentId);
    }

    public ForecastEngine.Forecast forecastFor(long studentId) {
        List<RiskScore> history = riskScores.findHistory(studentId, 30);
        double[] series = new double[history.size()];
        for (int i = 0; i < history.size(); i++) {
            series[i] = history.get(i).getScore();
        }
        return forecastEngine.project(series);
    }

    /** @return the population distribution across risk bands. */
    public Map<RiskLevel, Integer> riskDistribution() {
        Map<RiskLevel, Integer> distribution = new java.util.EnumMap<>(RiskLevel.class);
        for (RiskLevel level : RiskLevel.values()) {
            distribution.put(level, 0);
        }
        for (Student student : users.findAllStudents()) {
            riskScores.findLatest(student.getId()).ifPresent(score ->
                    distribution.merge(score.getLevel(), 1, Integer::sum));
        }
        return distribution;
    }

    public int windowDays() {
        return windowDays;
    }

    @Override
    public void close() {
        scheduler.shutdownNow();
        analysisPool.shutdown();
        try {
            if (!analysisPool.awaitTermination(5, TimeUnit.SECONDS)) {
                analysisPool.shutdownNow();
            }
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            analysisPool.shutdownNow();
        }
    }
}
