package com.welltrack.service;

import com.welltrack.core.util.Validation;
import com.welltrack.exception.NotFoundException;
import com.welltrack.model.Faculty;
import com.welltrack.model.Student;
import com.welltrack.model.User;
import com.welltrack.repository.BehaviorLogRepository;
import com.welltrack.repository.UserRepository;

import java.util.Comparator;
import java.util.List;
import java.util.Locale;
import java.util.Optional;

/**
 * Application service for student records — the CRUD core required by the
 * project specification, wrapped in validation and authorisation-aware queries.
 */
public final class StudentService {

    private final UserRepository users;
    private final BehaviorLogRepository behaviorLogs;

    public StudentService(UserRepository users, BehaviorLogRepository behaviorLogs) {
        this.users = users;
        this.behaviorLogs = behaviorLogs;
    }

    public List<Student> findAll() {
        return users.findAllStudents();
    }

    public Student require(long id) {
        return users.findStudent(id)
                .orElseThrow(() -> new NotFoundException("Student", id));
    }

    public Optional<Student> find(long id) {
        return users.findStudent(id);
    }

    /**
     * Free-text search across name, register number, username, email and
     * department. Matching is case-insensitive and substring-based, which is
     * what a mentor actually needs when scanning a cohort.
     */
    public List<Student> search(String query) {
        if (query == null || query.isBlank()) {
            return findAll();
        }
        String needle = query.trim().toLowerCase(Locale.ROOT);
        return findAll().stream()
                .filter(student -> contains(student.getFullName(), needle)
                        || contains(student.getRegisterNumber(), needle)
                        || contains(student.getUsername(), needle)
                        || contains(student.getEmail(), needle)
                        || contains(student.getDepartment(), needle))
                .sorted(Comparator.comparing(Student::getFullName,
                        Comparator.nullsLast(Comparator.naturalOrder())))
                .toList();
    }

    private static boolean contains(String value, String needle) {
        return value != null && value.toLowerCase(Locale.ROOT).contains(needle);
    }

    public List<Student> forMentor(long mentorId) {
        return users.findStudentsOfMentor(mentorId);
    }

    /** Updates the mutable parts of a student profile. */
    public Student updateProfile(long studentId, String fullName, String department,
                                 String section, int yearOfStudy, double cgpa,
                                 double attendancePercentage, int creditLoad, String hostelStatus) {
        Student student = require(studentId);
        Validation.check()
                .required("fullName", fullName)
                .minLength("fullName", fullName, 3)
                .maxLength("fullName", fullName, 80)
                .required("department", department)
                .range("yearOfStudy", yearOfStudy, 1, 5)
                .range("cgpa", cgpa, 0, 10)
                .range("attendancePercentage", attendancePercentage, 0, 100)
                .range("creditLoad", creditLoad, 0, 40)
                .throwIfInvalid();

        student.setFullName(fullName.trim());
        student.setDepartment(department.trim());
        student.setSection(section == null || section.isBlank() ? student.getSection() : section.trim());
        student.setYearOfStudy(yearOfStudy);
        student.setCgpa(cgpa);
        student.setAttendancePercentage(attendancePercentage);
        student.setCreditLoad(creditLoad);
        if (hostelStatus != null && !hostelStatus.isBlank()) {
            student.setHostelStatus(hostelStatus.trim());
        }
        users.save(student);
        return student;
    }

    /** Assigns a faculty mentor, verifying that the mentor exists. */
    public Student assignMentor(long studentId, long mentorId) {
        Student student = require(studentId);
        User mentor = users.findById(mentorId)
                .orElseThrow(() -> new NotFoundException("Faculty mentor", mentorId));
        if (!(mentor instanceof Faculty)) {
            throw new com.welltrack.exception.ValidationException(
                    "That account is not a faculty mentor",
                    java.util.Map.of("mentorId", "Choose a faculty account"));
        }
        student.setMentorId(mentorId);
        users.save(student);
        return student;
    }

    /** Deactivates rather than hard-deletes, preserving the audit trail. */
    public void deactivate(long studentId) {
        Student student = require(studentId);
        student.setActive(false);
        users.save(student);
    }

    public void reactivate(long studentId) {
        Student student = require(studentId);
        student.setActive(true);
        student.setFailedLoginAttempts(0);
        student.setLockedUntil(null);
        users.save(student);
    }

    /** Permanently removes a student and every behavioural record they own. */
    public void delete(long studentId) {
        Student student = require(studentId);
        behaviorLogs.deleteForStudent(student.getId());
        users.deleteById(studentId);
    }

    public long count() {
        return findAll().size();
    }
}
