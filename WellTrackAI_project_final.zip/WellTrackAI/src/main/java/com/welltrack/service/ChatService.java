package com.welltrack.service;

import com.welltrack.ai.WellnessCoach;
import com.welltrack.core.json.JsonArray;
import com.welltrack.core.json.JsonObject;
import com.welltrack.core.util.Validation;
import com.welltrack.model.ChatMessage;
import com.welltrack.model.Student;
import com.welltrack.model.enums.AlertSeverity;
import com.welltrack.model.enums.ChatRole;
import com.welltrack.repository.ChatMessageRepository;
import com.welltrack.repository.RiskScoreRepository;

import java.util.List;

/**
 * Orchestrates a conversation with the AI wellness coach and persists the
 * transcript.
 *
 * <p>Beyond relaying messages, this service performs the safety step that a
 * wellness product must not skip: when the coach's sentiment layer detects
 * crisis language, an urgent alert is raised for the faculty mentor
 * automatically, so a concerning message can never sit unread in a chat log.</p>
 */
public final class ChatService {

    private final ChatMessageRepository messages;
    private final RiskScoreRepository riskScores;
    private final BehaviorService behaviorService;
    private final WellnessCoach coach;
    private final AlertService alertService;

    public ChatService(ChatMessageRepository messages,
                       RiskScoreRepository riskScores,
                       BehaviorService behaviorService,
                       WellnessCoach coach,
                       AlertService alertService) {
        this.messages = messages;
        this.riskScores = riskScores;
        this.behaviorService = behaviorService;
        this.coach = coach;
        this.alertService = alertService;
    }

    /** Handles one turn of conversation. */
    public JsonObject send(Student student, String text) {
        Validation.check()
                .required("message", text)
                .maxLength("message", text, 1000)
                .throwIfInvalid();

        ChatMessage inbound = new ChatMessage(student.getId(), ChatRole.USER, text.trim());
        WellnessCoach.CoachReply reply = coach.respond(
                student, text,
                riskScores.findLatest(student.getId()),
                behaviorService.latest(student.getId()));

        inbound.setDetectedIntent(reply.intent());
        inbound.setSentiment(reply.sentiment().polarity());
        inbound.setConfidence(reply.intentConfidence());
        messages.save(inbound);

        ChatMessage outbound = new ChatMessage(student.getId(), ChatRole.COACH, reply.message());
        outbound.setDetectedIntent(reply.intent());
        outbound.setSentiment(reply.sentiment().polarity());
        outbound.setConfidence(reply.intentConfidence());
        outbound.setSource(reply.generator());
        messages.save(outbound);

        if (reply.escalate()) {
            alertService.raiseManual(student,
                    "Support request detected in wellness chat",
                    "%s wrote a message containing distress indicators. Please reach out personally today."
                            .formatted(student.getFullName()),
                    AlertSeverity.CRITICAL);
        }

        return JsonObject.of()
                .set("reply", outbound.toJson())
                .set("analysis", reply.toJson());
    }

    public JsonArray transcript(long studentId, int limit) {
        JsonArray array = new JsonArray();
        for (ChatMessage message : messages.findConversation(studentId, limit)) {
            array.add(message.toJson());
        }
        return array;
    }

    /** Greets a student who has no history, so the panel is never empty. */
    public JsonObject greeting(Student student) {
        List<ChatMessage> existing = messages.findConversation(student.getId(), 1);
        if (!existing.isEmpty()) {
            return existing.get(0).toJson();
        }
        String name = student.getFullName() == null
                ? "there" : student.getFullName().split("\\s+")[0];
        ChatMessage greeting = new ChatMessage(student.getId(), ChatRole.COACH,
                "Hello " + name + " — I am your WellTrack coach. I read your daily check-ins, "
                        + "explain exactly what is driving your burnout score, and suggest small changes "
                        + "that actually move it. Ask me anything, or start with \"why is my score high?\"");
        greeting.setDetectedIntent("greeting");
        messages.save(greeting);
        return greeting.toJson();
    }

    public int clear(long studentId) {
        return messages.clearConversation(studentId);
    }
}
