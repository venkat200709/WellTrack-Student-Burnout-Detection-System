package com.welltrack.service;

import com.welltrack.core.json.JsonObject;
import com.welltrack.model.Badge;
import com.welltrack.model.BehaviorLog;
import com.welltrack.model.Student;
import com.welltrack.model.enums.BadgeTier;
import com.welltrack.repository.BadgeRepository;
import com.welltrack.repository.BehaviorLogRepository;
import com.welltrack.repository.UserRepository;

import java.util.ArrayList;
import java.util.List;

/**
 * Behavioural reinforcement: streaks, points, levels and badges.
 *
 * <p>An early-warning system only works if students keep feeding it data, and
 * the honest difficulty with wellness tools is that engagement collapses after
 * the first fortnight. Rewarding <em>consistency</em> (logging, completing an
 * action step, protecting sleep) rather than a good score avoids the obvious
 * failure mode where students learn to report what earns points.</p>
 */
public final class GamificationService {

    private final BadgeRepository badges;
    private final BehaviorLogRepository behaviorLogs;
    private final UserRepository users;
    private final EventBus eventBus;

    public GamificationService(BadgeRepository badges,
                               BehaviorLogRepository behaviorLogs,
                               UserRepository users,
                               EventBus eventBus) {
        this.badges = badges;
        this.behaviorLogs = behaviorLogs;
        this.users = users;
        this.eventBus = eventBus;
    }

    /** Awards points and evaluates every badge rule after a check-in. */
    public List<Badge> onCheckIn(Student student) {
        student.awardPoints(10);
        List<Badge> awarded = evaluateBadges(student);
        users.save(student);
        return awarded;
    }

    /** Awards points when a recommended action is completed. */
    public List<Badge> onRecommendationCompleted(Student student) {
        student.awardPoints(25);
        List<Badge> awarded = evaluateBadges(student);
        users.save(student);
        return awarded;
    }

    /**
     * Evaluates every badge rule without awarding participation points. Used by
     * the start-up sweep so seeded students immediately hold the badges their
     * history has genuinely earned.
     */
    public List<Badge> evaluate(Student student) {
        List<Badge> awarded = evaluateBadges(student);
        if (!awarded.isEmpty()) {
            users.save(student);
        }
        return awarded;
    }

    private List<Badge> evaluateBadges(Student student) {
        List<Badge> awarded = new ArrayList<>();
        List<BehaviorLog> logs = behaviorLogs.findByStudent(student.getId());
        int streak = student.getStreakDays();

        award(awarded, student, "FIRST_STEP", logs.size() >= 1,
                "First Step", "Logged your very first wellness check-in",
                "🌱", BadgeTier.BRONZE, 20);
        award(awarded, student, "STREAK_7", streak >= 7,
                "Seven-Day Streak", "Checked in every day for a full week",
                "🔥", BadgeTier.SILVER, 60);
        award(awarded, student, "STREAK_30", streak >= 30,
                "Consistency Champion", "Thirty consecutive days of check-ins",
                "🏆", BadgeTier.PLATINUM, 200);
        award(awarded, student, "SLEEP_GUARDIAN", hasSustainedSleep(logs, 7, 7.0),
                "Sleep Guardian", "Seven straight nights above seven hours",
                "🌙", BadgeTier.GOLD, 120);
        award(awarded, student, "MOVER", hasSustainedExercise(logs, 5, 20),
                "In Motion", "Five consecutive days of at least twenty minutes' movement",
                "🏃", BadgeTier.SILVER, 70);
        award(awarded, student, "REFLECTOR", countJournalEntries(logs) >= 10,
                "Reflective Practitioner", "Wrote ten journal reflections",
                "📔", BadgeTier.SILVER, 60);
        award(awarded, student, "COMEBACK", hasComeback(student),
                "Comeback", "Climbed back out of the high-risk band",
                "💪", BadgeTier.GOLD, 150);

        return awarded;
    }

    private void award(List<Badge> awarded, Student student, String code, boolean earned,
                       String name, String description, String glyph, BadgeTier tier, int points) {
        if (!earned || badges.hasBadge(student.getId(), code)) {
            return;
        }
        Badge badge = new Badge(student.getId(), code, name, description, glyph, tier, points);
        badges.save(badge);
        student.awardPoints(points);
        awarded.add(badge);
        eventBus.publishToUser(student.getId(), "badge.earned", badge.toJson());
    }

    private boolean hasSustainedSleep(List<BehaviorLog> logs, int days, double threshold) {
        return tailSatisfies(logs, days, log -> log.getSleepHours() >= threshold);
    }

    private boolean hasSustainedExercise(List<BehaviorLog> logs, int days, int minutes) {
        return tailSatisfies(logs, days, log -> log.getExerciseMinutes() >= minutes);
    }

    private boolean tailSatisfies(List<BehaviorLog> logs, int days,
                                  java.util.function.Predicate<BehaviorLog> predicate) {
        if (logs.size() < days) {
            return false;
        }
        for (int i = logs.size() - days; i < logs.size(); i++) {
            if (!predicate.test(logs.get(i))) {
                return false;
            }
        }
        return true;
    }

    private int countJournalEntries(List<BehaviorLog> logs) {
        int count = 0;
        for (BehaviorLog log : logs) {
            if (log.getJournalNote() != null && log.getJournalNote().length() > 15) {
                count++;
            }
        }
        return count;
    }

    private boolean hasComeback(Student student) {
        // Awarded by the analysis pipeline through the recovery flag.
        return student.getWellnessPoints() > 0 && recoveryFlags.contains(student.getId());
    }

    private final java.util.Set<Long> recoveryFlags =
            java.util.concurrent.ConcurrentHashMap.newKeySet();

    /** Called by the analysis pipeline when a student leaves the high-risk band. */
    public void flagRecovery(long studentId) {
        recoveryFlags.add(studentId);
    }

    public List<Badge> badgesOf(long studentId) {
        return badges.findForStudent(studentId);
    }

    /** @return the wellness-points leaderboard, anonymised beyond the top three. */
    public JsonObject leaderboard(long viewerId, int limit) {
        List<Student> ranked = new ArrayList<>(users.findAllStudents());
        ranked.sort((a, b) -> Integer.compare(b.getWellnessPoints(), a.getWellnessPoints()));

        com.welltrack.core.json.JsonArray rows = new com.welltrack.core.json.JsonArray();
        for (int i = 0; i < Math.min(limit, ranked.size()); i++) {
            Student student = ranked.get(i);
            boolean reveal = i < 3 || student.getId() == viewerId;
            rows.add(JsonObject.of()
                    .set("rank", i + 1)
                    .set("name", reveal ? student.getFullName() : "Student " + student.initials())
                    .set("initials", student.initials())
                    .set("points", student.getWellnessPoints())
                    .set("level", student.level())
                    .set("levelTitle", student.levelTitle())
                    .set("streak", student.getStreakDays())
                    .set("isViewer", student.getId() == viewerId));
        }
        int viewerRank = 0;
        for (int i = 0; i < ranked.size(); i++) {
            if (ranked.get(i).getId() == viewerId) {
                viewerRank = i + 1;
                break;
            }
        }
        return JsonObject.of()
                .set("rows", rows)
                .set("viewerRank", viewerRank)
                .set("totalStudents", ranked.size());
    }
}
