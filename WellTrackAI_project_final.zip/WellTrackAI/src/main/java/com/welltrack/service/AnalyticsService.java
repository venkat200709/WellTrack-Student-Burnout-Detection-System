package com.welltrack.service;

import com.welltrack.ai.CohortAnalyzer;
import com.welltrack.core.json.JsonArray;
import com.welltrack.core.json.JsonObject;
import com.welltrack.core.util.Numbers;
import com.welltrack.model.BehaviorLog;
import com.welltrack.model.RiskScore;
import com.welltrack.model.Student;
import com.welltrack.model.enums.RiskLevel;
import com.welltrack.repository.AlertRepository;
import com.welltrack.repository.BehaviorLogRepository;
import com.welltrack.repository.RiskScoreRepository;
import com.welltrack.repository.UserRepository;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

/**
 * Aggregate analytics for the faculty and administrator consoles.
 *
 * <p>Everything here answers a question a mentor genuinely has: who needs me
 * today, is my cohort getting better or worse, which behaviour is failing
 * across the whole group, and which department is under the most strain.</p>
 */
public final class AnalyticsService {

    private final UserRepository users;
    private final BehaviorLogRepository behaviorLogs;
    private final RiskScoreRepository riskScores;
    private final AlertRepository alerts;
    private final CohortAnalyzer cohortAnalyzer;

    public AnalyticsService(UserRepository users,
                            BehaviorLogRepository behaviorLogs,
                            RiskScoreRepository riskScores,
                            AlertRepository alerts,
                            CohortAnalyzer cohortAnalyzer) {
        this.users = users;
        this.behaviorLogs = behaviorLogs;
        this.riskScores = riskScores;
        this.alerts = alerts;
        this.cohortAnalyzer = cohortAnalyzer;
    }

    /** The headline console for a mentor or administrator. */
    public JsonObject overview(List<Student> scope) {
        JsonArray roster = new JsonArray();
        Map<RiskLevel, Integer> distribution = new java.util.EnumMap<>(RiskLevel.class);
        for (RiskLevel level : RiskLevel.values()) {
            distribution.put(level, 0);
        }

        double totalScore = 0;
        int scored = 0;
        int interventions = 0;

        for (Student student : scope) {
            Optional<RiskScore> latest = riskScores.findLatest(student.getId());
            double score = latest.map(RiskScore::getScore).orElse(0.0);
            RiskLevel level = latest.map(RiskScore::getLevel).orElse(RiskLevel.THRIVING);
            if (latest.isPresent()) {
                totalScore += score;
                scored++;
                distribution.merge(level, 1, Integer::sum);
                if (level.requiresIntervention()) {
                    interventions++;
                }
            }

            CohortAnalyzer.Cohort cohort = cohortAnalyzer.cohortOf(student.getId());
            roster.add(JsonObject.of()
                    .set("id", student.getId())
                    .set("name", student.getFullName())
                    .set("initials", student.initials())
                    .set("registerNumber", student.getRegisterNumber())
                    .set("department", student.getDepartment())
                    .set("section", student.getSection())
                    .set("yearOfStudy", student.getYearOfStudy())
                    .set("score", Numbers.round(score, 1))
                    .set("level", level.name())
                    .set("levelLabel", level.label())
                    .set("levelColour", level.colour())
                    .set("trend", latest.map(item -> item.getTrend().name()).orElse("STABLE"))
                    .set("trendLabel", latest.map(item -> item.getTrend().label()).orElse("Stable"))
                    .set("confidence", latest.map(item -> Numbers.round(item.getConfidence(), 2)).orElse(0.0))
                    .set("streak", student.getStreakDays())
                    .set("attendance", Numbers.round(student.getAttendancePercentage(), 1))
                    .set("cgpa", student.getCgpa())
                    .set("unacknowledgedAlerts", alerts.countUnacknowledged(student.getId()))
                    .set("cohort", cohort == null ? "Unclustered" : cohort.name())
                    .set("lastCheckIn", behaviorLogs.findLatest(student.getId())
                            .map(log -> String.valueOf(log.getLogDate()))
                            .orElse("never")));
        }

        JsonObject distributionJson = new JsonObject();
        distribution.forEach((level, count) -> distributionJson.set(level.name(), count));

        return JsonObject.of()
                .set("totalStudents", scope.size())
                .set("scoredStudents", scored)
                .set("averageScore", scored == 0 ? 0 : Numbers.round(totalScore / scored, 1))
                .set("interventionsNeeded", interventions)
                .set("openAlerts", alerts.findUnacknowledged().size())
                .set("distribution", distributionJson)
                .set("roster", roster)
                .set("cohorts", cohortAnalyzer.toJson());
    }

    /**
     * Population-level behavioural averages over the last fortnight, so a mentor
     * can see whether a problem is individual or systemic.
     */
    public JsonObject behaviourAverages(List<Student> scope) {
        double sleep = 0;
        double study = 0;
        double screen = 0;
        double stress = 0;
        double exercise = 0;
        double attendance = 0;
        int samples = 0;

        for (Student student : scope) {
            for (BehaviorLog log : behaviorLogs.findRecent(student.getId(), 14)) {
                sleep += log.getSleepHours();
                study += log.getStudyHours();
                screen += log.getScreenTimeHours();
                stress += log.getStressLevel();
                exercise += log.getExerciseMinutes();
                attendance += log.attendanceRatio() * 100;
                samples++;
            }
        }
        if (samples == 0) {
            return JsonObject.of().set("samples", 0);
        }
        return JsonObject.of()
                .set("samples", samples)
                .set("sleepHours", Numbers.round(sleep / samples, 2))
                .set("studyHours", Numbers.round(study / samples, 2))
                .set("screenTimeHours", Numbers.round(screen / samples, 2))
                .set("stressLevel", Numbers.round(stress / samples, 2))
                .set("exerciseMinutes", Numbers.round(exercise / samples, 1))
                .set("attendancePercentage", Numbers.round(attendance / samples, 1));
    }

    /** The average cohort risk per day over the requested window. */
    public JsonArray riskTimeline(List<Student> scope, int days) {
        Map<LocalDate, List<Double>> byDay = new LinkedHashMap<>();
        for (Student student : scope) {
            for (RiskScore score : riskScores.findHistory(student.getId(), 200)) {
                if (score.getComputedAt() == null) {
                    continue;
                }
                LocalDate day = score.getComputedAt().toLocalDate();
                if (day.isBefore(LocalDate.now().minusDays(days))) {
                    continue;
                }
                byDay.computeIfAbsent(day, key -> new ArrayList<>()).add(score.getScore());
            }
        }
        List<LocalDate> sortedDays = new ArrayList<>(byDay.keySet());
        sortedDays.sort(Comparator.naturalOrder());

        JsonArray series = new JsonArray();
        for (LocalDate day : sortedDays) {
            List<Double> values = byDay.get(day);
            double average = values.stream().mapToDouble(Double::doubleValue).average().orElse(0);
            series.add(JsonObject.of()
                    .set("date", day.toString())
                    .set("averageScore", Numbers.round(average, 1))
                    .set("samples", values.size()));
        }
        return series;
    }

    /** Department-level rollup for the administrator view. */
    public JsonArray departmentBreakdown() {
        Map<String, List<Double>> byDepartment = new LinkedHashMap<>();
        for (Student student : users.findAllStudents()) {
            String department = student.getDepartment() == null ? "Unassigned" : student.getDepartment();
            double score = riskScores.findLatest(student.getId()).map(RiskScore::getScore).orElse(0.0);
            byDepartment.computeIfAbsent(department, key -> new ArrayList<>()).add(score);
        }
        JsonArray array = new JsonArray();
        byDepartment.forEach((department, scores) -> {
            double average = scores.stream().mapToDouble(Double::doubleValue).average().orElse(0);
            long atRisk = scores.stream().filter(score -> score >= 60).count();
            array.add(JsonObject.of()
                    .set("department", department)
                    .set("students", scores.size())
                    .set("averageScore", Numbers.round(average, 1))
                    .set("atRisk", atRisk));
        });
        return array;
    }

    /** The students most in need of contact, highest risk first. */
    public JsonArray priorityQueue(List<Student> scope, int limit) {
        List<Map.Entry<Student, RiskScore>> ranked = new ArrayList<>();
        for (Student student : scope) {
            riskScores.findLatest(student.getId())
                    .ifPresent(score -> ranked.add(Map.entry(student, score)));
        }
        ranked.sort((a, b) -> Double.compare(b.getValue().getScore(), a.getValue().getScore()));

        JsonArray array = new JsonArray();
        for (int i = 0; i < Math.min(limit, ranked.size()); i++) {
            Student student = ranked.get(i).getKey();
            RiskScore score = ranked.get(i).getValue();
            if (score.getScore() < 40) {
                break;
            }
            array.add(JsonObject.of()
                    .set("studentId", student.getId())
                    .set("name", student.getFullName())
                    .set("initials", student.initials())
                    .set("registerNumber", student.getRegisterNumber())
                    .set("score", Numbers.round(score.getScore(), 1))
                    .set("level", score.getLevel().label())
                    .set("levelColour", score.getLevel().colour())
                    .set("summary", score.getSummary())
                    .set("trendLabel", score.getTrend().label()));
        }
        return array;
    }
}
