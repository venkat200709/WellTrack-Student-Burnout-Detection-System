package com.welltrack.service;

import com.welltrack.ai.nlp.SentimentAnalyzer;
import com.welltrack.core.json.JsonObject;
import com.welltrack.core.util.Numbers;
import com.welltrack.dto.BehaviorLogRequest;
import com.welltrack.model.BehaviorLog;
import com.welltrack.model.Student;
import com.welltrack.repository.BehaviorLogRepository;
import com.welltrack.repository.UserRepository;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

/**
 * Manages daily check-ins: the create/read/update/delete surface over
 * behavioural data, plus the streak logic that keeps students logging.
 *
 * <p>Journal notes are passed through the {@link SentimentAnalyzer}, so the
 * free-text field becomes a genuine signal rather than decoration — a student
 * whose numbers look acceptable but whose writing is bleak still surfaces.</p>
 */
public final class BehaviorService {

    private final BehaviorLogRepository behaviorLogs;
    private final UserRepository users;
    private final SentimentAnalyzer sentimentAnalyzer = new SentimentAnalyzer();

    public BehaviorService(BehaviorLogRepository behaviorLogs, UserRepository users) {
        this.behaviorLogs = behaviorLogs;
        this.users = users;
    }

    /**
     * Records or replaces a day's check-in.
     *
     * <p>Re-submitting the same date updates the existing entry rather than
     * creating a duplicate, which keeps the time series clean — duplicates
     * would silently double-weight a single day in every downstream model.</p>
     */
    public BehaviorLog record(Student student, BehaviorLogRequest request) {
        BehaviorLog log = request.toEntity(student.getId());
        Optional<BehaviorLog> existing =
                behaviorLogs.findByStudentAndDate(student.getId(), request.logDate());
        existing.ifPresent(previous -> log.setId(previous.getId()));

        behaviorLogs.save(log);
        updateStreak(student);
        updateAttendanceRollup(student);
        return log;
    }

    /**
     * Recomputes the consecutive-day streak from the stored history, walking
     * backwards from today. Deriving it rather than incrementing a counter
     * means the value is always correct, even after an edit or a deletion.
     */
    public int updateStreak(Student student) {
        List<BehaviorLog> logs = behaviorLogs.findByStudent(student.getId());
        if (logs.isEmpty()) {
            student.setStreakDays(0);
            users.save(student);
            return 0;
        }
        java.util.Set<LocalDate> dates = new java.util.HashSet<>();
        logs.forEach(log -> dates.add(log.getLogDate()));

        LocalDate cursor = LocalDate.now();
        if (!dates.contains(cursor)) {
            cursor = cursor.minusDays(1);
            if (!dates.contains(cursor)) {
                student.setStreakDays(0);
                users.save(student);
                return 0;
            }
        }
        int streak = 0;
        while (dates.contains(cursor)) {
            streak++;
            cursor = cursor.minusDays(1);
        }
        student.setStreakDays(streak);
        users.save(student);
        return streak;
    }

    /** Keeps the profile-level attendance percentage in step with the logs. */
    private void updateAttendanceRollup(Student student) {
        List<BehaviorLog> recent = behaviorLogs.findRecent(student.getId(), 30);
        if (recent.isEmpty()) {
            return;
        }
        int attended = 0;
        int scheduled = 0;
        for (BehaviorLog log : recent) {
            attended += log.getClassesAttended();
            scheduled += log.getClassesScheduled();
        }
        if (scheduled > 0) {
            student.setAttendancePercentage(Numbers.round(attended * 100.0 / scheduled, 1));
            users.save(student);
        }
    }

    public List<BehaviorLog> history(long studentId, int days) {
        return behaviorLogs.findRecent(studentId, days);
    }

    public List<BehaviorLog> all(long studentId) {
        return behaviorLogs.findByStudent(studentId);
    }

    public Optional<BehaviorLog> latest(long studentId) {
        return behaviorLogs.findLatest(studentId);
    }

    public Optional<BehaviorLog> onDate(long studentId, LocalDate date) {
        return behaviorLogs.findByStudentAndDate(studentId, date);
    }

    public boolean delete(long studentId, long logId) {
        Optional<BehaviorLog> log = behaviorLogs.findById(logId);
        if (log.isEmpty() || log.get().getStudentId() != studentId) {
            return false;
        }
        return behaviorLogs.deleteById(logId);
    }

    /** Analyses the free-text journal entries of the recent window. */
    public JsonObject journalInsight(long studentId, int days) {
        List<BehaviorLog> window = behaviorLogs.findRecent(studentId, days);
        StringBuilder corpus = new StringBuilder();
        int entries = 0;
        for (BehaviorLog log : window) {
            if (log.getJournalNote() != null && !log.getJournalNote().isBlank()) {
                corpus.append(log.getJournalNote()).append(". ");
                entries++;
            }
        }
        if (entries == 0) {
            return JsonObject.of()
                    .set("entries", 0)
                    .set("message", "Add a short note to your check-ins and WellTrack will read the mood behind them.");
        }
        SentimentAnalyzer.SentimentReport report = sentimentAnalyzer.analyse(corpus.toString());
        return JsonObject.of()
                .set("entries", entries)
                .set("analysis", report.toJson())
                .set("message", narrate(report));
    }

    private String narrate(SentimentAnalyzer.SentimentReport report) {
        String emotion = report.dominantEmotion();
        if (report.crisisMarkerDetected()) {
            return "Your recent notes contain language that concerns me. Please talk to your mentor or "
                    + "the student welfare office today.";
        }
        if (report.polarity() < -0.4) {
            return "Your written notes are consistently negative, with " + emotion
                    + " showing most strongly. That matters as much as the numbers.";
        }
        if (report.polarity() < -0.1) {
            return "Your notes lean slightly negative — " + emotion
                    + " is the recurring theme. Worth watching this week.";
        }
        if (report.polarity() > 0.3) {
            return "Your written notes are consistently positive, which reinforces what the numbers show.";
        }
        return "Your notes read as balanced, with no dominant emotional theme.";
    }

    /** @return a per-metric weekly summary with change against the previous week. */
    public JsonObject weeklySummary(long studentId) {
        List<BehaviorLog> thisWeek = behaviorLogs.findRecent(studentId, 7);
        List<BehaviorLog> fortnight = behaviorLogs.findRecent(studentId, 14);
        List<BehaviorLog> lastWeek = new ArrayList<>();
        LocalDate boundary = LocalDate.now().minusDays(7);
        for (BehaviorLog log : fortnight) {
            if (log.getLogDate() != null && log.getLogDate().isBefore(boundary)) {
                lastWeek.add(log);
            }
        }

        return JsonObject.of()
                .set("daysLogged", thisWeek.size())
                .set("sleep", metric(thisWeek, lastWeek, BehaviorLog::getSleepHours, "hours"))
                .set("study", metric(thisWeek, lastWeek, BehaviorLog::getStudyHours, "hours"))
                .set("screenTime", metric(thisWeek, lastWeek, BehaviorLog::getScreenTimeHours, "hours"))
                .set("stress", metric(thisWeek, lastWeek, log -> (double) log.getStressLevel(), "/10"))
                .set("exercise", metric(thisWeek, lastWeek, log -> (double) log.getExerciseMinutes(), "minutes"))
                .set("mood", metric(thisWeek, lastWeek, log -> log.getMood().valence() * 10, "/10"))
                .set("attendance", metric(thisWeek, lastWeek, log -> log.attendanceRatio() * 100, "%"));
    }

    private JsonObject metric(List<BehaviorLog> current, List<BehaviorLog> previous,
                              java.util.function.Function<BehaviorLog, Double> extractor, String unit) {
        double currentAverage = average(current, extractor);
        double previousAverage = average(previous, extractor);
        double change = previous.isEmpty() ? 0 : currentAverage - previousAverage;
        return JsonObject.of()
                .set("current", Numbers.round(currentAverage, 1))
                .set("previous", Numbers.round(previousAverage, 1))
                .set("change", Numbers.round(change, 1))
                .set("unit", unit);
    }

    private double average(List<BehaviorLog> logs, java.util.function.Function<BehaviorLog, Double> extractor) {
        if (logs.isEmpty()) {
            return 0;
        }
        double total = 0;
        for (BehaviorLog log : logs) {
            total += extractor.apply(log);
        }
        return total / logs.size();
    }

    /** @return how many of the last {@code days} days have a check-in. */
    public double completeness(long studentId, int days) {
        long logged = behaviorLogs.findRecent(studentId, days).stream()
                .map(BehaviorLog::getLogDate)
                .filter(java.util.Objects::nonNull)
                .distinct()
                .filter(date -> ChronoUnit.DAYS.between(date, LocalDate.now()) < days)
                .count();
        return Numbers.clamp(logged / (double) days, 0, 1);
    }
}
