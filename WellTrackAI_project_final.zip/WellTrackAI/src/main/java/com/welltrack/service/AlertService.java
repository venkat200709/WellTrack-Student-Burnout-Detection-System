package com.welltrack.service;

import com.welltrack.ai.ForecastEngine;
import com.welltrack.core.util.Log;
import com.welltrack.exception.NotFoundException;
import com.welltrack.model.Alert;
import com.welltrack.model.RiskDriver;
import com.welltrack.model.RiskScore;
import com.welltrack.model.Student;
import com.welltrack.model.enums.AlertSeverity;
import com.welltrack.model.enums.TrendDirection;
import com.welltrack.repository.AlertRepository;
import com.welltrack.repository.RiskScoreRepository;

import java.util.List;
import java.util.Optional;

/**
 * Decides when a change in a student's data deserves a human's attention.
 *
 * <p>The hard part of an alerting system is not detecting problems — it is not
 * crying wolf. WellTrack applies four rules:</p>
 * <ul>
 *   <li><b>Band crossings, not absolute values.</b> An alert fires when a
 *       student <em>enters</em> a worse band, so a steady high-risk student does
 *       not generate a notification every quarter of an hour.</li>
 *   <li><b>Predictive alerts.</b> A projected crossing within the next few days
 *       is itself alert-worthy — that is the entire point of a preventive
 *       system.</li>
 *   <li><b>Sharp-decline detection.</b> A large jump inside a single window is
 *       escalated even if the absolute score is still moderate.</li>
 *   <li><b>Daily de-duplication.</b> At most one alert per category per student
 *       per day.</li>
 * </ul>
 */
public final class AlertService {

    private final AlertRepository alerts;
    private final RiskScoreRepository riskScores;
    private final EventBus eventBus;

    public AlertService(AlertRepository alerts, RiskScoreRepository riskScores, EventBus eventBus) {
        this.alerts = alerts;
        this.riskScores = riskScores;
        this.eventBus = eventBus;
    }

    /** Evaluates the alerting rules for a freshly computed score. */
    public void evaluate(Student student, RiskScore score, ForecastEngine.Forecast forecast) {
        List<RiskScore> history = riskScores.findHistory(student.getId(), 3);
        Optional<RiskScore> previous = history.size() >= 2
                ? Optional.of(history.get(history.size() - 2))
                : Optional.empty();

        // Rule 1 — the student moved into a worse band.
        boolean bandWorsened = previous
                .map(before -> score.getLevel().ordinal() > before.getLevel().ordinal())
                .orElse(score.getLevel().requiresIntervention());

        // Raised on entry to an intervention band and, thereafter, at most once a
        // day while the student remains there — a mentor needs the reminder, but
        // not one every fifteen minutes.
        if (score.getLevel().requiresIntervention()) {
            String title = bandWorsened
                    ? "%s has entered the %s band".formatted(student.getFullName(), score.getLevel().label())
                    : "%s remains in the %s band".formatted(student.getFullName(), score.getLevel().label());
            raise(student, score, AlertSeverity.forRisk(score.getLevel()),
                    "BAND_CHANGE", title, buildBandMessage(student, score));
        }

        // Rule 2 — a sharp single-window decline.
        previous.ifPresent(before -> {
            double delta = score.getScore() - before.getScore();
            if (delta >= 15) {
                raise(student, score, AlertSeverity.URGENT, "SHARP_DECLINE",
                        "Sharp wellness decline detected",
                        "%s's burnout score rose by %.0f points since the last analysis (%.0f to %.0f). %s"
                                .formatted(student.getFullName(), delta,
                                        before.getScore(), score.getScore(),
                                        primaryDriverSentence(score)));
            }
        });

        // Rule 3 — a predicted crossing into the high-risk band.
        if (forecast.daysUntilHighRisk() > 0 && !score.getLevel().requiresIntervention()) {
            raise(student, score, AlertSeverity.WARNING, "FORECAST",
                    "Projected to reach high risk in %d day%s".formatted(
                            forecast.daysUntilHighRisk(),
                            forecast.daysUntilHighRisk() == 1 ? "" : "s"),
                    "%s is currently at %.0f/100 but the seven-day projection crosses the high-risk "
                            .formatted(student.getFullName(), score.getScore())
                            + "threshold. Early contact now is far more effective than intervention later. "
                            + primaryDriverSentence(score));
        }

        // Rule 4 — sustained deterioration even without a band change.
        if (score.getTrend() == TrendDirection.WORSENING
                && score.getScore() >= 45
                && !score.getLevel().requiresIntervention()) {
            raise(student, score, AlertSeverity.INFO, "TREND",
                    "Wellness trending downward",
                    "%s has shown a consistent downward trend across the analysis window. %s"
                            .formatted(student.getFullName(), primaryDriverSentence(score)));
        }
    }

    private String buildBandMessage(Student student, RiskScore score) {
        return "%s is now at %.0f/100 (%s). %s %s".formatted(
                student.getFullName(),
                score.getScore(),
                score.getLevel().label(),
                primaryDriverSentence(score),
                score.getLevel().guidance());
    }

    private String primaryDriverSentence(RiskScore score) {
        List<RiskDriver> drivers = score.topAggravators(1);
        return drivers.isEmpty() ? "" : "Primary driver: " + drivers.get(0).explanation();
    }

    private void raise(Student student, RiskScore score, AlertSeverity severity,
                       String category, String title, String message) {
        if (alerts.existsSimilarToday(student.getId(), category)) {
            return;
        }
        Alert alert = new Alert(student.getId(), severity, title, message);
        alert.setStudentName(student.getFullName());
        alert.setCategory(category);
        alert.setTriggeringScore(score.getScore());
        alerts.save(alert);

        eventBus.publishToUser(student.getId(), "alert.created", alert.toJson());
        eventBus.publishToRoles("alert.created", alert.toJson(), List.of("FACULTY", "ADMIN"));
        Log.warn("AlertService", "[" + severity + "] " + title);
    }

    /** Manually raised alert, used when a mentor escalates a conversation. */
    public Alert raiseManual(Student student, String title, String message, AlertSeverity severity) {
        Alert alert = new Alert(student.getId(), severity, title, message);
        alert.setStudentName(student.getFullName());
        alert.setCategory("MANUAL");
        alerts.save(alert);
        eventBus.publishToUser(student.getId(), "alert.created", alert.toJson());
        eventBus.publishToRoles("alert.created", alert.toJson(), List.of("FACULTY", "ADMIN"));
        return alert;
    }

    public Alert acknowledge(long alertId, String actor) {
        Alert alert = alerts.findById(alertId)
                .orElseThrow(() -> new NotFoundException("Alert", alertId));
        alert.acknowledge(actor);
        alerts.save(alert);
        eventBus.publishToRoles("alert.acknowledged", alert.toJson(), List.of("FACULTY", "ADMIN"));
        return alert;
    }

    public List<Alert> forStudent(long studentId) {
        return alerts.findForStudent(studentId);
    }

    public List<Alert> forStudents(List<Long> studentIds) {
        return alerts.findForStudents(studentIds);
    }

    public List<Alert> unacknowledged() {
        return alerts.findUnacknowledged();
    }

    public long unacknowledgedCount(long studentId) {
        return alerts.countUnacknowledged(studentId);
    }
}
