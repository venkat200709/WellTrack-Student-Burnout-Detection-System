package com.welltrack.service;

import com.welltrack.core.json.JsonObject;
import com.welltrack.core.util.Log;

import java.util.List;
import java.util.Map;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.atomic.AtomicLong;

/**
 * An in-process publish/subscribe bus that powers WellTrack's live updates.
 *
 * <p>Each connected browser holds one {@link Subscription}, backed by a bounded
 * {@link LinkedBlockingQueue}. Publishers never block: if a slow client lets its
 * queue fill up, the oldest event is dropped rather than stalling the analysis
 * pipeline. Events are addressed either to a specific user or broadcast to a
 * role, so a student only ever receives their own alerts while faculty receive
 * the cohort feed.</p>
 */
public final class EventBus {

    private static final int QUEUE_CAPACITY = 64;

    /** One connected listener. */
    public static final class Subscription {

        private final String id;
        private final long userId;
        private final String role;
        private final BlockingQueue<JsonObject> queue = new LinkedBlockingQueue<>(QUEUE_CAPACITY);

        private Subscription(String id, long userId, String role) {
            this.id = id;
            this.userId = userId;
            this.role = role;
        }

        public String id() {
            return id;
        }

        public BlockingQueue<JsonObject> queue() {
            return queue;
        }

        private void offer(JsonObject event) {
            if (!queue.offer(event)) {
                queue.poll();
                queue.offer(event);
            }
        }
    }

    private final Map<String, Subscription> subscriptions = new ConcurrentHashMap<>();
    private final AtomicLong published = new AtomicLong();

    public Subscription subscribe(long userId, String role) {
        String id = com.welltrack.core.util.Ids.shortCode(10);
        Subscription subscription = new Subscription(id, userId, role);
        subscriptions.put(id, subscription);
        Log.info("EventBus", "Client " + id + " connected (" + subscriptions.size() + " live)");
        return subscription;
    }

    public void unsubscribe(String id) {
        if (subscriptions.remove(id) != null) {
            Log.info("EventBus", "Client " + id + " disconnected (" + subscriptions.size() + " live)");
        }
    }

    /** Sends an event to one user's open tabs. */
    public void publishToUser(long userId, String type, JsonObject payload) {
        publish(type, payload, subscription -> subscription.userId == userId);
    }

    /** Sends an event to everyone holding one of the given roles. */
    public void publishToRoles(String type, JsonObject payload, List<String> roles) {
        publish(type, payload, subscription -> roles.contains(subscription.role));
    }

    /** Sends an event to every connected client. */
    public void broadcast(String type, JsonObject payload) {
        publish(type, payload, subscription -> true);
    }

    private void publish(String type, JsonObject payload,
                         java.util.function.Predicate<Subscription> filter) {
        JsonObject event = JsonObject.of()
                .set("type", type)
                .set("timestamp", java.time.LocalDateTime.now().toString())
                .set("payload", payload);
        published.incrementAndGet();
        for (Subscription subscription : subscriptions.values()) {
            if (filter.test(subscription)) {
                subscription.offer(event);
            }
        }
    }

    public int listenerCount() {
        return subscriptions.size();
    }

    public long publishedCount() {
        return published.get();
    }
}
