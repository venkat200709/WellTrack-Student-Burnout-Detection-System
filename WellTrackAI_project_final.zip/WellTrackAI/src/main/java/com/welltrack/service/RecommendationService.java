package com.welltrack.service;

import com.welltrack.ai.RecommendationEngine;
import com.welltrack.core.util.Log;
import com.welltrack.exception.NotFoundException;
import com.welltrack.model.Recommendation;
import com.welltrack.model.RiskScore;
import com.welltrack.model.Student;
import com.welltrack.repository.RecommendationRepository;

import java.util.List;
import java.util.Map;
import java.util.function.Supplier;

/**
 * Keeps each student's action plan aligned with their latest analysis.
 *
 * <p>Whenever a score is recomputed, the outstanding plan is regenerated from
 * the new explanation while completed items are preserved as history. The peer
 * comparison used for collaborative boosting is supplied lazily, so the cost of
 * assembling the cohort matrix is only paid when a plan is actually rebuilt.</p>
 */
public final class RecommendationService {

    private final RecommendationRepository recommendations;
    private final RecommendationEngine engine;
    private final EventBus eventBus;

    private Supplier<Map<Long, double[]>> peerFeatureSupplier = Map::of;
    private Supplier<Map<Long, Double>> peerRiskSupplier = Map::of;

    public RecommendationService(RecommendationRepository recommendations,
                                 RecommendationEngine engine,
                                 EventBus eventBus) {
        this.recommendations = recommendations;
        this.engine = engine;
        this.eventBus = eventBus;
    }

    /** Wires in the cohort data used for collaborative filtering. */
    public void bindPeerSuppliers(Supplier<Map<Long, double[]>> features,
                                  Supplier<Map<Long, Double>> risks) {
        this.peerFeatureSupplier = features;
        this.peerRiskSupplier = risks;
    }

    /** Regenerates the outstanding plan for a student. */
    public List<Recommendation> refresh(Student student, RiskScore score, double[] aggregatedFeatures) {
        Map<Long, double[]> peers = peerFeatureSupplier.get();
        Map<Long, Double> peerRisk = peerRiskSupplier.get();
        peers.remove(student.getId());

        Map<String, Double> boosts = engine.collaborativeBoosts(aggregatedFeatures, peers, peerRisk, 8);

        recommendations.clearActive(student.getId());
        List<Recommendation> plan = engine.generate(
                student.getId(), score.getDrivers(), score.getLevel(), boosts, 4);
        plan.forEach(recommendations::save);

        eventBus.publishToUser(student.getId(), "recommendations.updated",
                com.welltrack.core.json.JsonObject.of().set("count", plan.size()));
        return plan;
    }

    public List<Recommendation> active(long studentId) {
        return recommendations.findActive(studentId);
    }

    public List<Recommendation> all(long studentId) {
        return recommendations.findForStudent(studentId);
    }

    /** Marks an item done and returns it, so the caller can award points. */
    public Recommendation complete(long recommendationId, long studentId) {
        Recommendation recommendation = recommendations.findById(recommendationId)
                .orElseThrow(() -> new NotFoundException("Recommendation", recommendationId));
        if (recommendation.getStudentId() != studentId) {
            throw new com.welltrack.exception.AuthorizationException(
                    "You can only complete your own recommendations");
        }
        recommendation.markCompleted();
        recommendations.save(recommendation);
        Log.info("Recommendations", "Completed: " + recommendation.getTitle());
        return recommendation;
    }

    public long completedCount(long studentId) {
        return recommendations.countCompleted(studentId);
    }

    public int knowledgeBaseSize() {
        return engine.knowledgeBaseSize();
    }
}
