package com.welltrack.dto;

import com.welltrack.core.json.JsonObject;
import com.welltrack.core.json.JsonSerializable;
import com.welltrack.model.User;

/** The payload returned by a successful sign-in or registration. */
public record AuthResult(String token, long expiresInSeconds, User user, String message)
        implements JsonSerializable {

    @Override
    public JsonObject toJson() {
        return JsonObject.of()
                .set("success", true)
                .set("token", token)
                .set("expiresIn", expiresInSeconds)
                .set("message", message)
                .set("user", user.toJson());
    }
}
