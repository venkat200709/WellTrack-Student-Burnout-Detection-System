package com.welltrack.dto;

import com.welltrack.core.json.JsonObject;
import com.welltrack.core.util.Validation;

/**
 * Immutable carrier for sign-in credentials.
 *
 * <p>Implemented as a {@code record}: the compiler generates the constructor,
 * accessors, {@code equals}, {@code hashCode} and {@code toString}, and the
 * value can never be mutated after validation — exactly what a request object
 * should be.</p>
 */
public record LoginRequest(String identifier, String password, boolean rememberMe) {

    /** Builds and validates a request straight from the JSON body. */
    public static LoginRequest from(JsonObject body) {
        LoginRequest request = new LoginRequest(
                trim(body.getString("identifier", body.getString("username", ""))),
                body.getString("password", ""),
                body.getBoolean("rememberMe", false));
        Validation.check()
                .required("identifier", request.identifier())
                .required("password", request.password())
                .maxLength("identifier", request.identifier(), 120)
                .maxLength("password", request.password(), 200)
                .throwIfInvalid();
        return request;
    }

    private static String trim(String value) {
        return value == null ? "" : value.trim();
    }

    /** Never expose the password through logs or error messages. */
    @Override
    public String toString() {
        return "LoginRequest{identifier='%s', rememberMe=%s}".formatted(identifier, rememberMe);
    }
}
