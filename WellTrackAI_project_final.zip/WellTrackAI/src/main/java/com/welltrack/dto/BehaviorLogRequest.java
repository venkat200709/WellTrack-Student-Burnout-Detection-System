package com.welltrack.dto;

import com.welltrack.core.json.JsonObject;
import com.welltrack.core.util.Validation;
import com.welltrack.model.BehaviorLog;
import com.welltrack.model.enums.Mood;

import java.time.LocalDate;

/**
 * Validated carrier for a daily check-in.
 *
 * <p>Every numeric field is range-checked, which keeps physically impossible
 * values (a 30-hour sleep, a negative stress level) out of the model's training
 * data — data hygiene is what makes the AI layer trustworthy.</p>
 */
public record BehaviorLogRequest(LocalDate logDate,
                                 double sleepHours,
                                 double studyHours,
                                 double screenTimeHours,
                                 int exerciseMinutes,
                                 int socialMinutes,
                                 int stressLevel,
                                 Mood mood,
                                 int classesAttended,
                                 int classesScheduled,
                                 int assignmentsPending,
                                 int caffeineCups,
                                 int mealsSkipped,
                                 int deadlinePressure,
                                 String journalNote) {

    public static BehaviorLogRequest from(JsonObject body) {
        String rawDate = body.getString("logDate", LocalDate.now().toString());
        LocalDate date;
        try {
            date = LocalDate.parse(rawDate);
        } catch (RuntimeException e) {
            throw new com.welltrack.exception.ValidationException(
                    "Please correct the highlighted fields",
                    java.util.Map.of("logDate", "Use the format YYYY-MM-DD"));
        }

        BehaviorLogRequest request = new BehaviorLogRequest(
                date,
                body.getDouble("sleepHours", 7),
                body.getDouble("studyHours", 4),
                body.getDouble("screenTimeHours", 4),
                body.getInt("exerciseMinutes", 0),
                body.getInt("socialMinutes", 0),
                body.getInt("stressLevel", 5),
                Mood.from(body.getString("mood", Mood.NEUTRAL.name())),
                body.getInt("classesAttended", 0),
                body.getInt("classesScheduled", 0),
                body.getInt("assignmentsPending", 0),
                body.getInt("caffeineCups", 0),
                body.getInt("mealsSkipped", 0),
                body.getInt("deadlinePressure", 3),
                body.getString("journalNote", ""));

        Validation.check()
                .notFuture("logDate", request.logDate())
                .range("sleepHours", request.sleepHours(), 0, 24)
                .range("studyHours", request.studyHours(), 0, 20)
                .range("screenTimeHours", request.screenTimeHours(), 0, 24)
                .range("exerciseMinutes", request.exerciseMinutes(), 0, 600)
                .range("socialMinutes", request.socialMinutes(), 0, 900)
                .range("stressLevel", request.stressLevel(), 1, 10)
                .range("classesAttended", request.classesAttended(), 0, 12)
                .range("classesScheduled", request.classesScheduled(), 0, 12)
                .range("assignmentsPending", request.assignmentsPending(), 0, 40)
                .range("caffeineCups", request.caffeineCups(), 0, 15)
                .range("mealsSkipped", request.mealsSkipped(), 0, 5)
                .range("deadlinePressure", request.deadlinePressure(), 0, 10)
                .maxLength("journalNote", request.journalNote(), 600)
                .rejectIf(request.classesAttended() > request.classesScheduled(),
                        "classesAttended", "Attended classes cannot exceed scheduled classes")
                .rejectIf(request.sleepHours() + request.studyHours() > 24,
                        "studyHours", "Sleep and study hours together cannot exceed a day")
                .throwIfInvalid();
        return request;
    }

    /** Projects this request onto a persistable entity. */
    public BehaviorLog toEntity(long studentId) {
        BehaviorLog log = new BehaviorLog(studentId, logDate);
        log.setSleepHours(sleepHours);
        log.setStudyHours(studyHours);
        log.setScreenTimeHours(screenTimeHours);
        log.setExerciseMinutes(exerciseMinutes);
        log.setSocialMinutes(socialMinutes);
        log.setStressLevel(stressLevel);
        log.setMood(mood);
        log.setClassesAttended(classesAttended);
        log.setClassesScheduled(classesScheduled);
        log.setAssignmentsPending(assignmentsPending);
        log.setCaffeineCups(caffeineCups);
        log.setMealsSkipped(mealsSkipped);
        log.setDeadlinePressure(deadlinePressure);
        log.setJournalNote(journalNote);
        return log;
    }
}
