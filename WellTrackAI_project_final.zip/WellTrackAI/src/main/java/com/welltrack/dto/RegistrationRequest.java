package com.welltrack.dto;

import com.welltrack.core.json.JsonObject;
import com.welltrack.core.util.Validation;

/**
 * Immutable carrier for a new student account, validated at construction time
 * against WellTrack's full registration policy.
 */
public record RegistrationRequest(String username,
                                  String email,
                                  String fullName,
                                  String password,
                                  String confirmPassword,
                                  String registerNumber,
                                  String department,
                                  String section,
                                  int yearOfStudy) {

    public static RegistrationRequest from(JsonObject body) {
        RegistrationRequest request = new RegistrationRequest(
                text(body, "username"),
                text(body, "email").toLowerCase(),
                text(body, "fullName"),
                body.getString("password", ""),
                body.getString("confirmPassword", ""),
                text(body, "registerNumber"),
                text(body, "department").isBlank() ? "CSE" : text(body, "department"),
                text(body, "section").isBlank() ? "A" : text(body, "section"),
                body.getInt("yearOfStudy", 1));

        Validation.check()
                .required("username", request.username())
                .username("username", request.username())
                .required("email", request.email())
                .email("email", request.email())
                .required("fullName", request.fullName())
                .minLength("fullName", request.fullName(), 3)
                .maxLength("fullName", request.fullName(), 80)
                .required("password", request.password())
                .password("password", request.password())
                .required("confirmPassword", request.confirmPassword())
                .matches("confirmPassword", request.confirmPassword(), request.password(),
                        "Passwords do not match")
                .required("registerNumber", request.registerNumber())
                .registerNumber("registerNumber", request.registerNumber())
                .range("yearOfStudy", request.yearOfStudy(), 1, 5)
                .throwIfInvalid();
        return request;
    }

    private static String text(JsonObject body, String key) {
        return body.getString(key, "").trim();
    }

    @Override
    public String toString() {
        return "RegistrationRequest{username='%s', email='%s', registerNumber='%s'}"
                .formatted(username, email, registerNumber);
    }
}
