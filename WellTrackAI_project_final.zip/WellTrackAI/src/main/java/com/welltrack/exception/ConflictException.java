package com.welltrack.exception;

import com.welltrack.core.http.HttpStatus;

/** Raised when an operation would violate a uniqueness or state constraint. */
public class ConflictException extends ApiException {

    private static final long serialVersionUID = 1L;

    public ConflictException(String message) {
        super(HttpStatus.CONFLICT, message);
    }
}
