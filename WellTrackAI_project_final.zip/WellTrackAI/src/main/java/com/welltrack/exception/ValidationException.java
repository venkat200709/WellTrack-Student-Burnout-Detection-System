package com.welltrack.exception;

import com.welltrack.core.http.HttpStatus;

import java.util.Map;

/** Raised when submitted data fails validation; carries per-field messages. */
public class ValidationException extends ApiException {

    private static final long serialVersionUID = 1L;

    private final Map<String, String> fieldErrors;

    public ValidationException(String message, Map<String, String> fieldErrors) {
        super(HttpStatus.UNPROCESSABLE, message);
        this.fieldErrors = Map.copyOf(fieldErrors);
    }

    public Map<String, String> fieldErrors() {
        return fieldErrors;
    }
}
