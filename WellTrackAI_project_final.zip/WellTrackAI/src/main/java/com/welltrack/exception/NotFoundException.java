package com.welltrack.exception;

import com.welltrack.core.http.HttpStatus;

/** Raised when a requested entity does not exist. */
public class NotFoundException extends ApiException {

    private static final long serialVersionUID = 1L;

    public NotFoundException(String entity, Object id) {
        super(HttpStatus.NOT_FOUND, "%s '%s' was not found".formatted(entity, id));
    }

    public NotFoundException(String message) {
        super(HttpStatus.NOT_FOUND, message);
    }
}
