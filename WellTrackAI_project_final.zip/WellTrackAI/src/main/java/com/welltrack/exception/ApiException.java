package com.welltrack.exception;

import com.welltrack.core.http.HttpStatus;

/**
 * Base class for every business-level failure in WellTrack.
 *
 * <p>Carrying the HTTP status inside the exception lets the transport layer
 * translate domain failures into correct responses without a chain of
 * {@code instanceof} checks — a small but effective use of polymorphism.</p>
 */
public class ApiException extends RuntimeException {

    private static final long serialVersionUID = 1L;

    private final HttpStatus status;

    public ApiException(HttpStatus status, String message) {
        super(message);
        this.status = status;
    }

    public ApiException(HttpStatus status, String message, Throwable cause) {
        super(message, cause);
        this.status = status;
    }

    public HttpStatus status() {
        return status;
    }
}
