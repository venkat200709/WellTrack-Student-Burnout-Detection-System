package com.welltrack.exception;

import com.welltrack.core.http.HttpStatus;

/** Raised when credentials are missing, malformed, expired or incorrect. */
public class AuthenticationException extends ApiException {

    private static final long serialVersionUID = 1L;

    public AuthenticationException(String message) {
        super(HttpStatus.UNAUTHORIZED, message);
    }
}
