package com.welltrack.exception;

import com.welltrack.core.http.HttpStatus;

/** Raised when the datastore cannot read or write. */
public class PersistenceException extends ApiException {

    private static final long serialVersionUID = 1L;

    public PersistenceException(String message, Throwable cause) {
        super(HttpStatus.SERVER_ERROR, message, cause);
    }
}
