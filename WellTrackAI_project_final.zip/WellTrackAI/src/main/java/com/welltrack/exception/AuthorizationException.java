package com.welltrack.exception;

import com.welltrack.core.http.HttpStatus;

/** Raised when an authenticated user lacks the role required by an endpoint. */
public class AuthorizationException extends ApiException {

    private static final long serialVersionUID = 1L;

    public AuthorizationException(String message) {
        super(HttpStatus.FORBIDDEN, message);
    }
}
