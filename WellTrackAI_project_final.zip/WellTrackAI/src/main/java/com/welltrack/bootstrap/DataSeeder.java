package com.welltrack.bootstrap;

import com.welltrack.ai.TrainingDataFactory;
import com.welltrack.core.util.Log;
import com.welltrack.model.Administrator;
import com.welltrack.model.BehaviorLog;
import com.welltrack.model.Faculty;
import com.welltrack.model.Student;
import com.welltrack.model.enums.Mood;
import com.welltrack.repository.BehaviorLogRepository;
import com.welltrack.repository.UserRepository;
import com.welltrack.security.PasswordEncoder;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/**
 * Populates a fresh installation with a realistic demonstration dataset.
 *
 * <p>The seeder runs only when the datastore is empty, so real data is never
 * overwritten. Each demonstration student is given a deliberate <em>narrative
 * arc</em> rather than random noise — one deteriorating through the term, one
 * recovering, one steady, one volatile — because that is what makes the
 * forecasting, anomaly detection and cohort clustering visibly demonstrate
 * something rather than merely execute.</p>
 *
 * <p>Daily entries are produced by the same generative simulator that trains
 * the model ({@link TrainingDataFactory}), so the seeded behaviour is
 * statistically consistent with what the classifier learned.</p>
 */
public final class DataSeeder {

    private static final int HISTORY_DAYS = 90;

    private final UserRepository users;
    private final BehaviorLogRepository behaviorLogs;
    private final PasswordEncoder passwordEncoder;

    public DataSeeder(UserRepository users,
                      BehaviorLogRepository behaviorLogs,
                      PasswordEncoder passwordEncoder) {
        this.users = users;
        this.behaviorLogs = behaviorLogs;
        this.passwordEncoder = passwordEncoder;
    }

    /** @return true when seeding actually ran. */
    public boolean seedIfEmpty() {
        if (!users.isEmpty()) {
            Log.info("DataSeeder", "Existing data found — seeding skipped");
            return false;
        }
        long started = System.currentTimeMillis();
        Log.info("DataSeeder", "Empty datastore detected — generating the demonstration dataset");

        Administrator admin = new Administrator("admin", "admin@welltrack.edu",
                "Institution Administrator", passwordEncoder.encode("Admin@2026"));
        users.save(admin);

        Faculty vignesh = new Faculty("vignesh", "vignesh@cit.edu.in", "Dr. Vignesh T",
                passwordEncoder.encode("Faculty@2026"), "CIT-CSE-114", "CSE", "Professor");
        users.save(vignesh);

        Faculty priya = new Faculty("priya", "priya@cit.edu.in", "Dr. Priya Raghavan",
                passwordEncoder.encode("Faculty@2026"), "CIT-CSE-207", "CSE", "Associate Professor");
        users.save(priya);

        // name, username, register number, section, baseline propensity, drift, mentor
        Object[][] profiles = {
                {"Venkatesan N", "venkat", "2104251040604", "A", 0.30, 0.34, vignesh},
                {"Needhivendhan T", "needhi", "2104251040629", "A", 0.22, -0.14, vignesh},
                {"Aarthi Krishnan", "aarthi", "2104251040611", "A", 0.58, 0.26, vignesh},
                {"Rohit Sharma", "rohit", "2104251040618", "A", 0.15, 0.05, vignesh},
                {"Divya Menon", "divya", "2104251040622", "B", 0.44, -0.28, priya},
                {"Karthik Subramani", "karthik", "2104251040635", "B", 0.66, 0.18, priya},
                {"Sneha Iyer", "sneha", "2104251040641", "B", 0.26, 0.08, priya},
                {"Arjun Prasad", "arjun", "2104251040649", "B", 0.51, -0.06, priya},
                {"Meera Nair", "meera", "2104251040653", "A", 0.19, 0.12, vignesh},
                {"Sanjay Kumar", "sanjay", "2104251040660", "B", 0.72, 0.08, priya}
        };

        Random random = new Random(20260811L);
        List<BehaviorLog> allLogs = new ArrayList<>();

        for (Object[] profile : profiles) {
            Student student = new Student(
                    (String) profile[1],
                    profile[1] + "@cit.edu.in",
                    (String) profile[0],
                    passwordEncoder.encode("Student@2026"),
                    (String) profile[2],
                    "CSE",
                    (String) profile[3],
                    3);
            Faculty mentor = (Faculty) profile[6];
            student.setMentorId(mentor.getId());
            student.setCreditLoad(22 + random.nextInt(6));
            student.setCgpa(Math.round((7.0 + random.nextDouble() * 2.6) * 100) / 100.0);
            student.setHostelStatus(random.nextBoolean() ? "Hosteller" : "Day Scholar");
            users.save(student);

            allLogs.addAll(generateHistory(student, (Double) profile[4], (Double) profile[5], random));
        }

        behaviorLogs.saveAll(allLogs);

        Log.success("DataSeeder", "Seeded %d accounts and %,d behavioural records in %d ms"
                .formatted(users.count(), allLogs.size(), System.currentTimeMillis() - started));
        Log.banner("""
                
                   Demonstration accounts (password shown in brackets)
                   ---------------------------------------------------
                   Student        venkat    [Student@2026]   rising risk through the term
                   Student        needhi    [Student@2026]   steadily recovering
                   Student        sanjay    [Student@2026]   sustained high risk
                   Faculty        vignesh   [Faculty@2026]   mentor console
                   Administrator  admin     [Admin@2026]     institution console
                """);
        return true;
    }

    /**
     * Builds one student's ninety-day history from a smoothly varying latent
     * burnout propensity, so charts show a story with a weekly rhythm and a
     * mid-term examination peak.
     */
    private List<BehaviorLog> generateHistory(Student student, double baseline,
                                              double drift, Random random) {
        List<BehaviorLog> logs = new ArrayList<>(HISTORY_DAYS);
        LocalDate start = LocalDate.now().minusDays(HISTORY_DAYS - 1);
        int attendedTotal = 0;
        int scheduledTotal = 0;

        for (int day = 0; day < HISTORY_DAYS; day++) {
            LocalDate date = start.plusDays(day);

            // Occasional missed check-ins keep the data honest.
            if (day < HISTORY_DAYS - 14 && random.nextDouble() < 0.10) {
                continue;
            }

            double propensity =
                    TrainingDataFactory.propensityForDay(baseline, drift, day, HISTORY_DAYS, random);
            double[] vector = TrainingDataFactory.simulateDay(propensity, random);

            boolean weekend = date.getDayOfWeek().getValue() >= 6;
            int scheduled = weekend ? 0 : 5 + random.nextInt(2);
            int attended = (int) Math.round(scheduled * vector[9]);

            BehaviorLog log = new BehaviorLog(student.getId(), date);
            log.setSleepHours(round(vector[0], 1));
            log.setStudyHours(round(weekend ? vector[2] * 0.7 : vector[2], 1));
            log.setScreenTimeHours(round(vector[4], 1));
            log.setExerciseMinutes((int) Math.round(vector[5]));
            log.setSocialMinutes((int) Math.round(vector[6]));
            log.setStressLevel((int) Math.round(vector[7]));
            log.setMood(Mood.closestTo(vector[8]));
            log.setClassesScheduled(scheduled);
            log.setClassesAttended(attended);
            log.setAssignmentsPending((int) Math.round(vector[10]));
            log.setCaffeineCups((int) Math.round(vector[11]));
            log.setMealsSkipped((int) Math.round(vector[12]));
            log.setDeadlinePressure((int) Math.round(vector[13]));
            log.setJournalNote(journalFor(propensity, random));
            log.setCreatedAt(date.atTime(21, 30));
            logs.add(log);

            attendedTotal += attended;
            scheduledTotal += scheduled;
        }

        if (scheduledTotal > 0) {
            student.setAttendancePercentage(round(attendedTotal * 100.0 / scheduledTotal, 1));
        }
        student.setWellnessPoints(60 + random.nextInt(340));
        student.setStreakDays(computeTrailingStreak(logs));
        users.save(student);
        return logs;
    }

    private int computeTrailingStreak(List<BehaviorLog> logs) {
        java.util.Set<LocalDate> dates = new java.util.HashSet<>();
        logs.forEach(log -> dates.add(log.getLogDate()));
        LocalDate cursor = LocalDate.now();
        int streak = 0;
        while (dates.contains(cursor)) {
            streak++;
            cursor = cursor.minusDays(1);
        }
        return streak;
    }

    /**
     * Writes a journal note whose tone matches the latent state, giving the
     * sentiment analyser genuine material rather than lorem ipsum.
     */
    private String journalFor(double propensity, Random random) {
        if (random.nextDouble() < 0.45) {
            return "";
        }
        String[] thriving = {
                "Slept well and finished the lab record early. Feeling on top of things.",
                "Good day. Gym in the morning, and the DSA problems finally clicked.",
                "Went out with friends after class, came back genuinely refreshed.",
                "Managed my time properly today and still had an evening free."
        };
        String[] moderate = {
                "A bit behind on the assignment but nothing unmanageable yet.",
                "Tired through the afternoon lectures, though the evening was okay.",
                "Too much screen time today. Need to sleep earlier tomorrow.",
                "Average day. Some progress, some procrastination."
        };
        String[] strained = {
                "Slept badly again and I am really struggling to focus in class.",
                "Completely overwhelmed by the number of deadlines this week. Skipped lunch again.",
                "Exhausted. I studied for six hours and barely remember any of it.",
                "Feeling anxious and very isolated. Have not spoken to anyone properly in days.",
                "Cannot keep up with the workload. Everything feels like it is piling on."
        };
        String[] pool = propensity < 0.35 ? thriving : propensity < 0.62 ? moderate : strained;
        return pool[random.nextInt(pool.length)];
    }

    private static double round(double value, int decimals) {
        double factor = Math.pow(10, decimals);
        return Math.round(value * factor) / factor;
    }
}
