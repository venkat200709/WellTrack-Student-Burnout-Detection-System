package com.welltrack;

import com.welltrack.ai.BurnoutPredictor;
import com.welltrack.ai.CohortAnalyzer;
import com.welltrack.ai.ForecastEngine;
import com.welltrack.ai.LlmClient;
import com.welltrack.ai.RecommendationEngine;
import com.welltrack.ai.WellnessCoach;
import com.welltrack.bootstrap.DataSeeder;
import com.welltrack.controller.AiController;
import com.welltrack.controller.AuthController;
import com.welltrack.controller.BehaviorController;
import com.welltrack.controller.ChatController;
import com.welltrack.controller.DashboardController;
import com.welltrack.controller.ExportController;
import com.welltrack.controller.FacultyController;
import com.welltrack.controller.RecommendationController;
import com.welltrack.controller.RiskController;
import com.welltrack.controller.StudentController;
import com.welltrack.controller.SystemController;
import com.welltrack.core.di.ServiceRegistry;
import com.welltrack.core.http.CommonFilters;
import com.welltrack.core.http.EventStreamHandler;
import com.welltrack.core.http.Router;
import com.welltrack.core.http.StaticResourceHandler;
import com.welltrack.core.http.WebServer;
import com.welltrack.core.util.AppConfig;
import com.welltrack.core.util.Log;
import com.welltrack.model.Student;
import com.welltrack.repository.AlertRepository;
import com.welltrack.repository.AuditEventRepository;
import com.welltrack.repository.BadgeRepository;
import com.welltrack.repository.BehaviorLogRepository;
import com.welltrack.repository.ChatMessageRepository;
import com.welltrack.repository.RecommendationRepository;
import com.welltrack.repository.RiskScoreRepository;
import com.welltrack.repository.UserRepository;
import com.welltrack.repository.datastore.Datastore;
import com.welltrack.repository.datastore.FileDatastore;
import com.welltrack.repository.datastore.JdbcDatastore;
import com.welltrack.security.AuthService;
import com.welltrack.security.PasswordEncoder;
import com.welltrack.security.Pbkdf2PasswordEncoder;
import com.welltrack.security.SecurityFilter;
import com.welltrack.security.SessionRegistry;
import com.welltrack.security.TokenService;
import com.welltrack.service.AlertService;
import com.welltrack.service.AnalyticsService;
import com.welltrack.service.BehaviorService;
import com.welltrack.service.ChatService;
import com.welltrack.service.EventBus;
import com.welltrack.service.ExportService;
import com.welltrack.service.GamificationService;
import com.welltrack.service.RecommendationService;
import com.welltrack.service.RiskAnalysisService;
import com.welltrack.service.StudentService;

import java.nio.file.Path;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * <h2>WellTrack — Student Burnout Detection &amp; Wellness Monitoring System</h2>
 *
 * <p>Application entry point and composition root. Running this class starts
 * the whole product: the embedded HTTP server, the datastore, the AI engine and
 * the web interface. There is nothing else to install — no build tool, no
 * database server, no framework, no third-party jar.</p>
 *
 * <p><b>Start-up sequence</b></p>
 * <ol>
 *   <li>Resolve configuration and choose the datastore implementation.</li>
 *   <li>Register every component in the {@link ServiceRegistry} (the composition root).</li>
 *   <li>Load all repositories into memory.</li>
 *   <li>Seed the demonstration dataset when the datastore is empty.</li>
 *   <li>Train the burnout model on a background thread, then run the first
 *       cohort-wide analysis.</li>
 *   <li>Wire the routing table and start the web server.</li>
 * </ol>
 *
 * <p>The application is usable the instant the server binds — the AI upgrade
 * from heuristic to trained model happens transparently a moment later.</p>
 *
 * @author  Venkatesan N (2104251040604) &amp; Needhivendhan T (2104251040629)
 * @version 2.0.0
 */
public final class WellTrackApplication {

    private static final String VERSION = "2.0.0";

    private final ServiceRegistry registry = new ServiceRegistry();
    private WebServer webServer;

    public static void main(String[] args) {
        Log.banner("""
                
                  ██╗    ██╗███████╗██╗     ██╗  ████████╗██████╗  █████╗  ██████╗██╗  ██╗
                  ██║    ██║██╔════╝██║     ██║  ╚══██╔══╝██╔══██╗██╔══██╗██╔════╝██║ ██╔╝
                  ██║ █╗ ██║█████╗  ██║     ██║     ██║   ██████╔╝███████║██║     █████╔╝
                  ██║███╗██║██╔══╝  ██║     ██║     ██║   ██╔══██╗██╔══██║██║     ██╔═██╗
                  ╚███╔███╔╝███████╗███████╗███████╗██║   ██║  ██║██║  ██║╚██████╗██║  ██╗
                   ╚══╝╚══╝ ╚══════╝╚══════╝╚══════╝╚═╝   ╚═╝  ╚═╝╚═╝  ╚═╝ ╚═════╝╚═╝  ╚═╝
                
                     Intelligent Student Burnout Detection & Wellness Monitoring System  v%s
                  Zero external dependencies · Pure Java %s
                """.formatted(VERSION, System.getProperty("java.version")));

        WellTrackApplication application = new WellTrackApplication();
        try {
            application.start();
        } catch (Exception e) {
            Log.error("WellTrack", "Start-up failed", e);
            System.exit(1);
        }
    }

    /** Boots every layer of the application. */
    public void start() throws Exception {
        long started = System.currentTimeMillis();
        AppConfig config = AppConfig.get();

        // ---------- 1. Persistence ------------------------------------
        Datastore datastore = createDatastore(config);
        registry.registerInstance(Datastore.class, datastore);

        registry.register(UserRepository.class, () -> new UserRepository(datastore));
        registry.register(BehaviorLogRepository.class, () -> new BehaviorLogRepository(datastore));
        registry.register(RiskScoreRepository.class, () -> new RiskScoreRepository(datastore));
        registry.register(AlertRepository.class, () -> new AlertRepository(datastore));
        registry.register(RecommendationRepository.class, () -> new RecommendationRepository(datastore));
        registry.register(ChatMessageRepository.class, () -> new ChatMessageRepository(datastore));
        registry.register(BadgeRepository.class, () -> new BadgeRepository(datastore));
        registry.register(AuditEventRepository.class, () -> new AuditEventRepository(datastore));

        // ---------- 2. Security ---------------------------------------
        registry.register(PasswordEncoder.class, Pbkdf2PasswordEncoder::new);
        registry.register(SessionRegistry.class, SessionRegistry::new);
        registry.register(TokenService.class, () -> new TokenService(
                config.string("security.jwt-secret", ""),
                config.integer("security.token-lifetime-seconds", 43_200)));
        registry.register(AuthService.class, () -> new AuthService(
                registry.get(UserRepository.class),
                registry.get(AuditEventRepository.class),
                registry.get(PasswordEncoder.class),
                registry.get(TokenService.class),
                registry.get(SessionRegistry.class)));

        // ---------- 3. Scoring engine ---------------------------------
        registry.register(LlmClient.class, LlmClient::new);
        registry.register(BurnoutPredictor.class, BurnoutPredictor::new);
        registry.register(ForecastEngine.class, ForecastEngine::new);
        registry.register(CohortAnalyzer.class, CohortAnalyzer::new);
        registry.register(RecommendationEngine.class, RecommendationEngine::new);
        registry.register(WellnessCoach.class, () -> new WellnessCoach(registry.get(LlmClient.class)));

        // ---------- 4. Services ---------------------------------------
        registry.register(EventBus.class, EventBus::new);
        registry.register(StudentService.class, () -> new StudentService(
                registry.get(UserRepository.class), registry.get(BehaviorLogRepository.class)));
        registry.register(BehaviorService.class, () -> new BehaviorService(
                registry.get(BehaviorLogRepository.class), registry.get(UserRepository.class)));
        registry.register(AlertService.class, () -> new AlertService(
                registry.get(AlertRepository.class), registry.get(RiskScoreRepository.class),
                registry.get(EventBus.class)));
        registry.register(RecommendationService.class, () -> new RecommendationService(
                registry.get(RecommendationRepository.class),
                registry.get(RecommendationEngine.class),
                registry.get(EventBus.class)));
        registry.register(GamificationService.class, () -> new GamificationService(
                registry.get(BadgeRepository.class), registry.get(BehaviorLogRepository.class),
                registry.get(UserRepository.class), registry.get(EventBus.class)));
        registry.register(RiskAnalysisService.class, () -> new RiskAnalysisService(
                registry.get(UserRepository.class),
                registry.get(BehaviorLogRepository.class),
                registry.get(RiskScoreRepository.class),
                registry.get(BurnoutPredictor.class),
                registry.get(ForecastEngine.class),
                registry.get(CohortAnalyzer.class),
                registry.get(AlertService.class),
                registry.get(RecommendationService.class),
                registry.get(EventBus.class)));
        registry.register(ChatService.class, () -> new ChatService(
                registry.get(ChatMessageRepository.class),
                registry.get(RiskScoreRepository.class),
                registry.get(BehaviorService.class),
                registry.get(WellnessCoach.class),
                registry.get(AlertService.class)));
        registry.register(AnalyticsService.class, () -> new AnalyticsService(
                registry.get(UserRepository.class),
                registry.get(BehaviorLogRepository.class),
                registry.get(RiskScoreRepository.class),
                registry.get(AlertRepository.class),
                registry.get(CohortAnalyzer.class)));
        registry.register(ExportService.class, () -> new ExportService(
                registry.get(BehaviorLogRepository.class), registry.get(RiskScoreRepository.class)));

        registry.initialiseAll();

        // ---------- 5. Load and seed ----------------------------------
        loadRepositories();
        new DataSeeder(registry.get(UserRepository.class),
                registry.get(BehaviorLogRepository.class),
                registry.get(PasswordEncoder.class)).seedIfEmpty();

        wirePeerSuppliers();

        // ---------- 6. Routing and server -----------------------------
        Router router = buildRouter();
        StaticResourceHandler staticResources =
                new StaticResourceHandler(config.flag("web.cache", true));

        webServer = new WebServer(
                config.integer("server.port", 8080),
                config.integer("server.threads", 32),
                router,
                staticResources);

        webServer.addFilter(CommonFilters.correlationId())
                .addFilter(CommonFilters.cors())
                .addFilter(CommonFilters.payloadLimit(256 * 1024))
                .addFilter(new SecurityFilter(router, registry.get(AuthService.class)))
                .addRawContext("/api/stream", new EventStreamHandler(
                        registry.get(AuthService.class), registry.get(EventBus.class)));

        webServer.start();
        router.printRoutingTable();
        Runtime.getRuntime().addShutdownHook(new Thread(this::stop, "welltrack-shutdown"));

        // ---------- 7. Train the AI in the background -----------------
        trainModelAsync();

        Log.success("WellTrack", "Application ready in %d ms"
                .formatted(System.currentTimeMillis() - started));
        Log.banner("""
                
                   ▶  Open  http://localhost:%d  in your browser
                
                """.formatted(config.integer("server.port", 8080)));
    }

    private Datastore createDatastore(AppConfig config) {
        String kind = config.string("datastore", "file").toLowerCase();
        if ("memory".equals(kind)) {
            return new com.welltrack.repository.datastore.InMemoryDatastore();
        }
        if ("jdbc".equals(kind)) {
            return new JdbcDatastore(
                    config.string("jdbc.url", "jdbc:h2:./data/welltrack;AUTO_SERVER=TRUE"),
                    config.string("jdbc.user", "sa"),
                    config.string("jdbc.password", ""));
        }
        return new FileDatastore(Path.of(config.string("data-directory", "data")));
    }

    private void loadRepositories() {
        registry.get(UserRepository.class).load();
        registry.get(BehaviorLogRepository.class).load();
        registry.get(RiskScoreRepository.class).load();
        registry.get(AlertRepository.class).load();
        registry.get(RecommendationRepository.class).load();
        registry.get(ChatMessageRepository.class).load();
        registry.get(BadgeRepository.class).load();
        registry.get(AuditEventRepository.class).load();
    }

    /**
     * Supplies the recommender with a live view of the cohort for its
     * collaborative-filtering step, without creating a circular dependency
     * between the two services.
     */
    private void wirePeerSuppliers() {
        RiskAnalysisService riskService = registry.get(RiskAnalysisService.class);
        UserRepository users = registry.get(UserRepository.class);
        RiskScoreRepository scores = registry.get(RiskScoreRepository.class);

        registry.get(RecommendationService.class).bindPeerSuppliers(
                () -> {
                    Map<Long, double[]> features = new HashMap<>();
                    for (Student student : users.findAllStudents()) {
                        features.put(student.getId(), riskService.aggregatedFeatures(student.getId()));
                    }
                    return features;
                },
                () -> {
                    Map<Long, Double> risks = new HashMap<>();
                    for (Student student : users.findAllStudents()) {
                        scores.findLatest(student.getId())
                                .ifPresent(score -> risks.put(student.getId(), score.getScore()));
                    }
                    return risks;
                });
    }

    private Router buildRouter() {
        Router router = new Router();

        new AuthController(registry.get(AuthService.class)).register(router);
        new StudentController(registry.get(StudentService.class)).register(router);
        new BehaviorController(registry.get(BehaviorService.class),
                registry.get(StudentService.class),
                registry.get(RiskAnalysisService.class),
                registry.get(GamificationService.class)).register(router);
        new RiskController(registry.get(RiskAnalysisService.class),
                registry.get(StudentService.class),
                registry.get(RiskScoreRepository.class)).register(router);
        new DashboardController(registry.get(StudentService.class),
                registry.get(BehaviorService.class),
                registry.get(RiskAnalysisService.class),
                registry.get(RecommendationService.class),
                registry.get(AlertService.class),
                registry.get(GamificationService.class),
                registry.get(CohortAnalyzer.class)).register(router);
        new AiController(registry.get(BurnoutPredictor.class),
                registry.get(CohortAnalyzer.class),
                registry.get(WellnessCoach.class),
                registry.get(RecommendationEngine.class),
                registry.get(RiskAnalysisService.class),
                registry.get(StudentService.class)).register(router);
        new ChatController(registry.get(ChatService.class),
                registry.get(StudentService.class)).register(router);
        new RecommendationController(registry.get(RecommendationService.class),
                registry.get(GamificationService.class),
                registry.get(StudentService.class)).register(router);
        new FacultyController(registry.get(AnalyticsService.class),
                registry.get(StudentService.class),
                registry.get(AlertService.class)).register(router);
        new ExportController(registry.get(ExportService.class),
                registry.get(StudentService.class)).register(router);
        new SystemController(() -> webServer,
                registry.get(Datastore.class),
                registry.get(UserRepository.class),
                registry.get(BehaviorLogRepository.class),
                registry.get(AuditEventRepository.class),
                registry.get(SessionRegistry.class),
                registry.get(EventBus.class)).register(router);

        return router;
    }

    /**
     * Trains the classifier off the request path so the server is responsive
     * immediately, then runs the first full cohort analysis and starts the
     * periodic re-analysis daemon.
     */
    private void trainModelAsync() {
        Thread trainer = new Thread(() -> {
            try {
                registry.get(BurnoutPredictor.class).train();
                RiskAnalysisService riskService = registry.get(RiskAnalysisService.class);
                long started = System.currentTimeMillis();

                // Reconstruct each student's risk history so the trend charts and
                // the forecaster have a genuine series to work with from the very
                // first page load.
                int backfilled = 0;
                for (Student student : registry.get(UserRepository.class).findAllStudents()) {
                    backfilled += riskService.backfillHistory(student, 60);
                    registry.get(GamificationService.class).evaluate(student);
                }
                if (backfilled > 0) {
                    Log.info("WellTrack", "Reconstructed " + backfilled + " historical risk scores");
                }

                int analysed = riskService.analyseAll().size();
                Log.success("WellTrack", "Initial analysis complete — %d students scored in %d ms"
                        .formatted(analysed, System.currentTimeMillis() - started));
                riskService.startDaemon();
                registry.get(EventBus.class).broadcast("ai.ready",
                        com.welltrack.core.json.JsonObject.of()
                                .set("message", "Scoring model trained and cohort analysis complete"));
            } catch (Exception e) {
                Log.error("WellTrack", "Model training failed", e);
            }
        }, "welltrack-model-trainer");
        trainer.setDaemon(false);
        trainer.start();
    }

    /** Graceful shutdown: drain requests, flush the datastore, close pools. */
    public void stop() {
        Log.info("WellTrack", "Shutting down…");
        if (webServer != null) {
            webServer.stop();
        }
        try {
            registry.get(Datastore.class).flush();
        } catch (RuntimeException ignored) {
            // The registry may already be closed.
        }
        registry.close();
        Log.success("WellTrack", "Shutdown complete. Data has been saved.");
    }

    /** Exposed for tests. */
    public ServiceRegistry registry() {
        return registry;
    }

    /** @return the supported roles, used by the tests and the docs generator. */
    public static List<String> roles() {
        return List.of("STUDENT", "FACULTY", "ADMIN");
    }
}
