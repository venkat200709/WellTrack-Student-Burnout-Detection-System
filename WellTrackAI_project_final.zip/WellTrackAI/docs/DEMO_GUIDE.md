# WellTrack — Review demonstration guide

A ten-minute walkthrough that shows every part of the system in a sensible order, with the
technical point to make at each step.

---

## Before you start

1. Open the `WellTrackAI` folder in IntelliJ IDEA.
2. Run **WellTrack ▶ Start Server**.
3. Watch the console: it seeds ten students with ninety days of history, trains the model,
   reconstructs the risk history and runs the first cohort analysis — all in about two seconds.
4. Open <http://localhost:8080>.

> If you want a completely fresh start at any point, delete the `data/` folder and run again.

**Talking point for the console output:** *"Everything you just saw — the datastore, the model
training, the cohort clustering — is our own Java. There are no downloaded libraries in this project
at all."*

---

## 1 · Sign-in screen (1 min)

- The particle constellation reacts to the cursor; it is drawn on a canvas, not an image.
- The accuracy figure in the left panel is fetched live from the trained model, not hard-coded.
- Type a wrong password for `venkat` first: the card shakes, the field turns red and the message says
  **"Incorrect password — 4 attempt(s) remaining"**.

**Talking point:** *"Login validation happens in seven stages: shape validation, IP rate limiting,
account lookup by username or email, active check, lockout window, a constant-time PBKDF2 comparison,
and an audit write. Five failures lock the account for ten minutes."*

Then click the **Student** demo chip to sign in as `venkat`.

---

## 2 · Student overview (2 min)

- The gauge sweeps up and the number counts to the live score.
- The trend chart draws itself, then the dashed seven-day forecast extends past the last real point
  inside a shaded confidence band.
- Scroll to **Why — Explainable AI**: each bar is a feature's exact contribution, in plain English.

**Talking point:** *"The score is an ensemble of four estimators — a logistic-regression model at 50%,
a transparent rule heuristic at 25%, an anomaly detector at 15% and the trend at 10%. Because the model
is linear on the standardised scale, weight times feature is the exact contribution, so these
explanations are mathematically derived rather than written by hand."*

Also point out the **cohort card** — `venkat` sits in *Sleep-Deprived High Achievers*, discovered by
k-means, and the **journal sentiment** panel, which reads the free-text notes.

---

## 3 · AI Insights and the what-if simulator (2 min)

Open **AI Insights** and drag the sleep slider from 5 hours up to 8.

- The projected score updates within a fifth of a second.
- The single-change sensitivity list re-ranks live.

**Talking point:** *"This is the same trained model scoring a hypothetical day. It turns the model from
a verdict into a planning tool — the student can see which single change buys the most relief before
committing a week of effort to it."*

---

## 4 · AI Coach (1.5 min)

Type: **"I cannot sleep at night and I feel so stressed about exams"**

Watch the typing indicator, then read the right-hand panel:

- intent `stress` with a confidence
- sentiment *Very negative*, dominant emotion *anxiety*
- the knowledge articles that were retrieved

**Talking point:** *"This is a full retrieval-augmented pipeline in Java. Naive Bayes classifies the
intent, a lexicon analyser with negation handling reads the sentiment, TF-IDF cosine similarity
retrieves the relevant article, and then the student's own live data is injected — notice it quotes
their actual stress level. No external API is called."*

---

## 5 · Daily check-in (1 min)

Open **Daily Check-in**, set sleep to 8.5 and stress to 3, write a positive journal note, submit.

- A toast shows the recalculated score immediately.
- Going back to Overview shows the gauge has moved.

Optionally demonstrate validation by setting attended classes above scheduled classes.

**Talking point:** *"One request triggers the whole chain: persist, recompute the streak, re-score
through the ensemble, regenerate the recommendations, evaluate four alerting rules and push a live
event — and the response already contains the new score."*

---

## 6 · Mentor console (2 min)

Sign out, then sign in as `vignesh` / `Faculty@2026`.

- Sort the roster by clicking **Burnout Risk**.
- Show the priority queue, the risk distribution donut and the discovered cohorts.
- Acknowledge an alert and watch it grey out.

**Keep a second browser window open, signed in as a student, and submit a check-in there** —
the alert appears in the mentor console instantly through the server-sent-events channel.

**Talking point:** *"Alerts fire on band crossings and predicted crossings, not on absolute values, and
they are de-duplicated per category per day — otherwise a mentor would be notified every fifteen
minutes about the same student and would stop reading them."*

---

## 7 · AI Transparency Lab (1.5 min)

Open **AI Lab** (available to every role).

- Every learned coefficient, ranked by influence.
- The confusion matrix with precision, recall, F1 and balanced accuracy.
- The full capability stack.

**Talking point:** *"Recall is 86.8%, deliberately higher than precision, because failing to flag a
student heading for burnout costs far more than a false alarm. And note that accuracy is 82.6%, not
100% — we inject 6% label noise into the training simulation on purpose, because a model reporting
perfect accuracy would have memorised a shortcut rather than learned anything."*

---

## 8 · System console (1 min)

Sign in as `admin` / `Admin@2026`, open **System**.

- Live JVM and HTTP metrics, thread count, active sessions.
- The security audit trail showing every sign-in attempt you made during this demonstration —
  including the failed one at the start.

---

## Extras worth showing if there is time

| Feature | How |
|---|---|
| Command palette | `Ctrl` + `K` from anywhere |
| Light theme | The moon icon in the top bar — the canvas charts re-theme too |
| Printable report | Command palette ▸ *Download my wellness report*, then print to PDF |
| CSV export | Mentor console ▸ *Export CSV* |
| Test suite | Run **WellTrack ✔ Run Tests** — 73 checks |
| Responsive layout | Narrow the window; the sidebar collapses to a menu |

---

## Likely questions

**"Where did the training data come from?"**
A generative simulation grounded in occupational-health research. Each simulated student gets a hidden
burnout propensity and every behaviour is sampled as a noisy function of it, using effect directions
from the literature. The same simulator produces the demonstration histories, so the seeded data is
statistically consistent with what the model learned.

**"Why logistic regression and not a neural network?"**
Because the explanation is the product. A linear model's coefficients *are* the explanation, available
in closed form. A neural network would score marginally better on this feature set and would be unable
to tell a student why they were flagged.

**"Why no Spring Boot?"**
Building the HTTP layer, dependency injection, JSON engine and security ourselves means the project is
our own Java rather than framework configuration, it runs anywhere a JDK exists with no downloads, and
every concept on the syllabus is visible in code we wrote.

**"Is this medical software?"**
No. It is a wellness indicator, explicitly not a diagnosis. When a student's language suggests genuine
distress the system stops giving advice and routes them to a human — and that behaviour is covered by
the test suite.
