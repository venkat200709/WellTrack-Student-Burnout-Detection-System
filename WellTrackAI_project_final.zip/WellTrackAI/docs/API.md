# WellTrack — REST API reference

Base URL `http://localhost:8080`

Authenticated endpoints require `Authorization: Bearer <token>`. Download links and the event stream also accept
`?token=<token>`, because a browser cannot attach a header to an anchor or an `EventSource`.

Every endpoint returns the same envelope:

```json
{ "success": true, "message": "optional", "data": { } }
```

Failures return `success: false` with a `message`, and validation failures add a `fieldErrors` map keyed by
field name.

---

## Authentication

| Method | Path | Auth | Description |
|---|---|---|---|
| `POST` | `/api/auth/login` | — | Sign in with username or email |
| `POST` | `/api/auth/register` | — | Create a student account |
| `POST` | `/api/auth/logout` | — | Revoke the current session |
| `GET` | `/api/auth/me` | any | The authenticated principal |
| `POST` | `/api/auth/password` | any | Change password (revokes all sessions) |
| `POST` | `/api/auth/password-strength` | — | Score a candidate password 0-100 |
| `GET` | `/api/auth/policy` | — | The password and lockout policy |

```bash
curl -X POST http://localhost:8080/api/auth/login \
  -H 'content-type: application/json' \
  -d '{"identifier":"venkat","password":"Student@2026"}'
```

---

## Dashboard and behaviour

| Method | Path | Auth | Description |
|---|---|---|---|
| `GET` | `/api/dashboard` | any | Everything the student dashboard needs, in one call |
| `GET` | `/api/dashboard/{studentId}` | self or elevated | The same, for a specific student |
| `POST` | `/api/behavior` | any | Record a check-in; re-scores immediately |
| `GET` | `/api/behavior/{studentId}?days=30` | self or elevated | Check-in history |
| `GET` | `/api/behavior/{studentId}/today` | self or elevated | Today's entry, to pre-fill the form |
| `GET` | `/api/behavior/{studentId}/weekly` | self or elevated | Week-over-week metric comparison |
| `GET` | `/api/behavior/{studentId}/journal` | self or elevated | NLP analysis of journal notes |
| `DELETE` | `/api/behavior/{studentId}/{logId}` | self or elevated | Delete an entry and recalculate |

---

## Risk analysis

| Method | Path | Auth | Description |
|---|---|---|---|
| `GET` | `/api/risk/{studentId}` | self or elevated | Latest score with drivers and forecast |
| `POST` | `/api/risk/{studentId}/analyse` | self or elevated | Force an immediate re-analysis |
| `GET` | `/api/risk/{studentId}/history?limit=60` | self or elevated | Score history for the trend chart |
| `GET` | `/api/risk/{studentId}/forecast` | self or elevated | Seven-day projection with intervals |
| `POST` | `/api/risk/analyse-all` | faculty, admin | Parallel sweep across the cohort |
| `GET` | `/api/risk/distribution` | faculty, admin | Population count per risk band |

---

## AI

| Method | Path | Auth | Description |
|---|---|---|---|
| `GET` | `/api/ai/model` | any | Weights, metrics, thresholds, ensemble weighting |
| `GET` | `/api/ai/cohorts` | any | Discovered wellness cohorts |
| `GET` | `/api/ai/explain/{studentId}` | self or elevated | Full ranked factor breakdown |
| `POST` | `/api/ai/simulate` | self or elevated | Counterfactual scoring + per-lever sensitivity |
| `GET` | `/api/ai/capabilities` | — | Public description of the AI stack and live metrics |

```bash
curl -X POST http://localhost:8080/api/ai/simulate \
  -H "Authorization: Bearer $TOKEN" -H 'content-type: application/json' \
  -d '{"sleepHours":8.2,"stressLevel":3,"studyHours":5}'
```

---

## Coaching, plan and gamification

| Method | Path | Auth | Description |
|---|---|---|---|
| `GET` | `/api/chat` | any | Transcript, seeded with a greeting when empty |
| `POST` | `/api/chat` | any | One conversational turn with the coach |
| `DELETE` | `/api/chat` | any | Clear the transcript |
| `GET` | `/api/recommendations/{studentId}` | self or elevated | Active plan and history |
| `POST` | `/api/recommendations/{id}/complete` | any | Mark an action done, award points |
| `GET` | `/api/recommendations/badges/{studentId}` | self or elevated | Earned badges |
| `GET` | `/api/recommendations/leaderboard` | any | Anonymised wellness leaderboard |

---

## Students, faculty and administration

| Method | Path | Auth | Description |
|---|---|---|---|
| `GET` | `/api/students?q=` | faculty, admin | Searchable roster |
| `GET` | `/api/students/{id}` | self or elevated | One student profile |
| `PUT` | `/api/students/{id}` | self or elevated | Update the profile |
| `POST` | `/api/students/{id}/mentor` | faculty, admin | Assign a mentor |
| `POST` | `/api/students/{id}/deactivate` | admin | Deactivate an account |
| `DELETE` | `/api/students/{id}` | admin | Delete a student and all their data |
| `GET` | `/api/faculty/overview` | faculty, admin | Console: roster, distribution, cohorts |
| `GET` | `/api/faculty/priority` | faculty, admin | Students needing contact, worst first |
| `GET` | `/api/faculty/timeline?days=30` | faculty, admin | Cohort risk over time |
| `GET` | `/api/faculty/behaviour` | faculty, admin | Cohort behavioural averages |
| `GET` | `/api/faculty/alerts` | faculty, admin | Alert feed in scope |
| `POST` | `/api/faculty/alerts/{id}/acknowledge` | faculty, admin | Acknowledge an alert |
| `POST` | `/api/faculty/alerts/raise` | faculty, admin | Raise a manual alert |
| `GET` | `/api/faculty/departments` | admin | Department rollup |

---

## Export, system and live stream

| Method | Path | Auth | Description |
|---|---|---|---|
| `GET` | `/api/export/behaviour/{studentId}` | self or elevated | Check-in history as CSV |
| `GET` | `/api/export/report/{studentId}` | self or elevated | Printable wellness report (HTML → PDF) |
| `GET` | `/api/export/cohort` | faculty, admin | Cohort snapshot as CSV |
| `GET` | `/api/system/health` | — | Liveness probe |
| `GET` | `/api/system/metrics` | admin | HTTP, JVM, domain and real-time counters |
| `GET` | `/api/system/sessions` | admin | Live sessions |
| `GET` | `/api/system/audit?limit=100` | admin | Security audit trail |
| `GET` | `/api/stream?token=…` | any | Server-sent events |

### Stream events

| Event | Sent to | Payload |
|---|---|---|
| `connected` | the subscriber | Subscription id, user, role |
| `alert.created` | the student and their mentors | The alert |
| `risk.updated` | the student | The new score |
| `risk.intervention` | faculty and admins | Student, score, band |
| `badge.earned` | the student | The badge |
| `recommendations.updated` | the student | Count of new actions |
| `ai.ready` | everyone | Model training finished |

---

## Status codes

| Code | Meaning |
|---|---|
| `200` / `201` | Success |
| `400` | Malformed request or JSON |
| `401` | Missing, expired, revoked or tampered token |
| `403` | Authenticated but not permitted |
| `404` | No such route or entity |
| `405` | Path exists under a different verb |
| `409` | Uniqueness or state conflict |
| `422` | Validation failed — inspect `fieldErrors` |
| `429` | Rate limited |
| `500` | Unexpected server failure (logged with a correlation id) |
