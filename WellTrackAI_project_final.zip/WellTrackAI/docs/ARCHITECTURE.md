# WellTrack — Architecture

## Design goals

1. **Runs anywhere, immediately.** A live demonstration must not depend on a build tool downloading jars, a
   database server being installed, or an internet connection existing in the room. The only prerequisite is a JDK.
2. **The AI must be readable.** Every model is implemented from first principles so each algorithm can be opened
   and explained, rather than being a library call whose behaviour is taken on faith.
3. **Explanation before prediction.** A wellness score a student cannot interrogate is not useful. Every point of
   the score is attributable to a named behaviour.
4. **Fail safe, never silent.** Missing data, an untrained model, an unreachable language model or a corrupt table
   all degrade to a working state rather than an error page.

---

## Layered structure

```
                    ┌──────────────────────────────────────────┐
   Browser  ◄──────►│  Single-page interface (vanilla JS)      │
                    │  · canvas charts   · SSE live channel    │
                    └──────────────────┬───────────────────────┘
                                       │  JSON over HTTP
                    ┌──────────────────▼───────────────────────┐
                    │  Transport — core.http                   │
                    │  WebServer · Router · Filters · SSE      │
                    └──────────────────┬───────────────────────┘
                                       │
                    ┌──────────────────▼───────────────────────┐
                    │  Security — SecurityFilter · AuthService │
                    │  PBKDF2 · JWT · sessions · rate limiting │
                    └──────────────────┬───────────────────────┘
                                       │
                    ┌──────────────────▼───────────────────────┐
                    │  Controllers — request/response mapping  │
                    └──────────────────┬───────────────────────┘
                                       │
        ┌──────────────────────────────▼───────────────────────┐
        │  Services — business logic and orchestration         │
        │  RiskAnalysisService · AlertService · ChatService …  │
        └───────┬──────────────────────────────────┬───────────┘
                │                                  │
   ┌────────────▼─────────────┐      ┌─────────────▼──────────────┐
   │  AI engine (com.welltrack.ai) │  │  Repositories              │
   │  prediction · forecasting     │  │  generic + typed queries   │
   │  clustering · NLP · recommend │  └─────────────┬──────────────┘
   └───────────────────────────────┘                │
                                       ┌────────────▼─────────────┐
                                       │  Datastore (interface)   │
                                       │  File · Memory · JDBC    │
                                       └──────────────────────────┘
```

Dependencies point strictly downward. The AI layer knows nothing about HTTP; repositories know nothing about the
storage medium; controllers contain no security logic.

---

## The analysis pipeline

When a student submits a check-in, one request triggers the entire chain:

```
BehaviorController.create
   └─ BehaviorService.record            validate, upsert by date, recompute streak
   └─ RiskAnalysisService.analyse
        ├─ BurnoutPredictor.aggregate   14-day window → recency-weighted feature vector
        ├─ BurnoutPredictor.probability logistic model  ─┐
        ├─ weightedHeuristic            rule engine      ├─ ensemble → 0-100 score
        ├─ AnomalyDetector.anomalyScore MAD + EWMA       │
        ├─ Numbers.slope                trend            ─┘
        ├─ BurnoutPredictor.explain     ranked RiskDrivers
        ├─ ForecastEngine.project       Holt → 7-day projection + interval
        ├─ AlertService.evaluate        four alerting rules, de-duplicated daily
        ├─ RecommendationService.refresh content-based + collaborative plan
        └─ EventBus.publish             live push to the student and their mentor
   └─ GamificationService.onCheckIn     points, streak badges
```

The response already contains the updated score, so the interface never has to poll for it.

### Recency weighting

Both the feature aggregation and the heuristic weight day *d* by `0.5^(daysAgo/5)` — a five-day half-life. The most
recent day therefore carries roughly four times the influence of a day a week earlier, which is what allows the
system to react to a bad week without being anchored by a good month.

### Graceful degradation

`BurnoutPredictor.isReady()` is checked at every use. Before training completes the ensemble reweights to
`0.75 heuristic + 0.15 anomaly + 0.10 trend`, so the application is fully usable from the first millisecond and
transparently upgrades when the model is ready.

---

## Concurrency model

| Pool | Purpose | Sizing |
|---|---|---|
| `welltrack-http-*` | Request handling | Fixed, `server.threads` (default 32) |
| Work-stealing pool | Parallel cohort analysis via `CompletableFuture` | `availableProcessors()` |
| `welltrack-analysis-daemon` | Periodic re-analysis sweep | Single scheduled thread |
| `welltrack-datastore-flusher` | Asynchronous write-behind to disk | Single scheduled thread |
| `welltrack-model-trainer` | One-off model training at start-up | One thread, then exits |

Shared state is protected by `ConcurrentHashMap`, `AtomicLong` and a `ReentrantReadWriteLock` in the datastore
(unlimited concurrent readers, exclusive writers). The event bus uses bounded queues that drop their oldest entry
rather than blocking a publisher, so a slow browser can never stall the analysis pipeline.

---

## Storage

The default engine writes one JSON document per logical table under `data/`. Writes are buffered in memory and
flushed by a background scheduler; each flush writes to a temporary file and then performs an atomic move, so an
interrupted process can never leave a half-written table. A corrupt table is quarantined with a timestamped suffix
and the application starts with an empty one rather than refusing to boot.

Switching to `datastore=jdbc` changes nothing above the `Datastore` interface. The relational schema is a document
table plus reporting views that project the JSON into ordinary columns (`sql/schema.sql`), so the same data can be
analysed with plain SQL.

---

## Security model

**Authentication.** Sign-in clears seven gates in order: shape validation, IP rate limiting, account lookup by
username *or* email, active check, lockout window, constant-time PBKDF2 verification, audit. Failure messaging is
uniform so an attacker cannot enumerate valid usernames, while the genuine user still sees their remaining attempt
count.

**Sessions.** Tokens are stateless JWTs signed with HMAC-SHA256, which makes verification cheap. Because a
stateless token cannot be revoked, they are paired with a small server-side `SessionRegistry`: the token's `jti`
claim is looked up on every request, so signing out or changing a password invalidates it immediately.

**Authorisation.** Declared on the route, enforced by `SecurityFilter` before any handler runs. Roles are
hierarchical (`ADMIN` satisfies everything below it) and a `requireSelfOrElevated` rule keeps students inside their
own records.

**Transport.** Every response carries `X-Content-Type-Options`, `X-Frame-Options` and `Referrer-Policy`. Static
file serving rejects `..` traversal and resolves only inside the resource root.

---

## Front-end architecture

No framework, no bundler, no CDN dependency. Six classic scripts attach to a `WT` namespace:

| File | Responsibility |
|---|---|
| `api.js` | Token-aware fetch wrapper, response envelope, typed `ApiError` with field errors |
| `ui.js` | DOM helpers, toasts, modals, count-up animation, particle field, theming |
| `charts.js` | The canvas chart library — area, sparkline, bar, donut, scatter, radial |
| `views-student.js` | Overview, check-in, insights, coach, plan |
| `views-faculty.js` | Mentor console, AI lab, system console |
| `app.js` | Auth screens, shell, routing, SSE, command palette |

Views are plain async functions that own their own data fetching, so navigation never waits on a global store.
All colour comes from CSS custom properties, which is why the entire interface — including the canvas charts —
re-themes correctly when the theme is toggled.
