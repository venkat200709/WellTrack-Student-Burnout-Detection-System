-- =============================================================================
--  WellTrack — relational schema
--
--  WellTrack runs out of the box on its own embedded document store, so this
--  script is only required when switching to `datastore=jdbc`.
--
--  Compatible with both H2 and MySQL 8.
--
--  Usage (MySQL):
--      mysql -u root -p < sql/schema.sql
--  then set in config/application.properties:
--      datastore=jdbc
--      jdbc.url=jdbc:mysql://localhost:3306/welltrack?serverTimezone=UTC
-- =============================================================================

CREATE DATABASE IF NOT EXISTS welltrack
    DEFAULT CHARACTER SET utf8mb4
    DEFAULT COLLATE utf8mb4_unicode_ci;

USE welltrack;

-- -----------------------------------------------------------------------------
-- The document table used by JdbcDatastore.
--
-- One row per entity: the logical table name, the primary key and a JSON
-- payload. This keeps the storage engine swappable without a migration for
-- every model change, while remaining fully queryable through the JSON
-- functions both H2 and MySQL provide.
-- -----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS wt_document (
    table_name  VARCHAR(64)  NOT NULL COMMENT 'users, behavior_logs, risk_scores, …',
    entity_id   BIGINT       NOT NULL COMMENT 'surrogate key within that table',
    payload     TEXT         NOT NULL COMMENT 'the entity serialised as JSON',
    updated_at  TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (table_name, entity_id),
    INDEX idx_wt_document_table (table_name)
);

-- =============================================================================
--  Reporting views
--
--  These project the JSON payloads into ordinary relational columns so the same
--  data can be analysed with plain SQL — useful for institutional reporting
--  alongside the application's own dashboards.
-- =============================================================================

CREATE OR REPLACE VIEW v_students AS
SELECT
    entity_id                                                     AS student_id,
    JSON_UNQUOTE(JSON_EXTRACT(payload, '$.registerNumber'))        AS register_number,
    JSON_UNQUOTE(JSON_EXTRACT(payload, '$.fullName'))              AS full_name,
    JSON_UNQUOTE(JSON_EXTRACT(payload, '$.email'))                 AS email,
    JSON_UNQUOTE(JSON_EXTRACT(payload, '$.department'))            AS department,
    JSON_UNQUOTE(JSON_EXTRACT(payload, '$.section'))               AS section,
    CAST(JSON_EXTRACT(payload, '$.yearOfStudy')      AS UNSIGNED)  AS year_of_study,
    CAST(JSON_EXTRACT(payload, '$.cgpa')             AS DECIMAL(4,2)) AS cgpa,
    CAST(JSON_EXTRACT(payload, '$.attendancePercentage') AS DECIMAL(5,2)) AS attendance_percentage,
    CAST(JSON_EXTRACT(payload, '$.streakDays')       AS UNSIGNED)  AS streak_days,
    CAST(JSON_EXTRACT(payload, '$.wellnessPoints')   AS UNSIGNED)  AS wellness_points,
    CAST(JSON_EXTRACT(payload, '$.mentorId')         AS UNSIGNED)  AS mentor_id
FROM wt_document
WHERE table_name = 'users'
  AND JSON_UNQUOTE(JSON_EXTRACT(payload, '$.type')) = 'Student';

CREATE OR REPLACE VIEW v_behavior_logs AS
SELECT
    entity_id                                                      AS log_id,
    CAST(JSON_EXTRACT(payload, '$.studentId')       AS UNSIGNED)   AS student_id,
    CAST(JSON_UNQUOTE(JSON_EXTRACT(payload, '$.logDate')) AS DATE) AS log_date,
    CAST(JSON_EXTRACT(payload, '$.sleepHours')      AS DECIMAL(4,2)) AS sleep_hours,
    CAST(JSON_EXTRACT(payload, '$.studyHours')      AS DECIMAL(4,2)) AS study_hours,
    CAST(JSON_EXTRACT(payload, '$.screenTimeHours') AS DECIMAL(4,2)) AS screen_time_hours,
    CAST(JSON_EXTRACT(payload, '$.exerciseMinutes') AS UNSIGNED)   AS exercise_minutes,
    CAST(JSON_EXTRACT(payload, '$.socialMinutes')   AS UNSIGNED)   AS social_minutes,
    CAST(JSON_EXTRACT(payload, '$.stressLevel')     AS UNSIGNED)   AS stress_level,
    JSON_UNQUOTE(JSON_EXTRACT(payload, '$.mood'))                  AS mood,
    CAST(JSON_EXTRACT(payload, '$.classesAttended') AS UNSIGNED)   AS classes_attended,
    CAST(JSON_EXTRACT(payload, '$.classesScheduled')AS UNSIGNED)   AS classes_scheduled,
    JSON_UNQUOTE(JSON_EXTRACT(payload, '$.journalNote'))           AS journal_note
FROM wt_document
WHERE table_name = 'behavior_logs';

CREATE OR REPLACE VIEW v_risk_scores AS
SELECT
    entity_id                                                      AS score_id,
    CAST(JSON_EXTRACT(payload, '$.studentId')  AS UNSIGNED)        AS student_id,
    CAST(JSON_EXTRACT(payload, '$.score')      AS DECIMAL(5,2))    AS score,
    JSON_UNQUOTE(JSON_EXTRACT(payload, '$.level'))                 AS risk_level,
    JSON_UNQUOTE(JSON_EXTRACT(payload, '$.trend'))                 AS trend,
    CAST(JSON_EXTRACT(payload, '$.confidence') AS DECIMAL(4,3))    AS confidence,
    JSON_UNQUOTE(JSON_EXTRACT(payload, '$.computedAt'))            AS computed_at
FROM wt_document
WHERE table_name = 'risk_scores';

-- -----------------------------------------------------------------------------
-- Example analytical queries
-- -----------------------------------------------------------------------------

-- Students currently requiring intervention, worst first.
-- SELECT s.full_name, s.register_number, r.score, r.risk_level
-- FROM v_students s
-- JOIN v_risk_scores r ON r.student_id = s.student_id
-- WHERE r.score >= 60
-- ORDER BY r.score DESC;

-- Average sleep per department over the last fortnight.
-- SELECT s.department, ROUND(AVG(b.sleep_hours), 2) AS avg_sleep, COUNT(*) AS entries
-- FROM v_behavior_logs b
-- JOIN v_students s ON s.student_id = b.student_id
-- WHERE b.log_date >= CURDATE() - INTERVAL 14 DAY
-- GROUP BY s.department;

-- The correlation between attendance and burnout, bucketed.
-- SELECT FLOOR(s.attendance_percentage / 10) * 10 AS attendance_band,
--        ROUND(AVG(r.score), 1) AS avg_burnout, COUNT(*) AS students
-- FROM v_students s JOIN v_risk_scores r ON r.student_id = s.student_id
-- GROUP BY attendance_band ORDER BY attendance_band;
